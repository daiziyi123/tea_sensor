#ifndef APP_DIAGNOSTICS_H
#define APP_DIAGNOSTICS_H
#include "sensor_soil.h"
#include "sensor_wind_speed.h"
#include "sensor_wind_direction.h"
#include "sensor_ph.h"

/* AD3 raw observations retained for local diagnostics; business result is circular. */
typedef struct
{
  uint32_t sample_count;
  uint32_t valid_count;
  uint64_t raw_sum;
  uint16_t raw_min;
  uint16_t raw_max;
  uint32_t error_counts[BSP_ADC_OUT_OF_RANGE + 1U];
  uint32_t cleanup_errors;
  uint32_t prepare_errors;
  uint32_t config_errors;
  BspAdcResult last_error;
} AppAdcRawWindow;

typedef AppAdcRawWindow AppAd3Window;

typedef struct
{
  uint32_t round_id;
  uint32_t round_t_ms;
  uint32_t soil_read_start_ms;
  uint32_t soil_read_end_ms;
  uint32_t wind_read_start_ms;
  uint32_t wind_read_end_ms;
  uint32_t pair_span_ms;
  uint32_t ad3_read_start_ms;
  uint32_t ad3_read_end_ms;
  uint32_t ad4_read_start_ms;
  uint32_t ad4_read_end_ms;
  uint32_t round_span_ms;
  SensorSoilData soil;
  SensorWindSpeedData wind;
  BspAdcResult ad3;
  BspAdcResult ad4;
  SensorPhValue soil_ph;
  SensorWindDirectionValue wind_direction;
} AppSampleRound;

typedef struct AppDiagnostics
{
  uint32_t sequence;
  uint32_t printf_errors;
  uint32_t completed_windows;
  uint32_t sample_errors;
  uint32_t sample_error_counts[BSP_ADC_OUT_OF_RANGE + 1U];
  uint32_t cleanup_errors;
  uint32_t last_window_end_ms;
  BspAdcResult last_adc_error;
  SensorSoilWindowResult last_window;
  SensorWindSpeedWindowResult last_wind_window;
  SensorWindSpeedDiagnostics wind_diagnostics;
  uint32_t wind_sample_errors;
  uint32_t ad3_sample_errors;
  AppAd3Window last_ad3_window;
  uint32_t ad4_sample_errors;
  SensorPhWindow last_ad4_window;
  SensorPhValue last_soil_ph;
  uint32_t ph_used_count;
  SensorWindDirectionWindowResult last_direction_window;
  AppSampleRound last_round;
} AppDiagnostics;


#endif
