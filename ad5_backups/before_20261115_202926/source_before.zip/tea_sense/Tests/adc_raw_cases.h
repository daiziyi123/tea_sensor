#ifndef ADC_RAW_CASES_H
#define ADC_RAW_CASES_H
/* Raw samples remain debugger/test data; normal output is one physical window. */
static void Test_RawSamplesAndFaults(void)
{
  BspAdcResult adc;
  const AppSampleRound *round;
  unsigned before;
  Test_Reset(0U); s_soil_duration_ms=2U;s_wind_duration_ms=3U;s_ad3_duration_ms=4U;s_ad4_duration_ms=5U;
  Test_At(950U);before=s_config_calls;Test_At(1000U);round=&App_GetDiagnostics()->last_round;
  assert(before==4U && s_config_calls==before && s_wind_reads==1U && s_ad4_reads==1U);
  assert(round->wind_read_start_ms==952U && round->ad4_read_start_ms==959U && round->ad4_read_end_ms==964U);
  assert(!s_console_length);
  Test_Reset(0U);s_wind_raw=s_ad4_raw=0U;Test_At(1000U);
  assert(App_GetDiagnostics()->last_round.wind.adc.valid && App_GetDiagnostics()->last_round.ad4.valid);
  assert(App_GetDiagnostics()->last_round.soil_ph.valid && App_GetDiagnostics()->last_round.soil_ph.range==SENSOR_PH_RANGE_LOW);
  s_wind_raw=321U;s_ad4_poll_result=HAL_TIMEOUT;s_ad4_stop_result=HAL_ERROR;Test_At(2000U);round=&App_GetDiagnostics()->last_round;
  assert(round->wind.adc.valid && round->wind.adc.raw==321U && !round->ad4.valid && !round->soil_ph.valid);
  assert(round->ad4.stage==BSP_ADC_STAGE_POLL && round->ad4.hal_status==BSP_ADC_HAL_TIMEOUT && round->ad4.stop_status==BSP_ADC_HAL_ERROR);
  s_ad4_poll_result=HAL_OK;Test_At(3000U);
  assert(App_GetDiagnostics()->last_round.ad4.stage==BSP_ADC_STAGE_STOP && !App_GetDiagnostics()->last_round.soil_ph.valid);
  s_ad4_stop_result=HAL_OK;s_ad4_config_result=HAL_BUSY;Test_At(4000U);
  assert(App_GetDiagnostics()->last_round.ad4.stage==BSP_ADC_STAGE_CONFIG && App_GetDiagnostics()->last_round.ad4.config_status==BSP_ADC_HAL_BUSY);
  s_ad4_config_result=HAL_OK;s_ad4_start_result=HAL_ERROR;Test_At(5000U);
  assert(App_GetDiagnostics()->last_round.ad4.stage==BSP_ADC_STAGE_START);
  s_ad4_start_result=HAL_OK;s_ad4_raw=65536U;Test_At(6000U);
  assert(App_GetDiagnostics()->last_round.ad4.status==BSP_ADC_OUT_OF_RANGE && !App_GetDiagnostics()->last_round.soil_ph.valid);
  assert(App_GetDiagnostics()->last_ad4_window.cleanup_errors==1U && App_GetDiagnostics()->last_ad4_window.config_errors==1U);
  s_ad4_raw=65535U;s_wind_poll_result=HAL_TIMEOUT;Test_At(7000U);
  assert(App_GetDiagnostics()->last_round.ad4.valid && !App_GetDiagnostics()->last_round.wind.adc.valid);
  s_prepare_result=HAL_TIMEOUT;before=s_config_calls;Test_At(8000U);
  assert(s_config_calls==before && App_GetDiagnostics()->last_round.ad4.prepare_status==BSP_ADC_HAL_TIMEOUT);
  s_cal_result=HAL_ERROR;BspAdc_Init();Test_At(9000U);
  adc=BspAdc_ReadRaw(BSP_ADC_INPUT_PH_AD4);
  assert(!adc.valid && adc.stage==BSP_ADC_STAGE_CALIBRATION && !adc.prepare_attempted && !adc.stop_attempted);
  assert(s_config_calls==before);
}
static void Test_RawWindows(void)
{
  unsigned tick;
  Test_Reset(0U);
  for(tick=0U;tick<3000U;tick+=100U) {
    s_wind_raw=tick==0U?0U:tick==2900U?65535U:1000U;
    s_ad4_raw=tick==0U?100U:tick==2900U?200U:2000U;Test_At(tick);
  }
  s_wind_raw=7U;s_ad4_raw=11U;Test_At(3000U);
  assert(App_GetDiagnostics()->last_wind_window.raw_sum==93535U && App_GetDiagnostics()->last_wind_window.raw_mean==1000U);
  assert(App_GetDiagnostics()->last_ad4_window.raw_sum==56300U && App_GetDiagnostics()->ph_used_count==28U);
  assert(!strstr(s_console,"ADC_SAMPLE") && !strstr(s_console,"ADC_WINDOW") && strstr(s_console,"土壤 pH："));
  Test_Through(6000U);
  assert(App_GetDiagnostics()->last_ad4_window.raw_sum==330U && App_GetDiagnostics()->last_wind_window.raw_sum==210U);
  Test_Reset(0U);s_wind_raw=s_ad4_raw=0U;Test_At(0U);Test_Through(3000U);
  assert(App_GetDiagnostics()->last_wind_window.value.valid && App_GetDiagnostics()->last_soil_ph.valid);
  assert(App_GetDiagnostics()->last_soil_ph.soil_ph_x100==300U);
  Test_Reset(0U);s_wind_poll_result=s_ad4_poll_result=HAL_TIMEOUT;s_wind_stop_result=s_ad4_stop_result=HAL_ERROR;
  Test_At(0U);Test_Through(3000U);
  assert(App_GetDiagnostics()->last_ad4_window.valid_count==0U && App_GetDiagnostics()->last_ad4_window.cleanup_errors==30U);
  assert(!App_GetDiagnostics()->last_soil_ph.valid && !App_GetDiagnostics()->last_wind_window.value.valid);
  assert(strstr(s_console,"数据无效"));
}
static void Test_RawWindowBoundaries(void)
{
  uint32_t base=UINT32_MAX-1499U;unsigned before;
  Test_Reset(0U);s_ad4_duration_ms=10U;s_ad4_raw=123U;Test_At(2995U);Test_At(3005U);
  assert(App_GetDiagnostics()->last_ad4_window.sample_count==1U && !App_GetDiagnostics()->last_soil_ph.valid);
  assert(App_GetDiagnostics()->last_wind_window.sample_count==1U);
  Test_Reset(base);s_ad4_raw=500U;Test_At(base);Test_At(base+2900U);s_ad4_raw=900U;Test_At(base+3000U);
  assert(App_GetDiagnostics()->last_window_end_ms==1500U && App_GetDiagnostics()->last_ad4_window.raw_sum==1000U);
  assert(App_GetDiagnostics()->last_round.ad4.raw==900U);
  Test_Reset(UINT32_MAX-3U);s_soil_duration_ms=2U;s_wind_duration_ms=4U;s_ad3_duration_ms=3U;s_ad4_duration_ms=5U;Test_At(UINT32_MAX-3U);
  assert(App_GetDiagnostics()->last_round.ad4_read_start_ms==5U && App_GetDiagnostics()->last_round.ad4_read_end_ms==10U);
  Test_Reset(0U);Test_At(0U);Test_At(10000U);before=s_config_calls;
  assert(App_GetDiagnostics()->last_ad4_window.sample_count==0U && !App_GetDiagnostics()->last_soil_ph.valid);
  assert(s_wind_reads==2U && s_ad4_reads==2U && s_cal_calls==1U);
  Test_At(10000U);assert(s_config_calls==before && !s_console_length);
}
static void Test_WindSpeedPrinting(void)
{
  unsigned tick,before;
  Test_Reset(0U);s_wind_raw=15793U;s_ad4_raw=15716U;
  for(tick=0U;tick<3000U;tick+=100U) { Test_At(tick); }
  before=s_config_calls;Test_At(3000U);
  assert(s_config_calls==before+4U && App_GetDiagnostics()->last_wind_window.value.wind_speed_mps_x100==1500U);
  assert(strstr(s_console,"风速：15.00 m/s") && strstr(s_console,"土壤 pH：6.00"));
  assert(!strstr(s_console,"ADC_") && !strstr(s_console,"input_mv") && !strstr(s_transmitted,"adc_raw"));
  Test_At(3001U);assert(!s_console_length);
}
#endif
