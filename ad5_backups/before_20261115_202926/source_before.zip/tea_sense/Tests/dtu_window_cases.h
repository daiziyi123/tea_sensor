static uint8_t Test_JsonField(const char *path,const char *expected)
{
  const char *value;size_t length;JSONTypes_t type;
  JSONStatus_t status=JSON_SearchConst(s_transmitted,s_transmitted_length,path,strlen(path),&value,&length,&type);
  if(!expected) { return status==JSONNotFound; }
  return status==JSONSuccess && length==strlen(expected) && !memcmp(value,expected,length);
}

static void Test_Through(uint32_t end)
{
  while ((uint32_t)(end - s_tick_ms) >= 100U) { Test_At(s_tick_ms + 100U); }
  if (s_tick_ms != end) { Test_At(end); }
}

static void Test_FirstWindow(uint32_t base)
{
  Test_Reset(base); Test_At(base); Test_Through(base + 3000U);
  assert(s_uart6_sends == 1U);
}

static void Test_FragmentedAndMultipleLines(void)
{
  size_t split;
  unsigned soil_before;
  Test_Reset(0U); Test_At(0U); Test_Through(2999U); assert(!s_uart6_sends);
  Test_At(3000U); assert(s_uart6_sends == 1U);
  assert(strstr(s_transmitted,"\"t_ms\":3000") && Test_JsonField("data.soil_moisture_pct.value","50.00"));
  assert((Test_JsonField("schema_version","2") && App_GetDiagnostics()->last_window.used_count==28U));
  split=s_ack_length/2U; soil_before=s_soil_reads;
  Test_Inject(s_ack,split); Test_At(3001U); assert(!Test_Acks());
  Test_Inject(s_ack+split,s_ack_length-split); Test_At(3050U);
  assert(Test_Acks()==1U && s_soil_reads==soil_before && s_uart6_sends==1U);
  Test_Through(6000U); assert(s_uart6_sends==2U);
  Test_Inject("noise\nwrong\r\n",13U);
  Test_Inject(s_ack,s_ack_length); Test_Inject(s_ack,s_ack_length); Test_At(6040U);
  assert(Test_Acks()==1U && (AppUpload_GetDiagnostics()->ack_sequence==2U && AppUpload_GetDiagnostics()->ack_id==14U));
  assert(!BspDtu_GetDiagnostics().rx_overflows);
  Test_At(6041U); assert(s_uart6_sends==2U && !Test_Acks());
}

static void Test_MismatchTimeoutAndSoil(void)
{
  unsigned soil_before;
  static const char wrong[]="{\"ok\":true,\"device_id\":\"tea_h743_001\",\"seq\":99,\"id\":1}\n";
  Test_FirstWindow(0U); Test_Inject(wrong,sizeof(wrong)-1U); Test_At(3100U); assert(!Test_Acks());
  Test_Inject("{\"ok\":false}\n",13U); Test_At(3200U); assert(!Test_Acks());
  soil_before=s_soil_reads; Test_Through(6000U);
  assert(s_soil_reads>soil_before && s_uart6_sends==1U);
  assert(strstr(s_console,"土壤湿度：50.00%，"));
  Test_Through(12000U); assert(AppUpload_GetDiagnostics()->skipped_busy==3U);
  Test_Through(12999U); assert(!(AppUpload_GetDiagnostics()->timeouts!=s_timeouts_before_process));
  Test_Inject(s_ack,s_ack_length); Test_At(13000U);
  assert(!Test_Acks() && (AppUpload_GetDiagnostics()->timeouts!=s_timeouts_before_process && AppUpload_GetDiagnostics()->last_sequence==1U));
  Test_At(13000U); Test_Through(14999U); assert(s_uart6_sends==1U);
  Test_At(15000U); assert(s_uart6_sends==2U && strstr(s_transmitted,"\"t_ms\":15000"));
  Test_At(15000U); assert(s_uart6_sends==2U);
}

static void Test_TickWrap(void)
{
  uint32_t base=UINT32_MAX-2000U;
  Test_FirstWindow(base);
  assert(App_GetDiagnostics()->last_window_end_ms==999U);
  Test_Inject(s_ack,s_ack_length); Test_At(base+3010U); assert(Test_Acks()==1U);
  Test_FirstWindow(base); Test_Through(base+12999U); assert(!(AppUpload_GetDiagnostics()->timeouts!=s_timeouts_before_process));
  Test_At(base+13000U); assert((AppUpload_GetDiagnostics()->timeouts!=s_timeouts_before_process && AppUpload_GetDiagnostics()->last_sequence==1U));
  Test_Through(base+15000U); assert(s_uart6_sends==2U);
}

static void Test_OverflowAndLongLine(void)
{
  unsigned index; const char noise='x';
  Test_FirstWindow(0U); Test_Inject(s_ack,10U); Test_At(3010U);
  for(index=0U;index<300U;++index) { Test_Inject(&noise,1U); }
  assert(BspDtu_GetDiagnostics().rx_overflows==45U);
  Test_At(3020U); assert(!Test_Acks() && AppUpload_GetDiagnostics()->stream_gaps);
  Test_Inject(s_ack,s_ack_length); Test_At(3030U); assert(!Test_Acks());
  Test_Inject(s_ack,s_ack_length); Test_At(3040U); assert(Test_Acks()==1U);
  Test_FirstWindow(0U);
  for(index=0U;index<513U;++index) { Test_Inject(&noise,1U); if(index%32U==31U) { Test_At(3001U); } }
  Test_Inject(s_ack,s_ack_length); Test_At(3010U); assert(!Test_Acks());
  Test_Inject(s_ack,s_ack_length); Test_At(3020U); assert(Test_Acks()==1U);
}

static void Test_ReceiveRecovery(void)
{
  uint8_t scratch[32];
  Test_FirstWindow(0U); Test_Inject(s_ack,10U); Test_At(3010U);
  Test_Error(HAL_UART_ERROR_ORE|HAL_UART_ERROR_FE);
  assert(s_rx_armed && BspDtu_GetDiagnostics().rx_errors==1U);
  assert(BspDtu_GetDiagnostics().last_uart_error==(HAL_UART_ERROR_ORE|HAL_UART_ERROR_FE));
  Test_At(3011U); assert(!Test_Acks() && AppUpload_GetDiagnostics()->stream_gaps);
  Test_Inject(s_ack+10U,s_ack_length-10U); Test_Inject(s_ack,s_ack_length); Test_At(3020U); assert(Test_Acks()==1U);
  Test_Reset(0U); s_rx_result=HAL_ERROR; Test_Inject("a",1U);
  assert(!BspDtu_GetDiagnostics().rx_active && BspDtu_GetDiagnostics().rx_start_errors==1U);
  s_rx_result=HAL_OK; Test_At(1U); assert(s_rx_armed);
  Test_Inject("\n",1U); Test_At(2U); Test_Through(3000U);
  Test_Inject(s_ack,s_ack_length); Test_At(3001U); assert(Test_Acks()==1U);
  Test_Reset(0U); s_abort_result=HAL_ERROR; Test_Error(HAL_UART_ERROR_PE);
  assert(BspDtu_GetDiagnostics().last_abort_status==BSP_DTU_UART_ERROR);
  Test_At(1U); assert(!BspDtu_GetDiagnostics().rx_active);
  s_abort_result=HAL_OK; Test_At(2U); assert(s_rx_armed);
  Test_Inject("\n",1U); Test_At(3U); Test_Through(3000U);
  Test_Inject(s_ack,s_ack_length); Test_At(3001U); assert(Test_Acks()==1U);
  Test_Reset(0U); s_rx_result=HAL_ERROR; App_Init();
  assert(AppUpload_GetDiagnostics()->init_status==BSP_DTU_UART_ERROR);
  Test_Through(3000U); assert(!s_uart6_sends && BspDtu_GetDiagnostics().last_tx_status==BSP_DTU_RX_NOT_READY);
  s_rx_result=HAL_OK; Test_At(3001U); assert(s_rx_armed);
  Test_Inject("\n",1U); Test_At(3002U); Test_Through(6000U);
  Test_Inject(s_ack,s_ack_length); Test_At(6001U); assert(Test_Acks()==1U);
  __disable_irq(); (void)BspDtu_Read(scratch,sizeof(scratch));
  (void)BspDtu_GetDiagnostics(); assert(s_irq_mask==1U); __set_PRIMASK(0U);
}

static void Test_SendFailuresAndLengthGuard(void)
{
  const HAL_StatusTypeDef failures[]={HAL_ERROR,HAL_BUSY,HAL_TIMEOUT};
  const BspDtuStatus statuses[]={BSP_DTU_UART_ERROR,BSP_DTU_UART_BUSY,BSP_DTU_UART_TIMEOUT};
  unsigned index,starts,writes;
  for(index=0U;index<3U;++index)
  {
    Test_Reset(0U); s_tx_result=failures[index]; Test_At(0U); Test_Through(3000U);
    assert(BspDtu_GetDiagnostics().last_tx_status==statuses[index] && AppUpload_GetDiagnostics()->last_sequence==1U);
    assert(BspDtu_GetDiagnostics().tx_errors==1U);
    Test_Inject(s_ack,s_ack_length); Test_At(3010U); assert(!Test_Acks());
    s_tx_result=HAL_OK; Test_Through(6000U); assert(s_uart6_sends==2U);
    Test_Inject(s_ack,s_ack_length); Test_At(6001U); assert(Test_Acks()==1U);
  }
  Test_Reset(0U); s_format_fault=1; Test_At(0U); Test_Through(3000U);
  assert(!s_uart6_sends && (AppUpload_GetDiagnostics()->format_errors==1U && AppUpload_GetDiagnostics()->last_sequence==1U));
  s_format_fault=2; Test_Through(6000U); assert(!s_uart6_sends);
  s_format_fault=0; Test_Through(9000U); assert(s_uart6_sends==1U);
  Test_At(9001U);
  assert(BspDtu_TxBuffer(NULL)==NULL);
  assert(BspDtu_StartSend(0U)==BSP_DTU_BAD_LENGTH);
  assert(BspDtu_StartSend(65536U)==BSP_DTU_BAD_LENGTH);
  starts=s_rx_starts; writes=s_gpio_writes;
  HAL_UART_RxCpltCallback(&huart2); HAL_UART_ErrorCallback(&huart2);
  assert(s_rx_starts==starts && s_gpio_writes==writes);
  Test_Reset(0U); s_echo_during_tx=1U; Test_At(0U); Test_Through(3000U);
  Test_At(3001U); assert(Test_Acks()==1U);
}

static void Test_JsonAckAndSnapshot(void)
{
  AppUploadAck ack; SensorSoilWindowResult result;
  AppSensorSnapshot snapshot;
  char frame[APP_UPLOAD_FRAME_CAPACITY];
  const char *invalid[]={
    "{\"ok\":\"true\",\"device_id\":\"tea_h743_001\",\"seq\":1,\"id\":1}",
    "{\"ok\":1,\"device_id\":\"tea_h743_001\",\"seq\":1,\"id\":1}",
    "{\"ok\":true,\"device_id\":\"tea_h743_001\",\"seq\":\"1\",\"id\":1}",
    "{\"ok\":true,\"device_id\":\"tea_h743_001\",\"seq\":1.0,\"id\":1}",
    "{\"ok\":false,\"ok\":true,\"device_id\":\"tea_h743_001\",\"seq\":1,\"id\":1}",
    "{\"ok\":true \"device_id\":\"tea_h743_001\",\"seq\":1,\"id\":1}",
    "{\"ok\":true,\"device_id\":\"tea_h743_001\",\"seq\":4294967296,\"id\":1}",
    "{\"ok\":true,\"device_id\":\"tea_h743_001\",\"seq\":1,\"id\":0}"};
  const char *ignored[]={"{\"ok\":false,\"device_id\":\"tea_h743_001\",\"seq\":1,\"id\":1}",
    "{\"ok\":true,\"device_id\":\"other\",\"seq\":1,\"id\":1}",
    "{\"ok\":true,\"device_id\":\"tea_h743_001\",\"seq\":2,\"id\":1}","{\"ok\":true}"};
  static const char reordered[]="{\"extra\":{\"ok\":false,\"nested\":[1,2]},\"id\":9223372036854775807,\"seq\":1,\"device_id\":\"tea_h743_001\",\"ok\":true}\r\n";
  unsigned index,reads_before; int length;
  for(index=0U;index<sizeof(invalid)/sizeof(invalid[0]);++index)
    assert(AppUpload_ParseAck(invalid[index],strlen(invalid[index]),1U,&ack)==APP_UPLOAD_ACK_INVALID);
  for(index=0U;index<sizeof(ignored)/sizeof(ignored[0]);++index)
    assert(AppUpload_ParseAck(ignored[index],strlen(ignored[index]),1U,&ack)==APP_UPLOAD_ACK_IGNORED);
  assert(AppUpload_ParseAck(reordered,sizeof(reordered)-1U,1U,&ack)==APP_UPLOAD_ACK_ACCEPTED && ack.id==INT64_MAX);
  Test_Reset(0U); s_raw=0U; Test_At(0U); Test_Through(3000U);
  result=App_GetDiagnostics()->last_window; reads_before=s_soil_reads;
  memset(&snapshot,0,sizeof(snapshot));snapshot.window_end_ms=UINT32_MAX;
  snapshot.soil_moisture_pct.valid=1U;snapshot.soil_moisture_pct.has_sample=1U;
  snapshot.soil_moisture_pct.status="OK";snapshot.soil_moisture_pct.range="LOW";
  snapshot.soil_moisture_pct.value=result.moisture_pct_x100;
  length=AppUpload_Format(frame,sizeof(frame),UINT32_MAX,UINT32_MAX,&snapshot);
  assert(length>0 && s_soil_reads==reads_before && JSON_Validate(frame,(size_t)length)==JSONSuccess);
  assert(strstr(frame,"\"soil_moisture_pct\":{\"value\":0.00") && strstr(frame,"\"range\":\"LOW\""));
  assert(frame[length-2]=='\r' && frame[length-1]=='\n');
  assert(AppUpload_Format(frame,(size_t)length-1U,UINT32_MAX,UINT32_MAX,&snapshot)<0);
  assert(AppUpload_Format(frame,4U,1U,3000U,&snapshot)<0);
  Test_Reset(0U); s_poll_result=HAL_TIMEOUT; s_stop_result=HAL_ERROR;
  Test_At(0U); Test_Through(3000U);
  assert(Test_JsonField("data.soil_moisture_pct.value","null") && Test_JsonField("data.soil_moisture_pct.range",NULL));
  assert(Test_JsonField("data.soil_moisture_pct.status","WINDOW_INSUFFICIENT") && App_GetDiagnostics()->last_window.diagnostics.cleanup_error_count==30U);
  assert(App_GetDiagnostics()->last_window.diagnostics.last_error.status==BSP_ADC_POLL_FAILED);
}

static void Test_WindowScheduling(void)
{
  unsigned before;
  Test_Reset(0U); s_raw=1000U; Test_At(0U); Test_Through(2900U);
  assert(s_soil_reads==30U && !s_uart6_sends);
  s_raw=65535U; Test_At(3000U);
  assert(App_GetDiagnostics()->last_window.adc_raw==1000U && App_GetDiagnostics()->last_window.sample_count==30U);
  Test_Inject(s_ack,s_ack_length); Test_At(3001U); Test_Through(6000U);
  assert(App_GetDiagnostics()->last_window.adc_raw==65535U && strstr(s_transmitted,"\"range\":\"HIGH\""));
  assert(App_GetDiagnostics()->last_window.sample_count==30U);
  /* One late read cannot stand in for the missing 100ms slots. */
  Test_Reset(0U); Test_At(0U); Test_At(2950U); before=s_soil_reads;
  Test_At(3000U); assert(s_soil_reads==before && App_GetDiagnostics()->last_window.valid_count==2U);
  assert(strstr(s_transmitted,"\"status\":\"WINDOW_INSUFFICIENT\""));
  Test_Reset(0U); Test_At(0U); Test_Through(2900U); Test_At(4500U);
  assert(s_uart6_sends==1U && App_GetDiagnostics()->last_window_end_ms==3000U);
  Test_Inject(s_ack,s_ack_length); Test_At(4501U); Test_Through(6000U);
  assert(s_uart6_sends==1U);
  Test_Through(7499U); assert(s_uart6_sends==1U);
  Test_At(7500U); assert(s_uart6_sends==2U && strstr(s_transmitted,"\"t_ms\":6000"));
  Test_Inject(s_ack,s_ack_length); Test_At(7501U);
  Test_Through(9000U); assert(s_uart6_sends==2U);
  Test_Through(10500U); assert(s_uart6_sends==3U && strstr(s_transmitted,"\"t_ms\":9000"));
  Test_Reset(0U); Test_At(0U); Test_At(10000U);
  assert(s_soil_reads==2U && s_uart6_sends==1U);
  assert(App_GetDiagnostics()->completed_windows==3U && AppUpload_GetDiagnostics()->skipped_late==2U);
  assert(App_GetDiagnostics()->last_window_end_ms==9000U && App_GetDiagnostics()->last_window.sample_count==0U);
  Test_At(10000U); assert(s_soil_reads==2U && s_uart6_sends==1U);
  /* Failed samples stay in diagnostics even when quality still passes. */
  Test_Reset(0U); Test_At(0U); Test_Through(2300U);
  s_stop_result=HAL_ERROR; Test_Through(2900U); s_stop_result=HAL_OK; Test_At(3000U);
  assert(App_GetDiagnostics()->last_window.valid_count==24U && App_GetDiagnostics()->last_window.used_count==22U);
  assert(App_GetDiagnostics()->sample_errors==6U && App_GetDiagnostics()->cleanup_errors==6U);
  assert((App_GetDiagnostics()->last_window.diagnostics.cleanup_error_count==6U && App_GetDiagnostics()->last_window.diagnostics.last_error.status==BSP_ADC_STOP_FAILED));
}
