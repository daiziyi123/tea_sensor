static void Test_CircularWindows(void)
{
  SensorWindDirectionWindow window;
  SensorWindDirectionWindowResult result;
  SensorWindDirectionValue value={0};
  unsigned i,n;
  const uint16_t north[3]={35900U,0U,100U},south[3]={17900U,18000U,18100U};
  value.valid=1U;value.range=SENSOR_WIND_DIRECTION_RANGE_OK;
  for(n=0U;n<2U;++n) {
    SensorWindDirection_WindowReset(&window);
    for(i=0U;i<3U;++i) { value.angle_deg_x100=n?south[i]:north[i];SensorWindDirection_WindowAdd(&window,&value); }
    result=SensorWindDirection_WindowFinish(&window,3U,80U);
    assert(result.valid && result.used_count==1U);
    assert(n?result.angle_deg_x100>=17999U && result.angle_deg_x100<=18001U:result.angle_deg_x100<=1U || result.angle_deg_x100>=35999U);
  }
  SensorWindDirection_WindowReset(&window);
  for(i=0U;i<4U;++i) {value.angle_deg_x100=i*9000U;SensorWindDirection_WindowAdd(&window,&value);}
  result=SensorWindDirection_WindowFinish(&window,4U,80U);
  assert(!result.valid && !result.used_count && result.status==SENSOR_WIND_DIRECTION_WINDOW_UNDEFINED);
  for(n=23U;n<=24U;++n) {
    SensorWindDirection_WindowReset(&window);
    for(i=0U;i<30U;++i) {value.valid=i<n;value.angle_deg_x100=0U;SensorWindDirection_WindowAdd(&window,&value);}
    result=SensorWindDirection_WindowFinish(&window,30U,80U);
    assert(result.valid==(n==24U) && result.used_count==(n==24U?22U:0U));
    assert(!result.valid || result.angle_deg_x100==0U);
  }
  value.valid=1U;SensorWindDirection_WindowReset(&window);
  for(i=0U;i<SENSOR_WIND_DIRECTION_WINDOW_CAPACITY+1U;++i) {SensorWindDirection_WindowAdd(&window,&value);}
  result=SensorWindDirection_WindowFinish(&window,30U,80U);
  assert(!result.valid && result.status==SENSOR_WIND_DIRECTION_WINDOW_CAPACITY_EXCEEDED);
  SensorWindDirection_WindowReset(&window);
  result=SensorWindDirection_WindowFinish(&window,SENSOR_WIND_DIRECTION_WINDOW_CAPACITY+1U,80U);
  assert(!result.valid && result.status==SENSOR_WIND_DIRECTION_WINDOW_CAPACITY_EXCEEDED);
}
static void Test_AsyncDtu(void)
{
  char frozen[APP_UPLOAD_FRAME_CAPACITY+2U];
  unsigned before,rx_aborts;
  size_t capacity;
  Test_Reset(0U);s_tx_auto_complete=0U;
  {
    SensorWeatherReply reply;unsigned item;
    memset(&reply,0,sizeof(reply));reply.status=SENSOR_WEATHER_OK;reply.valid_fields=63U;
    reply.value.temperature_c_x10=194;reply.value.humidity_rh_pct_x10=708U;reply.value.light_lux=1249U;
    reply.value.pressure_kpa_x100=10373U;reply.value.pm25_ug_m3=22U;reply.value.pm10_ug_m3=23U;
    for(item=0U;item<4U;++item) {
      SensorWeather_RecordQuery((SensorWeatherItem)item,UINT32_MAX-3U+item,UINT32_MAX-100U);
      SensorWeather_Complete((SensorWeatherItem)item,&reply,UINT32_MAX-100U,UINT32_MAX-100U);
    }
  }
  Test_At(0U);Test_Through(3000U);
  assert(s_active_tx_length>1152U && BspDtu_GetDiagnostics().tx_active);
  memcpy(frozen,s_active_tx,s_active_tx_length);
  before=s_soil_reads;s_raw=123U;Test_At(3100U);
  assert(s_soil_reads==before+1U && !memcmp(frozen,s_active_tx,s_active_tx_length));
  assert(BspDtu_TxBuffer(&capacity)==NULL && capacity==0U);
  Test_Inject(s_ack,s_ack_length);Test_At(3101U);
  assert(!AppUpload_GetDiagnostics()->ack_count);
  s_tick_ms=3200U;Test_TxComplete();Test_At(3200U);
  assert(AppUpload_GetDiagnostics()->ack_count==1U && !BspDtu_GetDiagnostics().tx_active);
  Test_Reset(0U);s_tx_auto_complete=0U;Test_At(0U);Test_Through(3000U);
  s_tick_ms=3900U;Test_TxComplete();Test_At(3900U);
  Test_At(13899U);assert(!AppUpload_GetDiagnostics()->timeouts);
  Test_At(13900U);assert(AppUpload_GetDiagnostics()->timeouts==1U);
  Test_Reset(0U);s_tx_auto_complete=0U;Test_At(0U);Test_Through(3000U);rx_aborts=s_aborts;
  Test_At(4000U);
  assert(AppUpload_GetDiagnostics()->tx_errors==1U && s_tx_aborts==1U && s_aborts==rx_aborts && s_rx_armed);
  s_tx_auto_complete=1U;Test_Through(6000U);
  assert(s_active_tx[0]=='\r' && s_active_tx[1]=='\n');
  assert(s_uart6_sends==2U && s_active_tx_length<sizeof(frozen));
  Test_Reset(0U);s_tx_auto_complete=0U;Test_At(0U);Test_Through(3000U);
  s_abort_tx_result=HAL_ERROR;Test_At(4000U);Test_At(4001U);Test_At(4002U);
  assert(BspDtu_GetDiagnostics().tx_abort_errors==3U && AppUpload_GetDiagnostics()->tx_errors==1U);
  assert(BspDtu_TxBuffer(&capacity)==NULL && s_rx_armed);
}
