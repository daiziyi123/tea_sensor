/* Included by the existing soil HAL harness; never linked into the target. */
static void Test_AddRaw(SensorSoilWindow *window, uint16_t raw)
{
  BspAdcResult sample;
  memset(&sample, 0, sizeof(sample));
  sample.valid = 1U; sample.raw = raw; sample.stop_attempted = 1U;
  SensorSoil_WindowAdd(window, &sample);
}

static void Test_WindowAlgorithm(void)
{
  SensorSoilWindow window;
  SensorSoilWindowResult result;
  BspAdcResult failure;
  unsigned i;
  const uint16_t identical[] = {0U, 436U, 15791U, 31146U, 65535U};
  for (i = 0U; i < sizeof(identical)/sizeof(identical[0]); ++i)
  {
    unsigned n;
    SensorSoil_WindowReset(&window);
    for (n = 0U; n < 30U; ++n) { Test_AddRaw(&window, identical[i]); }
    result = SensorSoil_WindowFinish(&window, 30U, 80U);
    assert(result.status == SENSOR_SOIL_WINDOW_OK && result.used_count == 28U);
    assert(result.adc_raw == identical[i]);
    assert(result.moisture_pct_x100 == SensorSoil_MoisturePercentX100(identical[i]));
  }
  SensorSoil_WindowReset(&window);
  for (i=0U;i<28U;++i) { Test_AddRaw(&window,15791U); }
  Test_AddRaw(&window,0U); Test_AddRaw(&window,65535U);
  result=SensorSoil_WindowFinish(&window,30U,80U);
  assert(result.adc_raw==15791U && result.moisture_pct_x100==5000U && result.used_count==28U);
  /* Repeated extrema remove one of each, not all occurrences. */
  SensorSoil_WindowReset(&window);
  Test_AddRaw(&window,100U); Test_AddRaw(&window,100U);
  Test_AddRaw(&window,200U); Test_AddRaw(&window,200U);
  result=SensorSoil_WindowFinish(&window,4U,80U);
  assert(result.adc_raw==150U && result.used_count==2U);
  /* Mean437.5 rounds raw to438; percent must remain0.00, not0.01. */
  SensorSoil_WindowReset(&window);
  Test_AddRaw(&window,0U); Test_AddRaw(&window,437U);
  Test_AddRaw(&window,438U); Test_AddRaw(&window,65535U);
  result=SensorSoil_WindowFinish(&window,4U,80U);
  assert(result.adc_raw==438U && result.moisture_pct_x100==0U);
  /* Clamp AFTER averaging raw, not before. */
  SensorSoil_WindowReset(&window);
  Test_AddRaw(&window,0U); Test_AddRaw(&window,0U);
  Test_AddRaw(&window,31146U); Test_AddRaw(&window,65535U);
  result=SensorSoil_WindowFinish(&window,4U,80U);
  assert(result.adc_raw==15573U && result.moisture_pct_x100==4929U);
  for (i=0U;i<2U;++i)
  {
    unsigned n; uint16_t edge=i?31146U:436U;
    SensorSoil_WindowReset(&window); Test_AddRaw(&window,0U);
    for(n=0U;n<3U;++n) { Test_AddRaw(&window,edge); }
    Test_AddRaw(&window,(uint16_t)(i?edge+1U:edge-1U)); Test_AddRaw(&window,65535U);
    result=SensorSoil_WindowFinish(&window,6U,80U);
    assert(result.adc_raw==edge && result.range==(i?SENSOR_SOIL_RANGE_HIGH:SENSOR_SOIL_RANGE_LOW));
    SensorSoil_WindowReset(&window); Test_AddRaw(&window,0U);
    Test_AddRaw(&window,(uint16_t)(edge-1U)); Test_AddRaw(&window,(uint16_t)(edge+1U)); Test_AddRaw(&window,65535U);
    result=SensorSoil_WindowFinish(&window,4U,80U);
    assert(result.adc_raw==edge && result.range==SENSOR_SOIL_RANGE_OK);
  }
  memset(&failure,0,sizeof(failure)); failure.status=BSP_ADC_POLL_FAILED;
  failure.hal_status=BSP_ADC_HAL_TIMEOUT; failure.stop_attempted=1U; failure.stop_status=BSP_ADC_HAL_ERROR;
  for(i=23U;i<=24U;++i)
  {
    unsigned n; SensorSoil_WindowReset(&window);
    for(n=0U;n<i;++n) { Test_AddRaw(&window,0U); }
    for(n=i;n<30U;++n) { SensorSoil_WindowAdd(&window,&failure); }
    result=SensorSoil_WindowFinish(&window,30U,80U);
    assert(result.sample_count==30U && result.valid_count==i);
    assert(result.status==(i==24U?SENSOR_SOIL_WINDOW_OK:SENSOR_SOIL_WINDOW_INSUFFICIENT));
    assert(result.used_count==(i==24U?22U:0U));
    assert(result.diagnostics.error_counts[BSP_ADC_POLL_FAILED]==30U-i);
    assert(result.diagnostics.cleanup_error_count==30U-i && result.diagnostics.last_error.hal_status==BSP_ADC_HAL_TIMEOUT);
  }
  SensorSoil_WindowReset(&window);
  for(i=0U;i<3U;++i)
  {
    result=SensorSoil_WindowFinish(&window,1U,80U);
    assert(result.status==SENSOR_SOIL_WINDOW_INSUFFICIENT && result.used_count==0U);
    Test_AddRaw(&window,0U);
  }
  SensorSoil_WindowReset(&window);
  for(i=0U;i<30U;++i) { SensorSoil_WindowAdd(&window,&failure); }
  result=SensorSoil_WindowFinish(&window,30U,80U);
  assert(!result.valid_count && !result.used_count && result.status==SENSOR_SOIL_WINDOW_INSUFFICIENT);
  failure.status=BSP_ADC_STOP_FAILED; failure.hal_status=BSP_ADC_HAL_ERROR;
  SensorSoil_WindowReset(&window); SensorSoil_WindowAdd(&window,&failure);
  assert(window.diagnostics.error_counts[BSP_ADC_STOP_FAILED]==1U && !window.valid_count);
  SensorSoil_WindowReset(&window);
  for(i=BSP_ADC_CAL_FAILED;i<=BSP_ADC_OUT_OF_RANGE;++i)
  {
    failure.status=(BspAdcStatus)i;
    SensorSoil_WindowAdd(&window,&failure);
    assert(window.diagnostics.error_counts[i]==1U);
  }
  assert(window.sample_count==5U && window.valid_count==0U);
  SensorSoil_WindowReset(&window); window.sample_count=window.valid_count=UINT32_MAX;
  window.raw_min=window.raw_max=65535U; window.raw_sum=(uint64_t)UINT32_MAX*65535U;
  result=SensorSoil_WindowFinish(&window,30U,80U);
  assert(result.adc_raw==65535U && result.moisture_pct_x100==10000U);
}
