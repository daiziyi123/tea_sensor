#ifndef AD3_CASES_H
#define AD3_CASES_H

/* Exercise production App/Bsp and USART2 retarget, not a second sampler. */
static void Test_Ad3SelectionAndFaults(void)
{
  BspAdcResult adc;
  unsigned before;
  Test_Reset(0U); Test_At(0U); Test_At(100U);
  assert(s_config_calls==8U && s_cal_calls==1U);
  assert(s_channel_history[0]==ADC_CHANNEL_5 && s_channel_history[1]==ADC_CHANNEL_3);
  assert(s_channel_history[2]==ADC_CHANNEL_19 && s_channel_history[3]==ADC_CHANNEL_18);
  assert(s_channel_history[4]==ADC_CHANNEL_5 && s_channel_history[5]==ADC_CHANNEL_3);
  assert(s_channel_history[6]==ADC_CHANNEL_19 && s_channel_history[7]==ADC_CHANNEL_18);
  assert(App_GetDiagnostics()->last_round.soil.adc.raw==15791U);
  assert(App_GetDiagnostics()->last_round.wind.adc.raw==12345U);
  assert(App_GetDiagnostics()->last_round.ad3.raw==23456U);
  s_ad3_config_result=HAL_BUSY; adc=BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_DIRECTION_AD3);
  assert(!adc.valid && !adc.raw && adc.status==BSP_ADC_START_FAILED && adc.stage==BSP_ADC_STAGE_CONFIG);
  assert(adc.config_status==BSP_ADC_HAL_BUSY && adc.stop_attempted && adc.stop_status==BSP_ADC_HAL_OK);
  s_ad3_config_result=HAL_OK; s_ad3_start_result=HAL_ERROR;
  adc=BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_DIRECTION_AD3);
  assert(!adc.valid && adc.stage==BSP_ADC_STAGE_START && adc.hal_status==BSP_ADC_HAL_ERROR);
  s_ad3_start_result=HAL_OK; s_ad3_poll_result=HAL_TIMEOUT; s_ad3_stop_result=HAL_ERROR;
  adc=BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_DIRECTION_AD3);
  assert(!adc.valid && adc.stage==BSP_ADC_STAGE_POLL && adc.hal_status==BSP_ADC_HAL_TIMEOUT);
  assert(adc.stop_status==BSP_ADC_HAL_ERROR && adc.stop_attempted);
  /* Shared hardware unavailable: all three return the actual prepare failure. */
  s_prepare_result=HAL_TIMEOUT; before=s_config_calls; Test_At(1000U);
  assert(!App_GetDiagnostics()->last_round.soil.adc.valid && !App_GetDiagnostics()->last_round.wind.adc.valid);
  assert(!App_GetDiagnostics()->last_round.ad3.valid && s_config_calls==before);
  assert((!App_GetDiagnostics()->last_round.wind_direction.valid && App_GetDiagnostics()->last_round.ad3.stage==BSP_ADC_STAGE_PREPARE && App_GetDiagnostics()->last_round.ad3.prepare_status==BSP_ADC_HAL_TIMEOUT));
  s_prepare_result=HAL_OK; s_ad3_poll_result=HAL_OK;
  adc=BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_DIRECTION_AD3);
  assert(!adc.valid && adc.status==BSP_ADC_STOP_FAILED && adc.stage==BSP_ADC_STAGE_STOP);
  s_ad3_stop_result=HAL_OK; s_ad3_raw=65536U;
  adc=BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_DIRECTION_AD3);
  assert(!adc.valid && adc.status==BSP_ADC_OUT_OF_RANGE && adc.stage==BSP_ADC_STAGE_VALUE);
  s_ad3_raw=0U; adc=BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_DIRECTION_AD3);
  assert(adc.valid && adc.raw==0U && adc.status==BSP_ADC_OK);
  s_cal_result=HAL_ERROR; BspAdc_Init(); before=s_config_calls;
  adc=BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_DIRECTION_AD3);
  assert(!adc.valid && adc.stage==BSP_ADC_STAGE_CALIBRATION && s_config_calls==before);
  /* A newly read value with failed cleanup is still NA, never the prior success. */
  Test_Reset(0U); Test_At(0U); s_ad3_stop_result=HAL_ERROR; s_ad3_raw=999U; Test_At(1000U);
  assert((!App_GetDiagnostics()->last_round.wind_direction.valid && App_GetDiagnostics()->last_round.ad3.stage==BSP_ADC_STAGE_STOP && App_GetDiagnostics()->last_round.ad3.stop_status==BSP_ADC_HAL_ERROR));
  assert(App_GetDiagnostics()->last_round.soil.adc.valid && App_GetDiagnostics()->last_round.wind.adc.valid);
}

static void Test_Ad3WindowAndPrinting(void)
{
  const AppDiagnostics *diagnostics;
  unsigned tick, before;
  Test_Reset(0U);
  for(tick=0U;tick<3000U;tick+=100U)
  {
    s_ad3_raw=tick==0U?0U:tick==2900U?65535U:1000U;
    Test_At(tick);
  }
  s_ad3_raw=7U; Test_At(3000U); diagnostics=App_GetDiagnostics();
  assert(diagnostics->last_ad3_window.sample_count==30U && diagnostics->last_ad3_window.valid_count==30U);
  assert(diagnostics->last_ad3_window.raw_min==0U && diagnostics->last_ad3_window.raw_max==65535U);
  assert(diagnostics->last_ad3_window.raw_sum==93535U); /* Includes both extremes. */
  assert((diagnostics->last_window_end_ms==3000U && diagnostics->last_ad3_window.raw_sum==93535U && !strstr(s_console,"AD3_WINDOW")));
  assert((App_GetDiagnostics()->last_round.wind_direction.valid && App_GetDiagnostics()->last_round.wind_direction.angle_deg_x100==0U));
  assert(Test_JsonField("schema_version","2") && App_GetDiagnostics()->last_window.adc_raw==15791U);
  assert(!strstr(s_transmitted,"AD3") && !strstr(s_transmitted,"ad3") && !strstr(s_transmitted,"23456"));
  assert(diagnostics->last_wind_window.raw_mean==12345U && diagnostics->last_wind_window.value.valid);
  before=s_ad3_reads; Test_At(3001U); assert(s_ad3_reads==before && !s_console_length);
  Test_Through(6000U); diagnostics=App_GetDiagnostics();
  assert(diagnostics->last_ad3_window.raw_sum==210U && diagnostics->last_ad3_window.sample_count==30U);
  assert((diagnostics->last_ad3_window.raw_min==7U && diagnostics->last_ad3_window.raw_max==7U && diagnostics->last_ad3_window.raw_sum==7U*diagnostics->last_ad3_window.valid_count));
  assert(s_uart6_sends==1U && AppUpload_GetDiagnostics()->skipped_busy==1U); /* No ACK; sampling continues. */
  Test_Reset(0U); s_ad3_raw=0U; Test_At(0U); Test_Through(3000U);
  assert(((App_GetDiagnostics()->last_round.wind_direction.valid && App_GetDiagnostics()->last_round.wind_direction.angle_deg_x100==0U) && App_GetDiagnostics()->last_ad3_window.raw_sum==0U && App_GetDiagnostics()->last_ad3_window.valid_count==30U));
  Test_Reset(0U); s_ad3_raw=65535U; Test_At(0U); Test_Through(3000U);
  assert((App_GetDiagnostics()->last_ad3_window.raw_sum==65535ULL*App_GetDiagnostics()->last_ad3_window.valid_count && (App_GetDiagnostics()->last_round.wind_direction.angle_deg_x100==36000U)));
  /* A single valid value is a raw calibration observation, no 80% threshold. */
  Test_Reset(0U); s_ad3_raw=42U; Test_At(0U); s_ad3_poll_result=HAL_TIMEOUT; Test_Through(3000U);
  assert(App_GetDiagnostics()->last_ad3_window.valid_count==1U);
  assert((App_GetDiagnostics()->last_ad3_window.raw_sum==42U && App_GetDiagnostics()->last_ad3_window.error_counts[BSP_ADC_POLL_FAILED]==29U));
  assert((!App_GetDiagnostics()->last_round.wind_direction.valid && App_GetDiagnostics()->last_round.ad3.stage==BSP_ADC_STAGE_POLL && App_GetDiagnostics()->last_round.ad3.hal_status==BSP_ADC_HAL_TIMEOUT));
  assert(App_GetDiagnostics()->last_ad3_window.error_counts[BSP_ADC_POLL_FAILED]==29U && App_GetDiagnostics()->sample_errors==0U);
  Test_Reset(0U); s_ad3_poll_result=HAL_TIMEOUT; s_ad3_stop_result=HAL_ERROR;
  Test_At(0U); Test_Through(3000U); diagnostics=App_GetDiagnostics();
  assert(diagnostics->last_ad3_window.valid_count==0U && diagnostics->last_ad3_window.raw_sum==0U);
  assert(diagnostics->last_ad3_window.cleanup_errors==30U && diagnostics->ad3_sample_errors==31U);
  assert(diagnostics->last_window.valid_count==30U && diagnostics->last_wind_window.valid_count==30U);
  assert((diagnostics->last_ad3_window.valid_count==0U && diagnostics->last_ad3_window.cleanup_errors==30U));
  assert((diagnostics->last_ad3_window.last_error.stage==BSP_ADC_STAGE_POLL && diagnostics->last_ad3_window.last_error.hal_status==BSP_ADC_HAL_TIMEOUT && diagnostics->last_ad3_window.last_error.stop_status==BSP_ADC_HAL_ERROR));
  s_ad3_poll_result=s_ad3_stop_result=HAL_OK; s_ad3_raw=88U; Test_Through(6000U);
  assert(App_GetDiagnostics()->last_ad3_window.valid_count==29U && App_GetDiagnostics()->last_ad3_window.raw_sum==88U*29U);
  /* AD0/AD2 failures cannot contaminate AD3; ADC config/start diagnostics persist. */
  Test_Reset(0U); s_config_result=HAL_ERROR; s_wind_poll_result=HAL_TIMEOUT; s_ad3_config_result=HAL_BUSY;
  Test_At(0U); Test_Through(3000U);
  assert(App_GetDiagnostics()->last_ad3_window.config_errors==30U);
  assert((!App_GetDiagnostics()->last_round.wind_direction.valid && App_GetDiagnostics()->last_round.ad3.stage==BSP_ADC_STAGE_CONFIG && App_GetDiagnostics()->last_round.ad3.config_status==BSP_ADC_HAL_BUSY));
  s_ad3_config_result=HAL_OK; s_ad3_start_result=HAL_BUSY; Test_At(4000U);
  assert((!App_GetDiagnostics()->last_round.wind_direction.valid && App_GetDiagnostics()->last_round.ad3.stage==BSP_ADC_STAGE_START && App_GetDiagnostics()->last_round.ad3.hal_status==BSP_ADC_HAL_BUSY));
  s_ad3_start_result=HAL_OK; Test_At(5000U);
  assert(App_GetDiagnostics()->last_round.ad3.valid && !App_GetDiagnostics()->last_round.soil.adc.valid && !App_GetDiagnostics()->last_round.wind.adc.valid);
}

static void Test_Ad3BoundaryAndRecovery(void)
{
  const AppDiagnostics *diagnostics;
  unsigned before;
  Test_Reset(0U); s_soil_duration_ms=2U; s_wind_duration_ms=3U; s_ad3_duration_ms=7U;
  Test_At(1000U); diagnostics=App_GetDiagnostics();
  assert(diagnostics->last_round.ad3_read_start_ms==1005U && diagnostics->last_round.ad3_read_end_ms==1012U);
  assert(diagnostics->last_round.pair_span_ms==5U && diagnostics->last_round.round_span_ms==12U);
  assert(diagnostics->last_round.ad3_read_start_ms==1005U); /* Sample timestamp, not printf-time 1012. */
  /* Existing sample may be printed at 1s without a new read if not yet due. */
  Test_Reset(0U); Test_At(950U); before=s_ad3_reads; Test_At(1000U);
  assert(s_ad3_reads==before && (App_GetDiagnostics()->last_round.ad3_read_start_ms==950U && (App_GetDiagnostics()->last_round.wind_direction.angle_deg_x100==24959U)));
  Test_Reset(0U); s_ad3_duration_ms=10U; s_ad3_raw=123U; Test_At(2995U); Test_At(3005U);
  assert(App_GetDiagnostics()->last_ad3_window.sample_count==1U && App_GetDiagnostics()->last_ad3_window.raw_sum==123U);
  assert(App_GetDiagnostics()->last_window.sample_count==1U && App_GetDiagnostics()->last_wind_window.sample_count==1U);
  assert(App_GetDiagnostics()->last_round.round_t_ms==2995U && App_GetDiagnostics()->last_round.ad3_read_end_ms==3005U);
  Test_Reset(UINT32_MAX-1499U); s_ad3_raw=500U; Test_At(UINT32_MAX-1499U);
  Test_At((uint32_t)(UINT32_MAX-1499U+2900U)); s_ad3_raw=900U;
  Test_At((uint32_t)(UINT32_MAX-1499U+3000U)); diagnostics=App_GetDiagnostics();
  assert(diagnostics->last_window_end_ms==1500U && diagnostics->last_ad3_window.sample_count==2U);
  assert(diagnostics->last_ad3_window.raw_sum==1000U && diagnostics->last_round.ad3.raw==900U);
  Test_Reset(0U); Test_At(0U); Test_At(10000U); diagnostics=App_GetDiagnostics(); before=s_ad3_reads;
  assert(before==2U && diagnostics->last_ad3_window.sample_count==0U && AppUpload_GetDiagnostics()->skipped_late==2U);
  assert((diagnostics->last_window_end_ms==9000U && diagnostics->last_ad3_window.valid_count==0U && !strstr(s_console,"AD3_WINDOW")));
  Test_At(10000U); assert(s_ad3_reads==before); /* No catch-up sampling. */
}
#endif
