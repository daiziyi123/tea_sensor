# tea_sense 当前架构
更新：2026-11-15。权威交付索引[共同Docs](../../Docs/README.md)，参数/协议分别见[标定](../../Docs/device_calibration_register.md)和[V2](../../Docs/protocol_v2.md)。

| 所有者 | 实际职责/API |
|---|---|
| app_main | 初始化、100ms四路采集、同窗结算、私有AppSensorSnapshot、气象已完成结果映射、直接printf |
| app_data.h | App范围唯一中立交换类型AppSensorValue/AppSensorSnapshot，只有stdint；无.c、HAL/Sensors/Bsp依赖、无可写extern全局帧 |
| app_upload | Init/Process/Submit/GetDiagnostics；唯一节流/TX待完成/RX拼行/早ACK/10秒等待/跳窗诊断；Format/ParseAck仍纯入口 |
| app_weather | 固定气象事务/间隔/退避，不经上传启动采样；版本启动不做在线探测 |
| Sensors | 原换算、独立窗口、圆周统计、气象流式解析/字段质量/最近完成缓存；不反向依赖App |
| Bsp | ADC/UART硬件、缓冲、失败/恢复；bsp_uart_irq固定huart3/4/6路由，三种HAL回调各唯一 |

调用：main→App_Init/Process→采集/结算私有快照→const Submit同步序列化→Bsp唯一4096字节TX缓冲→HAL IT TX/TC→AppUpload_Process→ACK。上传不持有调用方指针，不复制整份采样诊断、不新增TX副本；ADC/错误仍在各原诊断，上传诊断只由AppUpload_GetDiagnostics读取。App_GetDiagnostics保留采样/console，类型在app_diagnostics.h，非全工程总头。
单缓冲所有权：IDLE才可写；STARTING/SENDING/COMPLETE/FAILED/BLOCKED都不可写。HAL启动期间IRQ保持开放，ISR锁存结果；错误在消费前优先于TC。主循环消费一次，重新取tick后算ACK年龄。Abort失败三次锁定，60000ms局部恢复，确认安全停止后给下一新窗CRLF边界；RX继续，不以ACK超时重置UART/整机。ADC仅初始校准失败时每60000ms先Stop确认再校准，成功正常路径只一次。间隔是新增工程策略，实板待验证。
三层仍各仅Inc/Src；HAL操作只在Bsp和原生成层；无动态内存、RTOS/DMA、注册/日志框架。Core/Drivers/.ioc/启动配置及端点不变。
coreJSON已原字节迁入Middlewares/Third_Party/coreJSON，MDK独立ThirdParty/coreJSON分组，App只由app_upload.c包含core_json.h；不向公开业务头传播库类型。权威许可/版本/来源限制见[库README](../Middlewares/Third_Party/coreJSON/README.md)，不声明未经对照上游的“完全未修改”。
app_version.h定义固件/数字schema/参数集唯一来源；一次电脑口UTF-8启动摘要，不向DTU插入文字或JSON额外字段。标准Arm C库，无float printf/半主机；失败不重印，周期仍仅中文物理量。
