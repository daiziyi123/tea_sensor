# Tea Sense 本地工程
更新：2026-11-15。当前固件0.9.1-dev、协议V2、标定参数集baseline-2，权威来源tea_sense/App/Inc/app_version.h。雨强已接入十一项链路，尚未实板验收。

- 固件tea_sense；本地服务器和原生网页tea_sense_server；前端随服务器提供，无需npm启动。
- 网页http://127.0.0.1:8000，DTU TCP127.0.0.1:9000。启动根start_server.cmd；已有实例不要重复启动。
- **升级先服务器、后手动下载固件**：源码已更新，运行中的旧服务器本轮未自动重启。按[构建/运维步骤](Docs/build_operations.md)停止唯一旧实例、重新启动并核对十一项，再手动Rebuild/下载固件。
- [交付索引](Docs/README.md)、[雨强实现/验证](Docs/rain_integration_validation.md)、[接线](Docs/wiring_power_interfaces.md)、[标定来源](Docs/device_calibration_register.md)、[协议](Docs/protocol_v2.md)、[现场验收](Docs/acceptance_records.md)。
- 新源码包及清单见Docs/rain_release_record.json、Releases/rain-source-preview-20261115。旧包、备份和历史日志保留。公开包排除私有配置、真实数据库和HEX/AXF。
- 本轮不部署云端、不自动烧录、不覆盖真实数据库；气体仍暂停，无累计雨量。实板、4G、重启/断网、24～72小时和实际降雨精度仍待执行。
