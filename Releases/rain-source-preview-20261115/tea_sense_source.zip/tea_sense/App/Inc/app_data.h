#ifndef APP_DATA_H
#define APP_DATA_H
#include <stdint.h>

#define APP_SENSOR_METRIC_COUNT 11U

/* Fixed eleven-metric V2 wire contract, not a sensor registry. Values use the field's fixed
 * scale (x100, x10 or integer), and source ticks are never UTC timestamps. */
typedef struct
{
  int64_t value;
  uint32_t sample_seq, sample_t_ms;
  /* Read-only strings must outlive submission, normally string literals. */
  const char *status, *range;
  uint8_t valid, has_sample;
} AppSensorValue;
typedef struct
{
  uint32_t window_seq, window_end_ms;
  /* x100: percent, m/s, degrees, dimensionless pH, respectively. */
  AppSensorValue soil_moisture_pct, wind_speed_mps, wind_direction_deg, soil_ph;
  AppSensorValue rain_intensity_mm_min; /* mm/min x100; not accumulated mm. */
  /* x10: deg C and %RH; integers: lux and both ug/m3; pressure is kPa x100. */
  AppSensorValue temperature_c, air_humidity_rh_pct, light_lux, pressure_kpa, pm25_ug_m3, pm10_ug_m3;
} AppSensorSnapshot;


#endif
