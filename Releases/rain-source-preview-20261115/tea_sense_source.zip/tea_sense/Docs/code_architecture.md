# tea_sense 当前架构
更新：2026-11-15。权威交付索引[共同Docs](../../Docs/README.md)，参数/协议分别见[标定](../../Docs/device_calibration_register.md)和[V2](../../Docs/protocol_v2.md)。

| 所有者 | 实际职责/API |
|---|---|
| app_main | 初始化、100ms五路采集（5→3→19→18→15），五路同窗结算、私有AppSensorSnapshot；相同雨强结果用于中文printf与上传，AD5原始故障仅留采样诊断 |
| app_data.h | App范围唯一中立交换类型AppSensorValue/AppSensorSnapshot，只有stdint；无.c、HAL/Sensors/Bsp依赖、无可写extern全局帧 |
| app_upload | Init/Process/Submit/GetDiagnostics；唯一节流/TX待完成/RX拼行/早ACK/10秒等待/跳窗诊断；Format/ParseAck仍纯入口 |
| app_weather | 固定气象事务/间隔/退避，不经上传启动采样；版本启动不做在线探测 |
| Sensors | 原换算、独立窗口、圆周统计、气象流式解析/字段质量/最近完成缓存；不反向依赖App |
| Bsp | ADC/UART硬件、缓冲、失败/恢复；bsp_uart_irq固定huart3/4/6路由，三种HAL回调各唯一 |

调用：main→App_Init/Process→采集/结算私有快照→const Submit同步序列化→Bsp唯一4096字节TX缓冲→HAL IT TX/TC→AppUpload_Process→ACK。上传不持有调用方指针，不复制整份采样诊断、不新增TX副本；ADC/错误仍在各原诊断，上传诊断只由AppUpload_GetDiagnostics读取。App_GetDiagnostics保留采样/console，类型在app_diagnostics.h，非全工程总头。
单缓冲所有权：IDLE才可写；STARTING/SENDING/COMPLETE/FAILED/BLOCKED都不可写。HAL启动期间IRQ保持开放，ISR锁存结果；错误在消费前优先于TC。主循环消费一次，重新取tick后算ACK年龄。Abort失败三次锁定，60000ms局部恢复，确认安全停止后给下一新窗CRLF边界；RX继续，不以ACK超时重置UART/整机。ADC仅初始校准失败时每60000ms先Stop确认再校准，成功正常路径只一次。间隔是新增工程策略，实板待验证。
三层仍各仅Inc/Src；HAL操作只在Bsp和原生成层；无动态内存、RTOS/DMA、注册/日志框架。Core/Drivers/.ioc/启动配置及原四路端点不变，雨强新增独立端点。
coreJSON已原字节迁入Middlewares/Third_Party/coreJSON，MDK独立ThirdParty/coreJSON分组，App只由app_upload.c包含core_json.h；不向公开业务头传播库类型。权威许可/版本/来源限制见[库README](../Middlewares/Third_Party/coreJSON/README.md)，不声明未经对照上游的“完全未修改”。
app_version.h定义固件/数字schema/参数集唯一来源；一次电脑口UTF-8启动摘要，不向DTU插入文字或JSON额外字段。标准Arm C库，无float printf/半主机；失败不重印，周期仍仅中文物理量。

雨强接入：AD5枚举和Bsp ADC不变，App_AcquireRound中现有一次Channel15读数同时更新最新硬件诊断和SensorRainWindow；SensorRain只做转换/WindowReset/Add/Finish，不调用HAL/printf或依赖App。App_CloseWindow统一五路边界/迟到丢窗规则，参数与有效门槛来自已有配置。AppDiagnostics.last_rain_window保存计数、sum/extrema、去两点后的sum/used_count、值/范围及独立主故障/prepare/config/cleanup信息；不把硬件诊断塞入中立上传模型。
AppSensorSnapshot新增唯一rain_intensity_mm_min，value按mm/min×100，app_upload按100输出物理数值；新帧十一项，原十键语义和TX/ACK生命周期不变。删除AD5_SAMPLE及1000ms打印配置，主循环三秒同窗中文行追加降雨强度，没有额外打印/采样/上传任务。一次版本摘要0.9.1-dev/V2/baseline-2。MDK新增sensor_rain.c仅一次；旧受控恢复及coreJSON字节保持。接线仍AD5/PA3/ADC1 CH15、Analog/NOPULL，未手改生成区。
后端严格可选雨强扩展，通用measurements/schema2复用，旧十项缺失为NO_DATA且无历史点；前端五主卡+六气象卡，雨强独立mm/min量程。当前证据见[雨强验证](../../Docs/rain_integration_validation.md)，旧raw阶段材料仅历史。
