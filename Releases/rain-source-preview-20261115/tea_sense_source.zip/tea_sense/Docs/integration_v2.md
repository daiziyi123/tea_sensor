# 当前整合与稳定化入口
更新：2026-11-15。早期标定/一秒raw/单土壤输出材料保留为历史，当前事实采用共同根[交付索引](../../Docs/README.md)。
- [接线/供电与待确认硬件](../../Docs/wiring_power_interfaces.md)
- [唯一当前端点/公式/来源登记](../../Docs/device_calibration_register.md)
- [唯一当前V2字段、单位、身份/年龄、ACK与USART2格式](../../Docs/protocol_v2.md)
- [工具版本、构建/手动下载、本地运维、备份恢复、发布工具](../../Docs/build_operations.md)
- [稳定化/四项补充核对、软件结果与待执行现场验收](../../Docs/acceptance_records.md)
- [三层调用与所有权](code_architecture.md)

保持原四路窗口/质量与端点，风向圆周；新增同窗雨强，默认MET四组，气体暂停。AppUpload唯一发送/ACK状态，Bsp短临界区、单缓冲与低频受控恢复，核心算法与外部合同不变。一次启动版本摘要是周期物理值之外的唯一例外（已移除AD5_SAMPLE），不输出未经证明的在线结论。
人工对齐：用户确认供电/线束后先重启唯一更新后服务器并确认十一项，再手动下载本次固件，USART2 UTF-8/115200观察同窗五路，比较串口→ACK诊断→脱敏API→网页→CSV的值、单位、源seq/tick与年龄；气象缓存不重复加点，新查询同值正常加点，断线/失败不假零。具体现场记录仍待执行，本轮软件仿真不冒充实板。
历史整合日志位于本工程Docs/validation；本次雨强证据位于共同根Docs/rain_*.log及rain_test_results.json，旧release_*保留历史，不改历史日志时间或结果。
