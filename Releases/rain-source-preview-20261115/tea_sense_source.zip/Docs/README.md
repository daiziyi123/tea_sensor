# Tea Sense 交付初稿索引
更新：2026-11-15；固件0.9.1-dev / schema_version=2 / baseline-2。当前雨强增量替代旧“AD5仅raw、雨量暂停、固定十项”限制，已完成原地代码接入；没有使用旧ZIP覆盖工作区。

| 文档 | 内容 |
|---|---|
| [接线/供电](wiring_power_interfaces.md) | AD5/PA3/ADC1 CH15及现有接口；供电/线束待确认 |
| [设备/标定登记](device_calibration_register.md) | 唯一端点表、日志来源、0～5V→0～8mm/min及精度限制 |
| [V2协议](protocol_v2.md) | 十一项新帧、兼容十项旧帧、NO_DATA/null、身份/年龄/ACK |
| [构建运维](build_operations.md) | 工具、先服务器后手动固件、备份/恢复及源码发布 |
| [验收记录](acceptance_records.md) | 历史稳定化与本次软件结果；现场任务保持待执行 |
| [本次雨强验证](rain_integration_validation.md) | 文件映射、执行范围、打印、测试证据和剩余项 |

当前五主指标：土壤相对湿润度、风速、风向参考角度、土壤pH、降雨强度；六气象指标：气温/湿度/光照/气压/PM2.5/PM10。保留App/Sensors/Bsp职责、故障恢复、单缓冲TX和第三方库隔离；没有增加RTOS/DMA/累计量或气体功能。

证据区分：**代码核对**为当前软件事实；**用户提供日志/历史实测**为有来源的输入；**资料记录**未经本轮重测；硬件信息不足为**待确认**；未上板/持续运行的测试为**待执行**。显示两位小数不代表实物准确，不得凭ADC成功或ACK成功签收探头精度。

本次执行命令、工作目录、退出码及时间见rain_test_results.json；逐文件实际变更见rain_changed_files.json；保护审计见rain_protection_audit.json；当前构建/源码身份见rain_release_record.json和rain_source_manifest.sha256。新源码预览包rain-source-preview-20261115不含真实配置/数据库/固件二进制，密钥私下交接；无Git仓库不捏造提交身份。

release_record.json、release_*.log、source-preview-20261115属于前次稳定化快照；ad5_raw_validation.md及ad5_validation.json属于本次之前的raw阶段；原始日志和备份未批量改写。执行前备份由../rain_backup_path.txt定位，含私有配置，仅本机保管。本轮没有云端部署、自动烧录、覆盖真实库或重启生产实例。升级须先人工重启更新后的服务器、确认十一项，再手动下载新固件。
