# Tea Sense 稳定化交付初稿
交付初稿更新：2026-11-15，版本：0.9.0-dev。本文件是待硬件签收的交付初稿。
证据标记：**[代码核对]** 为本机修复后源码事实；**[历史用户实测]** 为已有带来源记录；**[资料记录]** 为附件/旧手册记载，未经本轮重测；**[待确认]** 为硬件信息不足；**[待执行]** 为尚未实施测试。

本轮以本地最新tea_sense及tea_sense_server为准；已读取两份附件并逐项校订，不用旧ZIP覆盖。两个目录均无Git仓库，未初始化/提交；版本由source_manifest.sha256与release_record.json对应。附件原件保留在Downloads，共同根目录有执行时副本。源码执行前副本位置见../stabilization_backup_path.txt（备份含私有配置，仅本机私下保存）。

| 文档 | 使用目的 |
|---|---|
| [wiring_power_interfaces.md](wiring_power_interfaces.md) | 接线、供电、电平、引脚与待确认事项 |
| [device_calibration_register.md](device_calibration_register.md) | 型号/编号、已确认电气端点、来源和精度限制 |
| [protocol_v2.md](protocol_v2.md) | 十项V2、status/null/范围、ACK与年龄 |
| [build_operations.md](build_operations.md) | 工具版本、构建、手动下载、启动、备份/恢复、升级 |
| [acceptance_records.md](acceptance_records.md) | 本轮软件证据与分开的待执行实板验收 |

[代码核对] 已实现十项：土壤相对湿润度、风速、风向参考角度、土壤pH、气温、空气湿度、光照、气压、PM2.5、PM10；默认停雨量和CO₂/O₂。App/Sensors/Bsp保持Inc/Src平铺，无RTOS/DMA/动态分配/注册机制。原系数、硬件配置、Core/Drivers/.ioc、私有配置、标准库/无半主机合同保持，保护审计见stabilization_protection_audit.json。

本轮修复两处TX/ACK竞态，移交上传职责和UART分发，并新增局部故障恢复。未部署云端、改DTU目标/cpolar/端口、烧录或操作生产恢复。服务器框架/数据库模型/前端保持；只新增独立备份工具与临时库测试。网页仍http://127.0.0.1:8000，TCP9000，未为写文档重复启动监听。

**不能据本初稿认定探头准确或十项实物已签收。** 当前无boot_id/离线补传；断网历史可能缺失，无boot_id重启推断有局限。真实供电/线束、雨量接口分辨率、风场/pH精度/对北、实际ISR和栈高水位、长时间稳定性待确认或待执行。没有填写虚构操作者、签名、起止时间或“全通过”。

公开交付规则：只按source_manifest发布源码和脱敏文档；app_secrets.h、.env、真实数据库/WAL/SHM、备份、IMEI/ICCID不得进入公开包/示例。密钥单独私下交接，不从测试日志复制。含真实token的HEX/AXF也仅私下交付，不当公共示例公开。本轮未制作公共压缩包。

四项补充及前一份任务核对见acceptance_records.md；当前类型为AppSensorValue/AppSensorSnapshot，coreJSON的版本/许可权威入口为../tea_sense/Middlewares/Third_Party/coreJSON/README.md。启动摘要仅一次，不作为传感器在线判断。

源码预览包包含本次release_*.log指定证据；stabilization_*、历史Docs/validation和工作区备份保持原处，不全部打入源码包。压缩包自身SHA256在旁置文件，不递归写入包内清单；release_record.json给出构建哈希和包路径。
