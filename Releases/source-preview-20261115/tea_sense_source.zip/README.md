# Tea Sense 本地工程
交付初稿更新：2026-11-15。固件0.9.0-dev、协议V2、参数集baseline-1由tea_sense/App/Inc/app_version.h统一定义，尚未实板验收。

- 固件：tea_sense；本地服务器与网页：tea_sense_server。
- 启动：双击根start_server.cmd或在终端运行它；已有实例时不要重复启动。
- 网页：http://127.0.0.1:8000；DTU TCP：127.0.0.1:9000；前端随服务器提供，无需npm启动。
- [交付索引与边界](Docs/README.md)、[接线/供电](Docs/wiring_power_interfaces.md)、[设备/标定](Docs/device_calibration_register.md)、[V2协议](Docs/protocol_v2.md)、[构建/运维/发布](Docs/build_operations.md)、[验收记录](Docs/acceptance_records.md)。
- 发布工具：Tools/package_release.py；实际源码预览包和哈希见Docs/release_record.json。配置需私下单独配置，包不含真实密钥/数据库/固件二进制。
- 本轮不部署云端、不自动烧录/恢复生产库；气体、雨量暂停，实板/真实供电/精度/4G/重启/长期运行仍待确认或待执行。
