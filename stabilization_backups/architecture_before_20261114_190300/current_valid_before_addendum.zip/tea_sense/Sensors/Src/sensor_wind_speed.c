#include "sensor_wind_speed.h"
#include <string.h>

/* Exactly round offset + delta*scale/(span*count), without delta*scale overflow
 * for UINT32_MAX samples. Both division remainders are retained: this does not
 * round the raw mean first. With these fixed endpoints every intermediate fits
 * int64_t (largest residual < 1.36e16). Halfway values round away from zero. */
static int32_t SensorWindSpeed_ScaleMean(int64_t delta, uint32_t count, int32_t scale, int32_t offset)
{
  int64_t span = SENSOR_WIND_SPEED_RAW_SPAN_X100;
  int64_t denominator = span * count;
  int64_t scaled = (delta / count) * scale + (int64_t)offset * span;
  int64_t whole = scaled / span;
  int64_t remainder = (scaled % span) * count + (delta % count) * scale;
  whole += remainder / denominator;
  remainder %= denominator;
  /* Normalize opposite signs before applying symmetric final rounding. */
  if (whole > 0 && remainder < 0) { --whole; remainder += denominator; }
  else if (whole < 0 && remainder > 0) { ++whole; remainder -= denominator; }
  return (int32_t)(whole + (remainder >= 0 ? (remainder + denominator / 2) / denominator :
                                            -((-remainder + denominator / 2) / denominator)));
}

SensorWindSpeedValue SensorWindSpeed_ConvertMean(uint64_t raw_sum, uint32_t count)
{
  SensorWindSpeedValue value;
  int64_t denominator, delta;
  memset(&value, 0, sizeof(value));
  if (!count || raw_sum > (uint64_t)UINT16_MAX * count) { return value; }
  denominator = (int64_t)SENSOR_WIND_SPEED_RAW_SPAN_X100 * count;
  delta = (int64_t)raw_sum * 100 - (int64_t)SENSOR_WIND_SPEED_RAW_ZERO_X100 * count;
  value.input_mv = SensorWindSpeed_ScaleMean(delta, count,
    SENSOR_WIND_SPEED_INPUT_SPAN_MV, SENSOR_WIND_SPEED_INPUT_ZERO_MV);
  value.range = delta < 0 ? SENSOR_WIND_SPEED_RANGE_LOW :
                delta > denominator ?
                SENSOR_WIND_SPEED_RANGE_HIGH : SENSOR_WIND_SPEED_RANGE_OK;
  if (delta <= 0) { value.wind_speed_mps_x100 = 0U; }
  else if (delta >= denominator)
  { value.wind_speed_mps_x100 = SENSOR_WIND_SPEED_FULL_SCALE_MPS_X100; }
  else
  {
    /* Nominal speed from raw independently of rounded terminal millivolts.
     * Electrical mapping measured; no reference-anemometer accuracy claim. */
    value.wind_speed_mps_x100 = (uint32_t)SensorWindSpeed_ScaleMean(delta, count,
      SENSOR_WIND_SPEED_FULL_SCALE_MPS_X100, 0);
  }
  value.valid = 1U;
  return value;
}

SensorWindSpeedData SensorWindSpeed_Read(void)
{
  SensorWindSpeedData data;
  memset(&data, 0, sizeof(data));
  data.adc = BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_SPEED_AD2);
  data.value = SensorWindSpeed_ConvertMean(data.adc.raw, data.adc.valid ? 1U : 0U);
  return data;
}

void SensorWindSpeed_WindowReset(SensorWindSpeedWindow *window)
{
  memset(window, 0, sizeof(*window));
  window->raw_min = UINT16_MAX;
}

void SensorWindSpeed_WindowAdd(SensorWindSpeedWindow *window, const BspAdcResult *sample)
{
  ++window->sample_count;
  if (!sample->valid || sample->status != BSP_ADC_OK || sample->hal_status != BSP_ADC_HAL_OK ||
      (sample->stop_attempted && sample->stop_status != BSP_ADC_HAL_OK))
  {
    if ((unsigned)sample->status <= BSP_ADC_OUT_OF_RANGE) { ++window->diagnostics.error_counts[sample->status]; }
    if (sample->stop_attempted && sample->stop_status != BSP_ADC_HAL_OK) { ++window->diagnostics.cleanup_error_count; }
    if (sample->prepare_attempted && sample->prepare_status != BSP_ADC_HAL_OK) { ++window->diagnostics.prepare_error_count; }
    if (sample->config_attempted && sample->config_status != BSP_ADC_HAL_OK) { ++window->diagnostics.config_error_count; }
    window->diagnostics.last_error = *sample;
    return;
  }
  ++window->valid_count;
  window->raw_sum += sample->raw;
  if (sample->raw < window->raw_min) { window->raw_min = sample->raw; }
  if (sample->raw > window->raw_max) { window->raw_max = sample->raw; }
}

SensorWindSpeedWindowResult SensorWindSpeed_WindowFinish(const SensorWindSpeedWindow *window,
                                                        uint32_t expected_count,
                                                        uint32_t minimum_valid_percent)
{
  SensorWindSpeedWindowResult result;
  uint64_t minimum_count;
  memset(&result, 0, sizeof(result));
  result.sample_count = window->sample_count;
  result.valid_count = window->valid_count;
  result.raw_sum = window->raw_sum;
  result.raw_min = window->valid_count ? window->raw_min : 0U;
  result.raw_max = window->raw_max;
  result.diagnostics = window->diagnostics;
  minimum_count = ((uint64_t)expected_count * minimum_valid_percent + 99U) / 100U;
  if (!expected_count || !minimum_valid_percent || minimum_valid_percent > 100U ||
      window->valid_count < 3U || window->valid_count < minimum_count) { return result; }
  result.used_count = window->valid_count - 2U;
  result.trimmed_sum = window->raw_sum - window->raw_min - window->raw_max;
  result.raw_mean = (uint16_t)((result.trimmed_sum + result.used_count / 2U) / result.used_count);
  result.status = SENSOR_WIND_SPEED_WINDOW_OK;
  result.value = SensorWindSpeed_ConvertMean(result.trimmed_sum, result.used_count);
  return result;
}

const char *SensorWindSpeed_WindowStatusName(SensorWindSpeedWindowStatus status)
{
  return status == SENSOR_WIND_SPEED_WINDOW_OK ? "OK" : "WINDOW_INSUFFICIENT";
}

const char *SensorWindSpeed_RangeName(SensorWindSpeedRange range)
{
  switch (range)
  {
    case SENSOR_WIND_SPEED_RANGE_OK: return "OK";
    case SENSOR_WIND_SPEED_RANGE_LOW: return "LOW";
    case SENSOR_WIND_SPEED_RANGE_HIGH: return "HIGH";
    default: return "NA";
  }
}
