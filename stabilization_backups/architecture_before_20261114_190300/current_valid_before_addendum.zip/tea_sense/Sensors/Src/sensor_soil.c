#include "sensor_soil.h"
#include <string.h>

/* One conversion path for single readings and unrounded window means. */
static uint32_t SensorSoil_ConvertMean(uint64_t raw_sum, uint32_t count, SensorSoilRange *range)
{
  const uint64_t dry = (uint64_t)SENSOR_SOIL_RAW_DRY * count;
  const uint64_t wet = (uint64_t)SENSOR_SOIL_RAW_WET * count;
  const uint64_t denominator = wet - dry;
  int64_t delta;
  *range = raw_sum < dry ? SENSOR_SOIL_RANGE_LOW :
           raw_sum > wet ? SENSOR_SOIL_RANGE_HIGH : SENSOR_SOIL_RANGE_OK;
  if (raw_sum <= dry)
  {
    return 0U;
  }
  if (raw_sum >= wet)
  {
    return 10000U;
  }
  /* Bounds precede subtraction. uint32 count * 16-bit raw * 10000 fits int64. */
  delta = (int64_t)raw_sum - (int64_t)dry;
  return (uint32_t)(((uint64_t)delta * 10000U + denominator / 2U) / denominator);
}

uint32_t SensorSoil_MoisturePercentX100(uint16_t raw)
{
  SensorSoilRange range;
  return SensorSoil_ConvertMean(raw, 1U, &range);
}

SensorSoilData SensorSoil_Read(void)
{
  SensorSoilData data;
  data.adc = BspAdc_ReadRaw(BSP_ADC_INPUT_SOIL_AD0);
  data.moisture_pct_x100 = 0U;
  data.range = SENSOR_SOIL_RANGE_UNAVAILABLE;
  if (data.adc.valid == 0U)
  {
    return data;
  }
  data.moisture_pct_x100 = SensorSoil_ConvertMean(data.adc.raw, 1U, &data.range);
  return data;
}

void SensorSoil_WindowReset(SensorSoilWindow *window)
{
  memset(window, 0, sizeof(*window));
  window->raw_min = UINT16_MAX;
}

void SensorSoil_WindowAdd(SensorSoilWindow *window, const BspAdcResult *sample)
{
  ++window->sample_count;
  if (!sample->valid || sample->status != BSP_ADC_OK ||
      sample->hal_status != BSP_ADC_HAL_OK ||
      (sample->stop_attempted && sample->stop_status != BSP_ADC_HAL_OK))
  {
    if ((unsigned)sample->status <= BSP_ADC_OUT_OF_RANGE)
    {
      ++window->diagnostics.error_counts[sample->status];
    }
    if (sample->stop_attempted && sample->stop_status != BSP_ADC_HAL_OK)
    {
      ++window->diagnostics.cleanup_error_count;
    }
    window->diagnostics.last_error = *sample;
    if (sample->prepare_attempted && sample->prepare_status != BSP_ADC_HAL_OK)
    { ++window->diagnostics.prepare_error_count; }
    if (sample->config_attempted && sample->config_status != BSP_ADC_HAL_OK)
    { ++window->diagnostics.config_error_count; }
    return;
  }
  ++window->valid_count;
  window->raw_sum += sample->raw;
  if (sample->raw < window->raw_min) { window->raw_min = sample->raw; }
  if (sample->raw > window->raw_max) { window->raw_max = sample->raw; }
}

SensorSoilWindowResult SensorSoil_WindowFinish(const SensorSoilWindow *window,
                                              uint32_t expected_count,
                                              uint32_t minimum_valid_percent)
{
  SensorSoilWindowResult result;
  uint64_t minimum_count, trimmed_sum;
  memset(&result, 0, sizeof(result));
  result.sample_count = window->sample_count;
  result.valid_count = window->valid_count;
  result.diagnostics = window->diagnostics;
  result.range = SENSOR_SOIL_RANGE_UNAVAILABLE;
  result.status = SENSOR_SOIL_WINDOW_INSUFFICIENT;
  minimum_count = ((uint64_t)expected_count * minimum_valid_percent + 99U) / 100U;
  if (!expected_count || !minimum_valid_percent || minimum_valid_percent > 100U ||
      window->valid_count < 3U || window->valid_count < minimum_count)
  {
    return result;
  }
  /* Delete exactly one occurrence of each extreme, even if they are equal. */
  trimmed_sum = window->raw_sum - window->raw_min - window->raw_max;
  result.used_count = window->valid_count - 2U;
  result.adc_raw = (uint16_t)((trimmed_sum + result.used_count / 2U) / result.used_count);
  result.moisture_pct_x100 = SensorSoil_ConvertMean(trimmed_sum, result.used_count, &result.range);
  result.status = SENSOR_SOIL_WINDOW_OK;
  return result;
}

const char *SensorSoil_WindowStatusName(SensorSoilWindowStatus status)
{
  return status == SENSOR_SOIL_WINDOW_OK ? "OK" : "WINDOW_INSUFFICIENT";
}
