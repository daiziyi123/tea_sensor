#include "sensor_wind_direction.h"
#include <math.h>
#include <string.h>

/* Current board electrical calibration, in chronological record order:
 * 5V:31000.43, 1V:6400.67, 3.5V:21920.14, 2.5V:15614.18.
 * Only 1V and 5V define the line; the other two are independent checks.
 * No soil/AD2 divider, VREF, orientation offset or automatic calibration. */
#define SENSOR_WIND_DIRECTION_RAW_1V_X100 640067L
#define SENSOR_WIND_DIRECTION_RAW_5V_X100 3100043L
#define SENSOR_WIND_DIRECTION_RAW_SPAN_X100 \
  (SENSOR_WIND_DIRECTION_RAW_5V_X100 - SENSOR_WIND_DIRECTION_RAW_1V_X100)
#define SENSOR_WIND_DIRECTION_INPUT_LOW_MV 1000L
#define SENSOR_WIND_DIRECTION_INPUT_SPAN_MV 4000L
#define SENSOR_WIND_DIRECTION_FULL_ANGLE_X100 36000L

#if SENSOR_WIND_DIRECTION_RAW_SPAN_X100 <= 0
#error Wind direction calibration raw span must be positive
#endif

static int32_t SensorWindDirection_RoundDivide(int64_t numerator, int64_t denominator)
{
  /* All products are bounded by a 16-bit ADC value times 100 and 36000.
   * Symmetric nearest rounding also handles negative voltage extrapolation. */
  return numerator >= 0 ? (int32_t)((numerator + denominator / 2) / denominator) :
                         -(int32_t)((-numerator + denominator / 2) / denominator);
}

SensorWindDirectionValue SensorWindDirection_Convert(uint32_t raw_x100)
{
  SensorWindDirectionValue value = {0};
  int64_t delta, span, voltage_numerator;
  if (raw_x100 > (uint32_t)UINT16_MAX * 100U) { return value; }
  span = SENSOR_WIND_DIRECTION_RAW_SPAN_X100;
  delta = (int64_t)raw_x100 - SENSOR_WIND_DIRECTION_RAW_1V_X100;
  voltage_numerator = SENSOR_WIND_DIRECTION_INPUT_LOW_MV * span +
                      delta * SENSOR_WIND_DIRECTION_INPUT_SPAN_MV;
  value.input_mv = SensorWindDirection_RoundDivide(voltage_numerator, span);
  /* Compare the unrounded raw relationship; rounded display endpoints do not
   * erase a small LOW/HIGH excursion. Equal endpoints are within range. */
  value.range = delta < 0 ? SENSOR_WIND_DIRECTION_RANGE_LOW :
                delta > span ? SENSOR_WIND_DIRECTION_RANGE_HIGH : SENSOR_WIND_DIRECTION_RANGE_OK;
  if (delta <= 0) { value.angle_deg_x100 = 0U; }
  else if (delta >= span) { value.angle_deg_x100 = SENSOR_WIND_DIRECTION_FULL_ANGLE_X100; }
  else
  {
    /* Compute angle directly from raw, never from already-rounded mV. */
    value.angle_deg_x100 = (uint32_t)SensorWindDirection_RoundDivide(
      delta * SENSOR_WIND_DIRECTION_FULL_ANGLE_X100, span);
  }
  value.valid = 1U;
  return value;
}

const char *SensorWindDirection_RangeName(SensorWindDirectionRange range)
{
  switch (range)
  {
    case SENSOR_WIND_DIRECTION_RANGE_LOW: return "LOW";
    case SENSOR_WIND_DIRECTION_RANGE_OK: return "OK";
    case SENSOR_WIND_DIRECTION_RANGE_HIGH: return "HIGH";
    default: return "NA";
  }
}

void SensorWindDirection_WindowReset(SensorWindDirectionWindow *window)
{ memset(window, 0, sizeof(*window)); }

void SensorWindDirection_WindowAdd(SensorWindDirectionWindow *window, const SensorWindDirectionValue *value)
{
  ++window->sample_count;
  if (!value->valid || value->angle_deg_x100 > 36000U) { return; }
  if (window->valid_count < SENSOR_WIND_DIRECTION_WINDOW_CAPACITY)
  { window->angles[window->valid_count] = (uint16_t)(value->angle_deg_x100 % 36000U); }
  else { window->overflow = 1U; }
  ++window->valid_count;
  if (value->range == SENSOR_WIND_DIRECTION_RANGE_LOW) { window->low = 1U; }
  if (value->range == SENSOR_WIND_DIRECTION_RANGE_HIGH) { window->high = 1U; }
}

SensorWindDirectionWindowResult SensorWindDirection_WindowFinish(const SensorWindDirectionWindow *window,
  uint32_t expected_count, uint32_t minimum_valid_percent)
{
  SensorWindDirectionWindowResult result;
  const float radians = 0.00017453292519943296f;
  const float pi = 3.14159265358979323846f;
  float x=0.0f, y=0.0f, center, minimum=4.0f, maximum=-4.0f;
  uint32_t index, minimum_index=0U, maximum_index=0U;
  uint64_t required=((uint64_t)expected_count*minimum_valid_percent+99U)/100U;
  memset(&result,0,sizeof(result));
  result.sample_count=window->sample_count; result.valid_count=window->valid_count;
  if (window->overflow || expected_count>SENSOR_WIND_DIRECTION_WINDOW_CAPACITY)
  { result.status=SENSOR_WIND_DIRECTION_WINDOW_CAPACITY_EXCEEDED; return result; }
  if (!expected_count || !minimum_valid_percent || minimum_valid_percent>100U ||
      window->valid_count<3U || window->valid_count<required) { return result; }
  for(index=0U;index<window->valid_count;++index)
  { float angle=window->angles[index]*radians; x+=cosf(angle); y+=sinf(angle); }
  /* Numerical direction is undefined for a normalized resultant <= 1e-4.
   * Test BEFORE trimming so removing points cannot manufacture a direction. */
  if (x*x+y*y <= (float)window->valid_count*(float)window->valid_count*1.0e-8f)
  { result.status=SENSOR_WIND_DIRECTION_WINDOW_UNDEFINED; return result; }
  center=atan2f(y,x);
  for(index=0U;index<window->valid_count;++index)
  {
    float difference=window->angles[index]*radians-center;
    while(difference < -pi) { difference+=2.0f*pi; }
    while(difference >= pi) { difference-=2.0f*pi; }
    if(difference<minimum) { minimum=difference; minimum_index=index; }
    if(difference>maximum) { maximum=difference; maximum_index=index; }
  }
  if(maximum_index==minimum_index) { maximum_index=(minimum_index+1U)%window->valid_count; }
  x=y=0.0f;
  for(index=0U;index<window->valid_count;++index)
  {
    if(index!=minimum_index && index!=maximum_index)
    { float angle=window->angles[index]*radians; x+=cosf(angle); y+=sinf(angle); }
  }
  result.used_count=window->valid_count-2U;
  if(x*x+y*y <= (float)result.used_count*(float)result.used_count*1.0e-8f)
  { result.used_count=0U; result.status=SENSOR_WIND_DIRECTION_WINDOW_UNDEFINED; return result; }
  center=atan2f(y,x); if(center<0.0f) { center+=2.0f*pi; }
  result.angle_deg_x100=(uint32_t)(center/radians+0.5f)%36000U;
  result.range=window->low?SENSOR_WIND_DIRECTION_RANGE_LOW:
               window->high?SENSOR_WIND_DIRECTION_RANGE_HIGH:SENSOR_WIND_DIRECTION_RANGE_OK;
  result.valid=1U; result.status=SENSOR_WIND_DIRECTION_WINDOW_OK;
  return result;
}
