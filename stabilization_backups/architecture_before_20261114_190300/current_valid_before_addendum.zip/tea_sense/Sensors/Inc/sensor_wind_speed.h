#ifndef SENSOR_WIND_SPEED_H
#define SENSOR_WIND_SPEED_H

#include "bsp_adc.h"

#define SENSOR_WIND_SPEED_CHANNEL_NAME "AD2"
/* Measured AD2 terminal-voltage endpoints; speed uses the nominal 0..30m/s relation. */
#define SENSOR_WIND_SPEED_RAW_ZERO_X100 6779U
#define SENSOR_WIND_SPEED_RAW_FULL_X100 3151863U
#define SENSOR_WIND_SPEED_RAW_SPAN_X100 (SENSOR_WIND_SPEED_RAW_FULL_X100 - SENSOR_WIND_SPEED_RAW_ZERO_X100)
#define SENSOR_WIND_SPEED_INPUT_ZERO_MV 40
#define SENSOR_WIND_SPEED_INPUT_SPAN_MV 5000
#define SENSOR_WIND_SPEED_FULL_SCALE_MPS_X100 3000U

typedef enum
{
  SENSOR_WIND_SPEED_RANGE_UNAVAILABLE = 0,
  SENSOR_WIND_SPEED_RANGE_OK,
  SENSOR_WIND_SPEED_RANGE_LOW,
  SENSOR_WIND_SPEED_RANGE_HIGH
} SensorWindSpeedRange;

typedef struct
{
  uint8_t valid; /* Availability of converted values, independent of ADC status. */
  int32_t input_mv; /* AD2 terminal voltage, not the MCU PA6 node. */
  uint32_t wind_speed_mps_x100;
  SensorWindSpeedRange range; /* Unrounded raw mean vs measured zero/full endpoints. */
} SensorWindSpeedValue;

typedef struct
{
  BspAdcResult adc;
  SensorWindSpeedValue value;
} SensorWindSpeedData;

typedef struct
{
  uint32_t error_counts[BSP_ADC_OUT_OF_RANGE + 1U];
  uint32_t cleanup_error_count;
  uint32_t prepare_error_count;
  uint32_t config_error_count;
  BspAdcResult last_error;
} SensorWindSpeedDiagnostics;

typedef struct
{
  uint32_t sample_count;
  uint32_t valid_count;
  uint64_t raw_sum;
  uint16_t raw_min;
  uint16_t raw_max;
  SensorWindSpeedDiagnostics diagnostics;
} SensorWindSpeedWindow;

typedef enum
{
  SENSOR_WIND_SPEED_WINDOW_INSUFFICIENT = 0,
  SENSOR_WIND_SPEED_WINDOW_OK
} SensorWindSpeedWindowStatus;

typedef struct
{
  uint32_t sample_count;
  uint32_t valid_count;
  uint32_t used_count;
  uint16_t raw_min; /* Available when valid_count>0, even if quality is insufficient. */
  uint16_t raw_max;
  uint16_t raw_mean; /* Rounded for display only; requires WINDOW_OK. */
  uint64_t raw_sum; /* All valid samples; independent of the trimmed result. */
  uint64_t trimmed_sum;
  SensorWindSpeedWindowStatus status;
  SensorWindSpeedValue value; /* Quality-qualified trimmed raw mean; invalid below gate. */
  SensorWindSpeedDiagnostics diagnostics;
} SensorWindSpeedWindowResult;

SensorWindSpeedData SensorWindSpeed_Read(void);
/* One fixed zero-compensated mapping for a sample or the exact raw sum/count.
 * No acquisition, pre-rounded raw/mV, VREF, divider guess or runtime mode. */
SensorWindSpeedValue SensorWindSpeed_ConvertMean(uint64_t raw_sum, uint32_t count);
void SensorWindSpeed_WindowReset(SensorWindSpeedWindow *window);
void SensorWindSpeed_WindowAdd(SensorWindSpeedWindow *window, const BspAdcResult *sample);
SensorWindSpeedWindowResult SensorWindSpeed_WindowFinish(const SensorWindSpeedWindow *window,
                                                        uint32_t expected_count,
                                                        uint32_t minimum_valid_percent);
const char *SensorWindSpeed_WindowStatusName(SensorWindSpeedWindowStatus status);
const char *SensorWindSpeed_RangeName(SensorWindSpeedRange range);

#endif
