#ifndef SENSOR_SOIL_H
#define SENSOR_SOIL_H

#include "bsp_adc.h"

#define SENSOR_SOIL_CHANNEL_NAME "AD0"
#define SENSOR_SOIL_MODEL "RE-SD-V05-TR"
/* Rounded means supplied by the user: 90 air-dry / 37 fully immersed samples.
 * These endpoints define relative wetness, not volumetric soil water content. */
#define SENSOR_SOIL_RAW_DRY 436U
#define SENSOR_SOIL_RAW_WET 31146U
#if SENSOR_SOIL_RAW_WET <= SENSOR_SOIL_RAW_DRY
#error SENSOR_SOIL_RAW_WET must be greater than SENSOR_SOIL_RAW_DRY
#endif
#if SENSOR_SOIL_RAW_WET > UINT16_MAX
#error Soil calibration endpoints must fit the unsigned 16-bit ADC
#endif

typedef enum
{
  SENSOR_SOIL_RANGE_UNAVAILABLE = 0,
  SENSOR_SOIL_RANGE_OK,
  SENSOR_SOIL_RANGE_LOW,
  SENSOR_SOIL_RANGE_HIGH
} SensorSoilRange;

typedef struct
{
  BspAdcResult adc;
  /* 0.01% relative wetness, valid only when adc.valid is set. */
  uint32_t moisture_pct_x100;
  SensorSoilRange range;
} SensorSoilData;

typedef struct
{
  uint32_t error_counts[BSP_ADC_OUT_OF_RANGE + 1U];
  uint32_t cleanup_error_count;
  uint32_t prepare_error_count;
  uint32_t config_error_count;
  BspAdcResult last_error;
} SensorSoilWindowDiagnostics;

/* Constant space; each valid raw contributes once, including raw=0. */
typedef struct
{
  uint32_t sample_count;
  uint32_t valid_count;
  uint64_t raw_sum;
  uint16_t raw_min;
  uint16_t raw_max;
  SensorSoilWindowDiagnostics diagnostics;
} SensorSoilWindow;

typedef enum
{
  SENSOR_SOIL_WINDOW_INSUFFICIENT = 0,
  SENSOR_SOIL_WINDOW_OK
} SensorSoilWindowStatus;

typedef struct
{
  uint32_t sample_count;
  uint32_t valid_count;
  uint32_t used_count;
  uint16_t adc_raw; /* Rounded window mean, only valid when status is OK. */
  uint32_t moisture_pct_x100; /* Computed from the unrounded rational mean. */
  SensorSoilRange range;
  SensorSoilWindowStatus status;
  SensorSoilWindowDiagnostics diagnostics;
} SensorSoilWindowResult;

/* One AD0 acquisition, then conversion only on a valid ADC result. */
SensorSoilData SensorSoil_Read(void);
/* Unique raw-to-percent conversion: clamped, rounded, no VREF/gain factor. */
uint32_t SensorSoil_MoisturePercentX100(uint16_t raw);
void SensorSoil_WindowReset(SensorSoilWindow *window);
void SensorSoil_WindowAdd(SensorSoilWindow *window, const BspAdcResult *sample);
/* App supplies expected count and quality policy; Sensors never includes App. */
SensorSoilWindowResult SensorSoil_WindowFinish(const SensorSoilWindow *window,
                                              uint32_t expected_count,
                                              uint32_t minimum_valid_percent);
const char *SensorSoil_WindowStatusName(SensorSoilWindowStatus status);

#endif
