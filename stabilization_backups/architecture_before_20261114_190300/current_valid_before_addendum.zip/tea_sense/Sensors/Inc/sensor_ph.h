#ifndef SENSOR_PH_H
#define SENSOR_PH_H

#include <stdint.h>
#include "bsp_adc.h"

/* AD4 / PA4 / ADC1 channel 18: measured electrical endpoints, 0..5V version.
 * The manufacturer's nominal pH 3..9 relation has no soil-reference validation. */
#define SENSOR_PH_RAW_LOW_X100 6222U
#define SENSOR_PH_RAW_HIGH_X100 3137026U
#define SENSOR_PH_RAW_SPAN_X100 (SENSOR_PH_RAW_HIGH_X100 - SENSOR_PH_RAW_LOW_X100)
#define SENSOR_PH_INPUT_SPAN_MV 5000
#define SENSOR_PH_SOIL_PH_LOW_X100 300U
#define SENSOR_PH_SOIL_PH_HIGH_X100 900U
#define SENSOR_PH_SOIL_PH_SPAN_X100 (SENSOR_PH_SOIL_PH_HIGH_X100 - SENSOR_PH_SOIL_PH_LOW_X100)

typedef enum
{
  SENSOR_PH_RANGE_UNAVAILABLE = 0,
  SENSOR_PH_RANGE_OK,
  SENSOR_PH_RANGE_LOW,
  SENSOR_PH_RANGE_HIGH
} SensorPhRange;

typedef struct
{
  uint8_t valid;
  int32_t input_mv; /* AD4 terminal voltage, not the PA4 node; extrapolation retained. */
  uint32_t soil_ph_x100; /* Display limited to 3.00..9.00; no percent unit. */
  SensorPhRange range; /* From the unrounded, unclamped raw mean. */
} SensorPhValue;

typedef struct
{
  uint32_t sample_count, valid_count;
  uint64_t raw_sum;
  uint16_t raw_min, raw_max;
  uint32_t error_counts[BSP_ADC_OUT_OF_RANGE + 1U];
  uint32_t cleanup_errors, prepare_errors, config_errors;
  BspAdcResult last_error;
} SensorPhWindow;

typedef struct
{
  SensorPhWindow raw;
  uint32_t used_count;
  uint64_t trimmed_sum;
  SensorPhValue soil_ph;
} SensorPhWindowResult;

/* Pure conversion of a caller-selected successful raw sum/count (sample: raw,1).
 * WindowFinish supplies the quality-gated, trimmed fraction. No early mean
 * rounding; count=0 is unavailable. Never starts an ADC. */
SensorPhValue SensorPh_Convert(uint64_t raw_sum, uint32_t count);
const char *SensorPh_RangeName(SensorPhRange range);
void SensorPh_WindowReset(SensorPhWindow *window);
void SensorPh_WindowAdd(SensorPhWindow *window, const BspAdcResult *sample);
SensorPhWindowResult SensorPh_WindowFinish(const SensorPhWindow *window,
  uint32_t expected_count, uint32_t minimum_valid_percent);

#endif
