/* Isolated V2 formatter/ACK fixture. Does not access ADC, production config or DTU. */
#include "app_upload.h"
#include "app_config.h"
#include "sensor_soil.h"
#include "bsp_dtu.h"
#include "sensor_wind_speed.h"
#include "sensor_wind_direction.h"
#include "sensor_ph.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

BspAdcResult BspAdc_ReadRaw(BspAdcInput input)
{ BspAdcResult result={0}; (void)input; assert(!"Fixture must not start ADC"); return result; }

BspDtuStatus BspDtu_Init(void) { assert(!"pure fixture"); return BSP_DTU_UART_ERROR; }
BspDtuTxResult BspDtu_Process(void) { BspDtuTxResult r={0};assert(!"pure fixture");return r; }
BspDtuReadResult BspDtu_Read(uint8_t *p,size_t n) { BspDtuReadResult r={0};(void)p;(void)n;assert(!"pure fixture");return r; }
char *BspDtu_TxBuffer(size_t *n) { (void)n;assert(!"pure fixture");return NULL; }
BspDtuStatus BspDtu_StartSend(size_t n) { (void)n;assert(!"pure fixture");return BSP_DTU_UART_ERROR; }
uint32_t BspTime_GetTickMs(void) { assert(!"pure fixture");return 0U; }

int main(int argc,char **argv)
{
  AppUploadSnapshot snapshot;
  AppUploadAck ack;
  AppUploadValue *analog[4],*weather[6];
  char buffer[APP_UPLOAD_FRAME_CAPACITY];
  uint32_t sequence=1U,now;
  unsigned i,tick;
  SensorSoilWindow soil_window;SensorWindSpeedWindow wind_window;
  SensorPhWindow soil_ph_window;SensorWindDirectionWindow direction_window;
  SensorSoilWindowResult soil;SensorWindSpeedWindowResult wind;
  SensorPhWindowResult soil_ph;SensorWindDirectionWindowResult direction;
  BspAdcResult adc;
  int length;
  memset(&snapshot,0,sizeof(snapshot));
  if(argc>1 && !strcmp(argv[1],"missing")) {
    assert(!AppUpload_IsConfigured());
    assert(AppUpload_Format(buffer,sizeof(buffer),1U,3000U,&snapshot)<0);return 0;
  }
  if(argc>1 && !strncmp(argv[1],"ack",3U)) {
    uint32_t expected=strtoul(argv[1]+3,NULL,10);
    if(!expected)expected=1U;
    assert(fgets(buffer,sizeof(buffer),stdin));
    assert(AppUpload_ParseAck(buffer,strlen(buffer),expected,&ack)==APP_UPLOAD_ACK_ACCEPTED && ack.id>0U);
    puts("ACK_ACCEPTED");return 0;
  }
  if(argc>1) {
    if(!strcmp(argv[1],"failure"))sequence=2U;
    else if(!strcmp(argv[1],"configuration"))sequence=3U;
    else sequence=(uint32_t)strtoul(argv[1],NULL,10);
  }
  assert(sequence>0U);now=sequence*3000U;
  snapshot.window_seq=sequence;snapshot.window_end_ms=now;
  analog[0]=&snapshot.soil_moisture_pct;analog[1]=&snapshot.wind_speed_mps;
  analog[2]=&snapshot.wind_direction_deg;analog[3]=&snapshot.soil_ph;
  for(i=0U;i<4U;++i) {
    analog[i]->valid=analog[i]->has_sample=1U;analog[i]->status="OK";analog[i]->range="OK";
    analog[i]->sample_seq=sequence;analog[i]->sample_t_ms=now;
  }
  SensorSoil_WindowReset(&soil_window);SensorWindSpeed_WindowReset(&wind_window);
  SensorPh_WindowReset(&soil_ph_window);SensorWindDirection_WindowReset(&direction_window);
  for(tick=0U;tick<3000U;tick+=100U) {
    SensorWindDirectionValue angle=SensorWindDirection_Convert(1561400U);
    memset(&adc,0,sizeof(adc));adc.valid=1U;adc.raw=19122U;
    if(argc>1 && ((!strcmp(argv[1],"failure") && tick>=2300U) || !strcmp(argv[1],"configuration"))) {
      adc.valid=0U;adc.status=BSP_ADC_POLL_FAILED;adc.hal_status=BSP_ADC_HAL_TIMEOUT;
    }
    SensorSoil_WindowAdd(&soil_window,&adc);
    memset(&adc,0,sizeof(adc));adc.valid=1U;adc.raw=15793U;SensorWindSpeed_WindowAdd(&wind_window,&adc);
    adc.raw=15716U;SensorPh_WindowAdd(&soil_ph_window,&adc);
    SensorWindDirection_WindowAdd(&direction_window,&angle);
  }
  soil=SensorSoil_WindowFinish(&soil_window,30U,80U);
  wind=SensorWindSpeed_WindowFinish(&wind_window,30U,80U);
  soil_ph=SensorPh_WindowFinish(&soil_ph_window,30U,80U);
  direction=SensorWindDirection_WindowFinish(&direction_window,30U,80U);
  analog[0]->valid=soil.status==SENSOR_SOIL_WINDOW_OK;analog[0]->value=soil.moisture_pct_x100;
  if(!analog[0]->valid)analog[0]->status="WINDOW_INSUFFICIENT";
  analog[1]->valid=wind.value.valid;analog[1]->value=wind.value.wind_speed_mps_x100;
  analog[2]->valid=direction.valid;analog[2]->value=direction.angle_deg_x100;
  analog[3]->valid=soil_ph.soil_ph.valid;analog[3]->value=soil_ph.soil_ph.soil_ph_x100;
  weather[0]=&snapshot.temperature_c;weather[1]=&snapshot.air_humidity_rh_pct;
  weather[2]=&snapshot.light_lux;weather[3]=&snapshot.pressure_kpa;
  weather[4]=&snapshot.pm25_ug_m3;weather[5]=&snapshot.pm10_ug_m3;
  for(i=0U;i<6U;++i) {
    uint32_t period=(i==3U)?60000U:i>=4U?30000U:10000U;
    uint32_t initial=i<2U?1000U:i==2U?1250U:i==3U?1750U:1500U;
    weather[i]->sample_t_ms=(now-initial)/period*period+initial;
    weather[i]->sample_seq=(i<2U?1000U:i==2U?2000U:i==3U?4000U:3000U)+(now-initial)/period+1U;
    weather[i]->valid=weather[i]->has_sample=1U;weather[i]->status="OK";
  }
  weather[0]->value=194;weather[1]->value=708;weather[2]->value=1249;
  weather[3]->value=10373;weather[4]->value=22;weather[5]->value=23;
  if(argc>1 && (!strcmp(argv[1],"failure") || !strcmp(argv[1],"configuration"))) {
    analog[0]->valid=0U;analog[0]->status="WINDOW_INSUFFICIENT";
    /* A stale numeric value is deliberately left in place; output must be null. */
    if(sequence==3U) {
      weather[0]->valid=0U;weather[0]->status="TIMEOUT";
      weather[0]->sample_t_ms=now;weather[0]->sample_seq=1002U;
    }
  }
  length=AppUpload_Format(buffer,sizeof(buffer),sequence,now,&snapshot);
  assert(length>0 && (size_t)length<sizeof(buffer));
  assert(buffer[length-2]=='\r' && buffer[length-1]=='\n');
  fwrite(buffer,1U,(size_t)length,stdout);return 0;
}
