/* Regressions use virtual ticks; no 60-second sleeps or board access. */
static void Test_CompletionTickRace(void)
{
  uint32_t bases[2]={0U,UINT32_MAX-3100U};unsigned i;
  for(i=0U;i<2U;++i) {
    uint32_t base=bases[i];
    Test_Reset(base);s_tx_auto_complete=0U;Test_At(base);Test_Through(base+3000U);
    s_tc_during_tick=1U;Test_At(base+3100U);
    assert(!AppUpload_GetDiagnostics()->timeouts && AppUpload_GetDiagnostics()->awaiting_ack);
    assert(BspDtu_GetDiagnostics().tx_completed==1U);
    Test_At(base+13100U);assert(!AppUpload_GetDiagnostics()->timeouts);
    Test_At(base+13101U);assert(AppUpload_GetDiagnostics()->timeouts==1U);
    Test_Inject(s_ack,s_ack_length);Test_At(base+13102U);assert(!AppUpload_GetDiagnostics()->ack_count);
    Test_Reset(base);s_tx_auto_complete=0U;Test_At(base);Test_Through(base+3000U);
    Test_Inject(s_ack,s_ack_length);Test_At(base+3050U);
    assert(!AppUpload_GetDiagnostics()->ack_count);
    s_tc_during_tick=1U;Test_At(base+3100U);
    assert(AppUpload_GetDiagnostics()->ack_count==1U && !AppUpload_GetDiagnostics()->awaiting_ack);
  }
}
static void Test_StartErrorRace(void)
{
  char frozen[APP_UPLOAD_FRAME_CAPACITY];size_t capacity;unsigned tc;
  for(tc=0U;tc<2U;++tc) {
    Test_Reset(0U);s_tx_auto_complete=(uint8_t)tc;Test_At(0U);Test_Through(2900U);
    s_start_error_injection=1U;Test_At(3000U);
    assert(BspDtu_GetDiagnostics().rx_errors==1U);
    assert(BspDtu_GetDiagnostics().last_tx_status==BSP_DTU_UART_ERROR);
    assert(!AppUpload_GetDiagnostics()->awaiting_ack && BspDtu_TxBuffer(&capacity)==NULL);
    memcpy(frozen,s_active_tx,s_active_tx_length);
    Test_At(3001U);
    assert(AppUpload_GetDiagnostics()->tx_errors==1U && !AppUpload_GetDiagnostics()->awaiting_ack);
    assert(!BspDtu_GetDiagnostics().tx_completed && !memcmp(frozen,s_active_tx,s_active_tx_length));
    Test_At(3002U);assert(AppUpload_GetDiagnostics()->tx_errors==1U);
    s_tx_auto_complete=1U;Test_Through(6000U);Test_At(6001U);
    assert(s_uart6_sends==2U && AppUpload_GetDiagnostics()->awaiting_ack);
  }
  Test_Reset(0U);s_tx_auto_complete=0U;Test_At(0U);Test_Through(3000U);
  Test_TxComplete();Test_Error(1U);Test_At(3001U);
  assert(AppUpload_GetDiagnostics()->tx_errors==1U && !BspDtu_GetDiagnostics().tx_completed);
  Test_Reset(0U);s_tx_auto_complete=0U;Test_At(0U);Test_Through(3000U);
  Test_TxComplete();Test_At(3001U);Test_Error(1U);Test_At(3002U);
  assert(!AppUpload_GetDiagnostics()->tx_errors && BspDtu_GetDiagnostics().tx_completed==1U);
  /* Late idle callback and a callback while new bytes remain cannot complete
   * the next transfer; only real HAL READY/count=0 TC can do that. */
  Test_Reset(0U);s_tx_auto_complete=0U;Test_At(0U);Test_Through(4000U);
  HAL_UART_TxCpltCallback(&huart6);Test_Through(6000U);
  HAL_UART_TxCpltCallback(&huart6);Test_At(6001U);
  assert(!BspDtu_GetDiagnostics().tx_completed && !AppUpload_GetDiagnostics()->awaiting_ack);
  Test_TxComplete();Test_At(6002U);assert(BspDtu_GetDiagnostics().tx_completed==1U);
}
static void Test_DtuControlledRecovery(void)
{
  uint32_t bases[2]={0U,UINT32_MAX-5000U};unsigned i;
  for(i=0U;i<2U;++i) {
    char frozen[APP_UPLOAD_FRAME_CAPACITY];size_t capacity;
    unsigned aborts,reads;uint32_t base=bases[i],locked=base+4002U;
    Test_Reset(base);s_tx_auto_complete=0U;Test_At(base);Test_Through(base+3000U);
    s_abort_tx_result=HAL_ERROR;Test_At(base+4000U);Test_At(base+4001U);Test_At(locked);
    assert(BspDtu_GetDiagnostics().tx_state==BSP_DTU_TX_BLOCKED);
    memcpy(frozen,s_active_tx,s_active_tx_length);aborts=s_tx_aborts;reads=s_soil_reads;
    assert(BspDtu_Init()==BSP_DTU_UART_ERROR);
    assert(BspDtu_TxBuffer(&capacity)==NULL && s_tx_aborts==aborts+1U);
    aborts=s_tx_aborts;
    Test_At(locked+100U);Test_At(locked+BSP_DTU_RECOVERY_PERIOD_MS-1U);
    assert(s_tx_aborts==aborts && s_soil_reads>reads && s_rx_armed);
    assert(!memcmp(frozen,s_active_tx,s_active_tx_length));
    Test_At(locked+BSP_DTU_RECOVERY_PERIOD_MS);
    assert(s_tx_aborts==aborts+1U && BspDtu_GetDiagnostics().recovery_attempts==1U);
    assert(BspDtu_TxBuffer(&capacity)==NULL && !memcmp(frozen,s_active_tx,s_active_tx_length));
    Test_At(locked+2U*BSP_DTU_RECOVERY_PERIOD_MS-1U);assert(s_tx_aborts==aborts+1U);
    s_abort_tx_result=HAL_OK;s_tx_auto_complete=1U;
    Test_At(locked+2U*BSP_DTU_RECOVERY_PERIOD_MS);
    assert(BspDtu_GetDiagnostics().recovery_successes==1U && BspDtu_GetDiagnostics().recovery_attempts==2U);
    assert(BspDtu_GetDiagnostics().tx_errors==1U && AppUpload_GetDiagnostics()->tx_errors==1U);
    /* Next available new window, never replay the failed 3000ms snapshot. */
    if(s_uart6_sends==1U) { Test_At(locked+2U*BSP_DTU_RECOVERY_PERIOD_MS+3000U); }
    assert(s_uart6_sends==2U && s_active_tx[0]=='\r' && s_active_tx[1]=='\n');
    assert(s_rx_armed && BspDtu_GetDiagnostics().tx_abort_errors==4U);
  }
}
static void Test_AdcCalibrationRecovery(void)
{
  unsigned i,cal;uint32_t bases[2]={0U,UINT32_MAX-1000U};
  for(i=0U;i<2U;++i) {
    uint32_t base=bases[i];BspAdcResult raw;
    Test_Reset(base);s_cal_result=HAL_TIMEOUT;BspAdc_Init();cal=s_cal_calls;
    assert(BspAdc_GetDiagnostics()->initial_calibration_status==BSP_ADC_HAL_TIMEOUT);
    raw=BspAdc_ReadRaw(BSP_ADC_INPUT_PH_AD4);assert(!raw.valid && raw.status==BSP_ADC_CAL_FAILED);
    s_cal_result=HAL_OK;s_tick_ms=base+BSP_ADC_CAL_RECOVERY_PERIOD_MS-1U;BspAdc_Process();
    assert(s_cal_calls==cal && !BspAdc_GetDiagnostics()->recovery_attempts);
    s_prepare_result=HAL_ERROR;s_tick_ms=base+BSP_ADC_CAL_RECOVERY_PERIOD_MS;BspAdc_Process();
    assert(s_cal_calls==cal && BspAdc_GetDiagnostics()->recovery_stop_errors==1U);
    s_prepare_result=HAL_OK;s_tick_ms=base+2U*BSP_ADC_CAL_RECOVERY_PERIOD_MS-1U;BspAdc_Process();
    assert(s_cal_calls==cal);
    s_tick_ms=base+2U*BSP_ADC_CAL_RECOVERY_PERIOD_MS;BspAdc_Process();
    assert(s_cal_calls==cal+1U && BspAdc_GetDiagnostics()->recovery_successes==1U);
    assert(BspAdc_GetDiagnostics()->calibration_failures==1U);
    assert(BspAdc_GetDiagnostics()->initial_calibration_status==BSP_ADC_HAL_TIMEOUT);
    s_raw=0U;raw=BspAdc_ReadRaw(BSP_ADC_INPUT_SOIL_AD0);assert(raw.valid && raw.raw==0U);
    s_tick_ms+=10U*BSP_ADC_CAL_RECOVERY_PERIOD_MS;BspAdc_Process();assert(s_cal_calls==cal+1U);
    Test_Reset(base);s_cal_result=HAL_ERROR;BspAdc_Init();cal=s_cal_calls;
    s_tick_ms=base+BSP_ADC_CAL_RECOVERY_PERIOD_MS;BspAdc_Process();
    assert(s_cal_calls==cal+1U && !BspAdc_GetDiagnostics()->calibrated);
    s_tick_ms=base+2U*BSP_ADC_CAL_RECOVERY_PERIOD_MS-1U;BspAdc_Process();assert(s_cal_calls==cal+1U);
    s_tick_ms++;BspAdc_Process();assert(s_cal_calls==cal+2U && BspAdc_GetDiagnostics()->calibration_failures==3U);
    raw=BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_SPEED_AD2);assert(!raw.valid && raw.status==BSP_ADC_CAL_FAILED);
  }
}
