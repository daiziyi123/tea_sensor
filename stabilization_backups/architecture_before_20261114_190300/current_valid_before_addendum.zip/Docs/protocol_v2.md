# 当前V2协议与采样身份
版本：STAB-DRAFT-2026-11-14。本文件是待硬件签收的交付初稿。
证据标记：**[代码核对]** 为本机修复后源码事实；**[历史用户实测]** 为已有带来源记录；**[资料记录]** 为附件/旧手册记载，未经本轮重测；**[待确认]** 为硬件信息不足；**[待执行]** 为尚未实施测试。

[代码核对] 来源：tea_sense/App/Inc/app_upload.h、App/Src/app_upload.c、app_main.c、app_weather.c、Sensors/Src/sensor_weather.c；服务器app/protocol.py、storage.py、main.py与web/app.js。以下以本机当前源码为准。

## 线路与顶层
USART6/RS485透明TCP，UTF-8单行JSON+CRLF，服务端按LF拆粘包；非HTTP、非AT命令。schema_version=2，device_id默认tea_h743_001，seq是发送尝试编号，t_ms是窗口末上电tick，window_ms来自APP_SAMPLE_WINDOW_MS默认3000，data固定十项，token取现有私有配置。当前固件不发boot_id。
window_ms已消除写死字面量；2000ms软件编译变体实际采20点并输出2000，通过回归。该变体仅验证同步能力；现有服务器严格要求3000，若以后改产品周期必须双方同步，本轮默认合同不变。

每项固定对象：value、status、sample_seq、sample_t_ms、age_ms；适用且有效时可有range=LOW/OK/HIGH。value是JSON数字或null；只有OK携带有限数值，NO_DATA时身份/年龄均null。失败无range、不能把失败变0；有效raw0和物理0保留。range是电气端点越界诊断，不证明供电、线路或探头准确。

| data键 | 名称 | 单位 | 源周期ms | 过期阈值ms |
|---|---|---|---|---|
| soil_moisture_pct | 土壤湿度 | % | 3000 | 9000 |
| soil_ph | 土壤pH | 无量纲 | 3000 | 9000 |
| wind_speed_mps | 风速 | m/s | 3000 | 9000 |
| wind_direction_deg | 风向角度 | ° | 3000 | 9000 |
| temperature_c | 气温 | ℃ | 10000 | 30000 |
| air_humidity_rh_pct | 空气湿度 | %RH | 10000 | 30000 |
| light_lux | 光照 | lx | 10000 | 30000 |
| pressure_kpa | 气压 | kPa | 60000 | 180000 |
| pm25_ug_m3 | PM2.5 | μg/m³ | 30000 | 90000 |
| pm10_ug_m3 | PM10 | μg/m³ | 30000 | 90000 |

## status白名单
[代码核对] 下列从服务器MetricStatus读取，固件当前可用状态与此兼容，新增恢复状态仅在本地诊断，不上行：
OK, NO_DATA, WINDOW_INSUFFICIENT, DIRECTION_UNDEFINED, WINDOW_CAPACITY, INVALID_VALUE, STALE, TIMEOUT, CRC_ERROR, FRAME_ERROR, MODBUS_EXCEPTION, UART_ERROR, UART_BUSY, UART_TIMEOUT, RX_NOT_READY, IRQ_DISABLED, RX_OVERFLOW

模拟量身份取实际窗口编号与末tick；上传seq与窗口seq可因busy/late/rate跳过不同。气象身份取最近完成查询，成功响应末tick、失败真实完成tick；PENDING保留上次完成，不用新查询号套旧值。age=编码now−源tick的无符号差，不是UTC，不含未知网络滞留。气象每3秒重复快照不创建新点，同值新查询正常建点。

## ACK与生命周期
[代码核对] ACK严格解析JSON对象：ok=true、device_id及当前seq匹配、正整数id（不超过INT64_MAX）；duplicate可由服务器返回。非法类型/重复字段/不匹配/超时ACK不得确认。RX独立512字节ACK行缓冲，Bsp单4096字节TX缓冲（含2字节恢复前缀），公开格式化容量4094；凭据大小仅在实现内编译核验，每次snprintf检查，越界不发送。
AppUpload_Init/Process/Submit/GetDiagnostics是实际上传所有者；Format/ParseAck保持独立纯入口，无采样或UART操作。Submit同步编码，不保留调用者快照指针。TX中缓冲只读；TC后才起10秒ACK计时，状态消费后重新取tick。早ACK保留至成功，错误则丢弃；无排队重发/离线回灌。
内部状态为IDLE→STARTING→SENDING→COMPLETE/FAILED；TC与错误在消费前并发时错误优先，消费完成后的RX错误独立。无TC且错误不会进入等待；HAL_OK只表示接受启动。失败最多三次AbortTransmit，仍失败进入BLOCKED，60秒低频探测，确认安全停止才释放；旧TC标志清除且HAL READY/count=0校验防迟到回调影响新帧。不为普通ACK超时重置UART/DTU/整机。

## 服务器与网页
[代码核对] 本轮没有重构这些模块。严格V1兼容；V2固定十项，布尔/非有限/失败假值/重复键拒绝。SQLite schema=2、readings原ID空间、measurements独立点；按运行段/指标/源seq/tick识别缓存，年龄不会因重复接收置零。无boot_id只能保守推断重启，不能保证跨重启全局幂等或断网历史完整。设备tick不是北京时间；图表采用服务器接收时间。
实际端点：/healthz、/api/config、/api/overview、/api/readings、/api/measurements、/api/export.csv、/ws。VIEW_TOKEN开启时API需X-View-Token，WS首条鉴权且保留Origin限制；真实token不进公开API/CSV。网页按各源三倍周期过期，当前值独立历史过滤，3秒WS重连、5秒HTTP兜底；趋势最多1000点标实际覆盖，CSV最多10000长表行。

## USART2观察格式
[代码核对及本轮ARM CPU执行] 每条一整行CRLF，直接整数拆分printf、UTF-8；不输出JSON/token/raw帧/ADC：
~~~
土壤湿度：60.85%，风速：15.00 m/s，风向角度：134.83°，土壤 pH：6.00
气温：19.4 ℃，空气湿度：70.8 %RH
光照强度：1249 lx
PM2.5：22 μg/m³，PM10：23 μg/m³
大气压力：103.73 kPa
~~~
四路同窗每3秒一行；气象只实际完成查询打印，数据无效/采集失败与有效0区分，printf错误计数与clearerr恢复保留。示例及本轮CPU输出不是实板数据，实板观察待执行。
