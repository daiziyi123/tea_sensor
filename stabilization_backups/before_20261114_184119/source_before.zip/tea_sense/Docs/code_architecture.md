# tea_sense 当前代码架构
更新：2026-11-14；当前行为详见 integration_v2.md，早期标定记录保留。
ARMCC5、标准Arm C库、MicroLIB关闭，无浮点printf/半主机。Core、Drivers、.ioc、第三方coreJSON和私有密钥不变。
| 层 | 职责 |
|---|---|
| App/Inc、App/Src | app_main调度/同窗物理快照/直接中文printf/ACK；app_weather固定查询事务；app_upload十项格式化与coreJSON ACK |
| Sensors/Inc、Sensors/Src | soil/wind_speed/ph独立窗口和纯换算，wind_direction定容量圆周窗口，weather CRC/解码/逐字段质量/最近完成结果 |
| Bsp/Inc、Bsp/Src | ADC显式选通/超时/清理、USART2重定向、USART6单缓冲IT TX与RX环、气象串口和时基 |

Sensors不依赖App，HAL操作在Bsp，无可写extern状态、日志框架、动态分配、RTOS或DMA。
main原生成初始化→App_Init（一次ADC自校准）→App_Process。每循环处理控制台恢复和DTU完成/RX/ACK，再结算旧窗、采到期轮次、气象事务、上传和直接printf。100ms轮次、3000ms窗、30期望/24有效，通道5→3→19→18→5。
土壤/风速/pH通过质量后去各一个极值，保留sum/count精度；风向先判合向量可定义，再按圆心相对角差删除不同索引端点，重新圆周平均。容量32，超限无效。App_GetDiagnostics保留原始/错误诊断，普通打印与上传仅物理量。
USART6一个4096字节缓冲含2字节边界恢复预留，空闲才格式化，在途只读。TC后起算10秒ACK，早ACK暂存到发送成功；有限超时仅AbortTransmit不清RX，最多3次清理失败锁TX到重初始化，下次CRLF恢复残行。busy/late/rate有界跳过，无队列补发。
MET默认四组；UART4生成配置和六组纯解析保留，APP_WEATHER_GAS_ENABLED默认0，启用分支有host覆盖。
