# 当前三秒窗口、气象与V2上传
更新：2026-11-14；替代早期一秒/原始打印的当前运行说明。

## 采样、质量与系数
100ms轮次，3000ms窗口，[start,end)，边界先结算再采新轮次；无符号tick差处理回绕，迟到不补采不回灌。期望30，至少24有效。ADC16位、异步分频8、软件单次、单Rank、387.5cycles，自校准仅初始化一次。
AD0/PB1/CH5：raw436～31146对应0～100%相对湿润度；
AD2/PA6/CH3：raw×100=6779～3151863，40～5040mV对应标称0～30m/s；
AD3/PA5/CH19：raw×100=640067～3100043，对应参考0～360°；
AD4/PA4/CH18：raw×100=6222～3137026，对应0～5000mV、pH3～9。
全部原系数保持；电气映射不代表标准风场、地理对北、真实土壤/标准pH溶液精度已对照。VREF未实测状态不改。
土壤原算法保持；风速/pH正式窗口质量合格后去两个极值，再从未舍入分数均值换算，不先限幅单点再平均。无效/23有效/零样本不能假报0或pH3；有效raw0仍有效，越界LOW/HIGH保留。单点纯换算能力保留。风向圆周算法与容量边界见code_architecture.md。

## USART2 实际格式
115200/8N1、UTF-8，以下每条为一整行CRLF；整数拆分，无浮点printf：
~~~
土壤湿度：60.85%，风速：15.00 m/s，风向角度：134.83°，土壤 pH：6.00
气温：19.4 ℃，空气湿度：70.8 %RH
光照强度：1249 lx
PM2.5：22 μg/m³，PM10：23 μg/m³
大气压力：103.73 kPa
~~~
模拟量同一三秒窗一行；气象仅真实查询完成打印。质量不足/字段超量程为“数据无效”，事务失败“采集失败”；有效0照常显示。printf失败计数并clearerr恢复；无ISR打印、启动配置、原始帧、ADC_SAMPLE/ADC_WINDOW、一秒行、JSON或密钥输出。

## 气象
USART3/PD8-PD9/4800/8N1/地址01；温湿度/光照10秒、PM30秒、气压60秒。发送50ms有限超时、响应1000ms、间隔250ms，三次无合法响应后60秒探测。合法CRC但字段无效不算无响应。
湿度第一字0～100%RH，温度第二字有符号−40～80℃，FFFF可表示−0.1℃；光照高字在前uint32全FF无效；PM两字分别判断全FF，不虚构上限；气压raw10373直接为103.73kPa，30～110有效。同响应有效兄弟字段保留。默认无CO₂/OXYGEN查询/显示。
最近完成身份/状态与PENDING和旧成功缓存分开，失败使用真实完成tick。

## 验证与限制
五组host配置各运行soil/dtu两程序，共10次；原ADC各阶段/cleanup、CRC/流式分片/回显/ACK严格性、tick回绕/迟到覆盖保留，新增24/23、去极值、圆周对消/容量、天气逐字段/完成tick、长帧/早ACK/TC/abort。
MDK全量重建0error/0warning，无float printf/半主机。Unicorn真实ARM C库和业务对象：182轮、728次5/3/19/18通道配置、1456次Stop、一次校准、6上传与ACK，核对完整十项帧。进入应用后的实测最大栈624字节，原1KiB不变，断言至少224字节余量；未计实际ISR抢占。
C→分片TCP→临时SQLite→鉴权API/CSV→生产C ACK回环：24上传/128独立点，正常帧1111～1129字节；host另测最坏长元数据超过1152字节。Bsp单4096缓冲，APP按2560非token预算加JSON转义token/device，逐步snprintf检查，ACK独立512。fixture仅demo/临时库/测试密钥。证据Docs/validation/integration_*。
真实电压、ISR实时负荷、AUTO方向、4G/cpolar实链路、风场/pH准确度仍须上板；未自动烧录。

## 人工对齐
1. 用户在MDK手动编译/下载新固件；USART2 UTF-8/115200采集四路同窗中文值。
2. 根目录start_server.cmd启动唯一服务，网页8000、TCP9000，原cpolar/DTU目标不变。
3. 比较同一窗口串口与/api/overview物理值；气象按真实完成事件核对19.4/70.8、1249、103.73、22/23。
4. 正常串口不打印JSON/token。用ACK诊断计数与脱敏API核对发送seq/源seq/tick/age；busy可能跳窗，两seq允许不同。
5. 网页显式选真实设备，逐项切图，CSV的value/unit/status/身份与API对齐；缓存不加点，新查询同值仍加点。断线按各阈值过期，失败不能变0；恢复后按新完成结果显示。

## 统一字段合同（schema_version=2）
UTF-8单行JSON+CRLF，顶层：schema_version、device_id、seq、t_ms、window_ms=3000、data、私有token。当前固件不发boot_id；模拟器可选UUID。ACK仍为ok/device_id/seq/id/duplicate。
| data键 | 单位 | 周期 / 过期阈值 |
|---|---|---|
| soil_moisture_pct | %相对湿润度 | 3s / 9s |
| soil_ph | 无量纲 | 3s / 9s |
| wind_speed_mps | m/s | 3s / 9s |
| wind_direction_deg | °参考角度[0,360) | 3s / 9s |
| temperature_c | ℃ | 10s / 30s |
| air_humidity_rh_pct | %RH | 10s / 30s |
| light_lux | lx | 10s / 30s |
| pressure_kpa | kPa | 60s / 180s |
| pm25_ug_m3 | μg/m³ | 30s / 90s |
| pm10_ug_m3 | μg/m³ | 30s / 90s |

每项固定对象：value数字/null、status、sample_seq、sample_t_ms、age_ms，可选range=LOW/OK/HIGH。只有OK带数字，失败null；NO_DATA身份/年龄全部null。有效0与缺失严格区分。
模拟量源seq为窗口编号、tick为窗口末；上报seq为发送尝试编号，允许busy跳窗。天气源seq为最近完成查询编号，成功tick为响应结束，失败tick为事务真实完成；查询中保留上次完成结果。age_ms为编码时无符号tick差，不是UTC，不覆盖未知网络滞留。不上传ADC、电压、引脚或窗口诊断。

## API、数据库与网页
/api/config返回脱敏V2/旧例、指标规格、端口与鉴权开关；/api/overview返回上报/测量总数、设备连接和十项当前状态；当前值独立于历史过滤。
/api/readings保留原上报分页，/api/measurements按device_id/metric/hours/status/limit/before_id查独立测量；/api/export.csv按相同条件导出物理长表，UTF-8 BOM，最多10000行，无ADC/电压/token。
/ws保留VIEW_TOKEN首条鉴权、同源Origin、ready/reading/resync/ping；网页3秒重连、5秒HTTP兜底。

SQLite user_version=2，readings原ID/payload保留，新增schema_version/run_id；device_runs和measurements增量回填旧湿度，幂等。上报次数与测量点数分开。运行段+指标+源seq+源tick去重缓存，同值新查询仍加点；全部事务提交后ACK。报告age加服务器流逝时间，缓存重复不会重置/年轻化；晚到旧结果不覆盖新故障。
无boot_id不能全局区分重启与重放：已建立段（旧seq>=5、tick>=60s）同时发生早期seq<=3、tick<=30s双倒退时才保守切段；单TCP重连不切，回绕采用模差。短时重启与不可区分重放仍有局限。
页面四主卡+六气象卡、独立质量/年龄；风向指针走最短路，跨0曲线断线；不同量纲分图，趋势最多1000点并标实际覆盖。真实优先，demo需显式选择；无气体/雨量/ADC卡。
