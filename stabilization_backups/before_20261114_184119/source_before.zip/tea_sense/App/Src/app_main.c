#include "app_main.h"
#include "app_config.h"
#include "app_weather.h"
#include "sensor_soil.h"
#include "bsp_console.h"
#include "bsp_dtu.h"
#include "app_upload.h"
#include "bsp_time.h"
#include <stdio.h>
#include <string.h>

#define APP_DTU_LINE_SIZE APP_UPLOAD_ACK_CAPACITY
#if APP_WINDOW_EXPECTED_ROUNDS > SENSOR_WIND_DIRECTION_WINDOW_CAPACITY
#error Sample window exceeds fixed wind direction capacity
#endif

static uint32_t s_last_sample_tick_ms;
static uint32_t s_window_start_tick_ms;
static uint8_t s_sampling_started;
static SensorSoilWindow s_soil_window;
static SensorWindSpeedWindow s_wind_window;
static AppAd3Window s_ad3_window;
static SensorPhWindow s_ad4_window;
static SensorWindDirectionWindow s_direction_window;
static AppUploadSnapshot s_snapshot;
static uint8_t s_window_ready;
static AppDiagnostics s_diagnostics;
static uint8_t s_dtu_tx_pending, s_dtu_early_ack;
static uint64_t s_dtu_early_id;
static uint8_t s_dtu_rx_line[APP_DTU_LINE_SIZE];
static uint8_t s_dtu_rx_chunk[32];
static size_t s_dtu_rx_length;
static uint32_t s_dtu_sequence;
static uint32_t s_dtu_last_attempt_ms;
static uint8_t s_dtu_attempted;
static uint32_t s_dtu_sent_ms;
static uint8_t s_dtu_waiting;
static uint8_t s_dtu_discard_line;

static void App_RawWindowReset(AppAdcRawWindow *window)
{
  memset(window, 0, sizeof(*window));
  window->raw_min = UINT16_MAX;
}

static void App_RawWindowAdd(AppAdcRawWindow *window, const BspAdcResult *sample)
{
  ++window->sample_count;
  if (sample->valid && sample->status == BSP_ADC_OK)
  {
    ++window->valid_count;
    window->raw_sum += sample->raw;
    if (sample->raw < window->raw_min) { window->raw_min = sample->raw; }
    if (sample->raw > window->raw_max) { window->raw_max = sample->raw; }
    return;
  }
  if ((unsigned)sample->status <= BSP_ADC_OUT_OF_RANGE)
  { ++window->error_counts[sample->status]; }
  if (sample->stop_attempted && sample->stop_status != BSP_ADC_HAL_OK)
  { ++window->cleanup_errors; }
  if (sample->prepare_attempted && sample->prepare_status != BSP_ADC_HAL_OK)
  { ++window->prepare_errors; }
  if (sample->config_attempted && sample->config_status != BSP_ADC_HAL_OK)
  { ++window->config_errors; }
  window->last_error = *sample;
}

static void App_DtuConsumeByte(uint8_t byte, uint32_t now_ms)
{
  if (s_dtu_discard_line != 0U)
  {
    if (byte == '\n')
    {
      s_dtu_discard_line = 0U;
    }
    return;
  }
  if (s_dtu_rx_length == sizeof(s_dtu_rx_line))
  {
    s_dtu_rx_length = 0U;
    s_dtu_discard_line = (byte == '\n') ? 0U : 1U;
    ++s_diagnostics.dtu_line_drops;
    return;
  }
  s_dtu_rx_line[s_dtu_rx_length++] = byte;
  if (byte != '\n')
  {
    return;
  }
  if (s_dtu_tx_pending || (s_dtu_waiting && (uint32_t)(now_ms - s_dtu_sent_ms) < APP_DTU_TIMEOUT_MS))
  {
    AppUploadAck ack;
    if (AppUpload_ParseAck((const char *)s_dtu_rx_line, s_dtu_rx_length, s_dtu_sequence, &ack) == APP_UPLOAD_ACK_ACCEPTED)
    {
      if(s_dtu_tx_pending) { s_dtu_early_ack=1U; s_dtu_early_id=ack.id; }
      else {
        s_dtu_waiting=0U; ++s_diagnostics.dtu_ack_count;
        s_diagnostics.dtu_ack_sequence=s_dtu_sequence; s_diagnostics.dtu_ack_id=ack.id;
      }
    }
  }
  s_dtu_rx_length = 0U;
}

static void App_DtuRead(uint32_t now_ms)
{
  unsigned batch;
  /* Drain up to one ring per pass; continuous noise cannot starve the soil task. */
  for (batch = 0U; batch < 8U; ++batch)
  {
    size_t index;
    BspDtuReadResult received = BspDtu_Read(s_dtu_rx_chunk, sizeof(s_dtu_rx_chunk));
    if (received.data_lost != 0U)
    {
      if (s_dtu_discard_line == 0U)
      {
        ++s_diagnostics.dtu_stream_gaps;
      }
      s_dtu_discard_line = 1U;
      s_dtu_rx_length = 0U;
    }
    for (index = 0U; index < received.length; ++index)
    {
      App_DtuConsumeByte(s_dtu_rx_chunk[index], now_ms);
    }
    if (received.length == 0U)
    {
      break;
    }
  }
}

static void App_DtuProcess(uint32_t now_ms)
{
  BspDtuTxResult transmitted=BspDtu_Process();
  if(s_dtu_tx_pending && transmitted.finished) {
    s_dtu_tx_pending=0U;
    if(transmitted.status==BSP_DTU_OK) {
      s_dtu_sent_ms=transmitted.completed_ms; s_dtu_waiting=1U;
      if(s_dtu_early_ack) {
        s_dtu_waiting=0U; ++s_diagnostics.dtu_ack_count;
        s_diagnostics.dtu_ack_sequence=s_dtu_sequence; s_diagnostics.dtu_ack_id=s_dtu_early_id;
      }
    } else { ++s_diagnostics.dtu_tx_errors; }
    s_dtu_early_ack=0U;
  }
  App_DtuRead(now_ms);
  if (s_dtu_waiting && (uint32_t)(now_ms - s_dtu_sent_ms) >= APP_DTU_TIMEOUT_MS)
  {
    ++s_diagnostics.dtu_timeouts;
    s_dtu_waiting = 0U;
  }
}

static uint8_t App_CloseWindow(uint32_t now_ms)
{
  uint32_t elapsed = (uint32_t)(now_ms - s_window_start_tick_ms);
  uint32_t windows;
  SensorPhWindowResult soil_ph;
  AppUploadValue *analog[4];
  unsigned index;
  if (elapsed < APP_SAMPLE_WINDOW_MS) { return 0U; }
  if (s_window_ready) { ++s_diagnostics.upload_skipped_rate; }
  windows = elapsed / APP_SAMPLE_WINDOW_MS;
  if (windows > 1U)
  {
    /* No backlog: old partial/empty windows are skipped, not replayed. The
     * latest completed window had no samples while this task was absent. */
    s_diagnostics.upload_skipped_late += windows - 1U;
    SensorSoil_WindowReset(&s_soil_window);
    SensorWindSpeed_WindowReset(&s_wind_window);
    App_RawWindowReset(&s_ad3_window);
    SensorPh_WindowReset(&s_ad4_window);
  SensorWindDirection_WindowReset(&s_direction_window);
  }
  s_window_start_tick_ms += windows * APP_SAMPLE_WINDOW_MS;
  s_diagnostics.completed_windows += windows;
  s_diagnostics.last_window_end_ms = s_window_start_tick_ms;
  s_diagnostics.last_window = SensorSoil_WindowFinish(&s_soil_window,
    APP_WINDOW_EXPECTED_ROUNDS, APP_WINDOW_MIN_VALID_PERCENT);
  s_diagnostics.last_wind_window = SensorWindSpeed_WindowFinish(&s_wind_window,
    APP_WINDOW_EXPECTED_ROUNDS, APP_WINDOW_MIN_VALID_PERCENT);
  s_diagnostics.last_ad3_window = s_ad3_window;
  soil_ph=SensorPh_WindowFinish(&s_ad4_window,APP_WINDOW_EXPECTED_ROUNDS,APP_WINDOW_MIN_VALID_PERCENT);
  s_diagnostics.last_ad4_window=soil_ph.raw;
  s_diagnostics.last_soil_ph=soil_ph.soil_ph; s_diagnostics.ph_used_count=soil_ph.used_count;
  s_diagnostics.last_direction_window=SensorWindDirection_WindowFinish(&s_direction_window,
    APP_WINDOW_EXPECTED_ROUNDS,APP_WINDOW_MIN_VALID_PERCENT);
  s_snapshot.window_seq=s_diagnostics.completed_windows; s_snapshot.window_end_ms=s_window_start_tick_ms;
  analog[0]=&s_snapshot.soil_moisture_pct; analog[1]=&s_snapshot.wind_speed_mps;
  analog[2]=&s_snapshot.wind_direction_deg; analog[3]=&s_snapshot.soil_ph;
  for(index=0U;index<4U;++index) {
    memset(analog[index],0,sizeof(*analog[index])); analog[index]->has_sample=1U;
    analog[index]->sample_seq=s_snapshot.window_seq; analog[index]->sample_t_ms=s_snapshot.window_end_ms;
    analog[index]->status="WINDOW_INSUFFICIENT";
  }
  analog[0]->valid=s_diagnostics.last_window.status==SENSOR_SOIL_WINDOW_OK;
  analog[0]->value=s_diagnostics.last_window.moisture_pct_x100;
  analog[0]->range=s_diagnostics.last_window.range==SENSOR_SOIL_RANGE_LOW?"LOW":
    s_diagnostics.last_window.range==SENSOR_SOIL_RANGE_HIGH?"HIGH":"OK";
  analog[1]->valid=s_diagnostics.last_wind_window.value.valid;
  analog[1]->value=s_diagnostics.last_wind_window.value.wind_speed_mps_x100;
  analog[1]->range=SensorWindSpeed_RangeName(s_diagnostics.last_wind_window.value.range);
  analog[2]->valid=s_diagnostics.last_direction_window.valid;
  analog[2]->value=s_diagnostics.last_direction_window.angle_deg_x100;
  analog[2]->range=SensorWindDirection_RangeName(s_diagnostics.last_direction_window.range);
  if(s_diagnostics.last_direction_window.status==SENSOR_WIND_DIRECTION_WINDOW_UNDEFINED) { analog[2]->status="DIRECTION_UNDEFINED"; }
  if(s_diagnostics.last_direction_window.status==SENSOR_WIND_DIRECTION_WINDOW_CAPACITY_EXCEEDED) { analog[2]->status="WINDOW_CAPACITY"; }
  analog[3]->valid=soil_ph.soil_ph.valid; analog[3]->value=soil_ph.soil_ph.soil_ph_x100;
  analog[3]->range=SensorPh_RangeName(soil_ph.soil_ph.range);
  for(index=0U;index<4U;++index) { if(analog[index]->valid) { analog[index]->status="OK"; } }
  SensorSoil_WindowReset(&s_soil_window);
  SensorWindSpeed_WindowReset(&s_wind_window);
  App_RawWindowReset(&s_ad3_window);
  SensorPh_WindowReset(&s_ad4_window);
  SensorWindDirection_WindowReset(&s_direction_window);
  s_window_ready = 1U;
  return 1U;
}

static AppUploadValue App_WeatherResult(SensorWeatherItem item, uint16_t field, int64_t value, uint32_t now_ms)
{
  AppUploadValue result;
  const SensorWeatherMeasurement *measurement=SensorWeather_GetMeasurement(item);
  memset(&result,0,sizeof(result)); result.status="NO_DATA";
  if(!measurement->has_completed) { return result; }
  result.has_sample=1U; result.sample_seq=measurement->completed_sequence;
  result.sample_t_ms=measurement->sample_t_ms;
  result.status=SensorWeather_StatusName(measurement->completed_status);
  if(measurement->completed_status==SENSOR_WEATHER_OK) {
    if(!(measurement->valid_fields&field)) { result.status="INVALID_VALUE"; }
    else if((uint32_t)(now_ms-result.sample_t_ms)>3U*AppWeather_PeriodMs(item)) { result.status="STALE"; }
    else { result.valid=1U; result.value=value; }
  }
  return result;
}

static void App_UploadWindow(uint32_t now_ms)
{
  int length;
  size_t capacity;
  char *buffer;
  BspDtuStatus status;
  const SensorWeatherValue *temp=&SensorWeather_GetMeasurement(SENSOR_WEATHER_TEMP_HUM)->completed_value;
  const SensorWeatherValue *light=&SensorWeather_GetMeasurement(SENSOR_WEATHER_LIGHT)->completed_value;
  const SensorWeatherValue *pm=&SensorWeather_GetMeasurement(SENSOR_WEATHER_PM)->completed_value;
  const SensorWeatherValue *pressure=&SensorWeather_GetMeasurement(SENSOR_WEATHER_PRESSURE)->completed_value;
  if(!s_window_ready) { return; }
  if(s_dtu_waiting || s_dtu_tx_pending) {
    s_window_ready=0U; ++s_diagnostics.upload_skipped_busy; return;
  }
  if(!AppUpload_IsConfigured()) { s_window_ready=0U; return; }
  if(s_dtu_attempted && (uint32_t)(now_ms-s_dtu_last_attempt_ms)<APP_DTU_PERIOD_MS) { return; }
  buffer=BspDtu_TxBuffer(&capacity);
  if(!buffer) { s_window_ready=0U; ++s_diagnostics.upload_skipped_busy; return; }
  s_window_ready=0U; s_dtu_last_attempt_ms=now_ms; s_dtu_attempted=1U;
  s_diagnostics.dtu_last_sequence=++s_dtu_sequence;
  s_snapshot.temperature_c=App_WeatherResult(SENSOR_WEATHER_TEMP_HUM,SENSOR_WEATHER_FIELD_TEMPERATURE,temp->temperature_c_x10,now_ms);
  s_snapshot.air_humidity_rh_pct=App_WeatherResult(SENSOR_WEATHER_TEMP_HUM,SENSOR_WEATHER_FIELD_HUMIDITY,temp->humidity_rh_pct_x10,now_ms);
  s_snapshot.light_lux=App_WeatherResult(SENSOR_WEATHER_LIGHT,SENSOR_WEATHER_FIELD_LIGHT,light->light_lux,now_ms);
  s_snapshot.pm25_ug_m3=App_WeatherResult(SENSOR_WEATHER_PM,SENSOR_WEATHER_FIELD_PM25,pm->pm25_ug_m3,now_ms);
  s_snapshot.pm10_ug_m3=App_WeatherResult(SENSOR_WEATHER_PM,SENSOR_WEATHER_FIELD_PM10,pm->pm10_ug_m3,now_ms);
  s_snapshot.pressure_kpa=App_WeatherResult(SENSOR_WEATHER_PRESSURE,SENSOR_WEATHER_FIELD_PRESSURE,pressure->pressure_kpa_x100,now_ms);
  if(capacity>APP_UPLOAD_FRAME_CAPACITY) { capacity=APP_UPLOAD_FRAME_CAPACITY; }
  length=AppUpload_Format(buffer,capacity,s_dtu_sequence,now_ms,&s_snapshot);
  if(length<0) { ++s_diagnostics.dtu_format_errors; return; }
  s_dtu_early_ack=0U; s_dtu_tx_pending=1U;
  status=BspDtu_StartSend((size_t)length);
  if(status!=BSP_DTU_OK) { s_dtu_tx_pending=0U; ++s_diagnostics.dtu_tx_errors; }

}

void App_Init(void)
{
  memset(&s_diagnostics, 0, sizeof(s_diagnostics));
  BspConsole_Init();
  s_diagnostics.dtu_init_status = BspDtu_Init();
  BspAdc_Init();
  AppWeather_Init();
  /* First real main-loop sample may occur at start; windows are [start,end). */
  s_window_start_tick_ms = BspTime_GetTickMs();
  s_last_sample_tick_ms = s_window_start_tick_ms;
  memset(&s_snapshot,0,sizeof(s_snapshot));
  s_dtu_tx_pending=s_dtu_early_ack=0U;
  s_sampling_started = 0U;
  SensorSoil_WindowReset(&s_soil_window);
  SensorWindSpeed_WindowReset(&s_wind_window);
  App_RawWindowReset(&s_ad3_window);
  SensorPh_WindowReset(&s_ad4_window);
  SensorWindDirection_WindowReset(&s_direction_window);
  s_window_ready = 0U;
  s_dtu_last_attempt_ms = s_window_start_tick_ms;
  s_dtu_attempted = 0U;
  s_dtu_sent_ms = 0U;
  s_dtu_sequence = 0U;
  s_dtu_rx_length = 0U;
  s_dtu_waiting = 0U;
  s_dtu_discard_line = 0U;
}

/* Keep the round snapshot frame off the receive/parser/printf call paths. */
static void App_AcquireRound(uint32_t now_ms)
{
  AppSampleRound round;
  memset(&round, 0, sizeof(round));
  s_sampling_started = 1U;
  s_last_sample_tick_ms = now_ms;
  round.round_id = ++s_diagnostics.sequence;
  round.round_t_ms = now_ms;
  round.soil_read_start_ms = BspTime_GetTickMs();
  round.soil = SensorSoil_Read();
  round.soil_read_end_ms = BspTime_GetTickMs();
  round.wind_read_start_ms = BspTime_GetTickMs();
  round.wind = SensorWindSpeed_Read();
  round.wind_read_end_ms = BspTime_GetTickMs();
  /* Preserve the existing AD0/AD2 pair duration. */
  round.pair_span_ms = (uint32_t)(BspTime_GetTickMs() - round.round_t_ms);
  round.ad3_read_start_ms = BspTime_GetTickMs();
  round.ad3 = BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_DIRECTION_AD3);
  round.ad3_read_end_ms = BspTime_GetTickMs();
  round.ad4_read_start_ms = BspTime_GetTickMs();
  round.ad4 = BspAdc_ReadRaw(BSP_ADC_INPUT_PH_AD4);
  round.ad4_read_end_ms = BspTime_GetTickMs();
  if (round.ad4.valid && round.ad4.status == BSP_ADC_OK)
  {
    round.soil_ph = SensorPh_Convert(round.ad4.raw, 1U);
  }
  if (round.ad3.valid && round.ad3.status == BSP_ADC_OK)
  {
    round.wind_direction = SensorWindDirection_Convert((uint32_t)round.ad3.raw * 100U);
  }
  /* All four belong to round_t_ms, even if a later read crosses a boundary. */
  SensorSoil_WindowAdd(&s_soil_window, &round.soil.adc);
  SensorWindSpeed_WindowAdd(&s_wind_window, &round.wind.adc);
  App_RawWindowAdd(&s_ad3_window, &round.ad3);
  SensorPh_WindowAdd(&s_ad4_window, &round.ad4);
  SensorWindDirection_WindowAdd(&s_direction_window,&round.wind_direction);
  if (!round.ad3.valid) { ++s_diagnostics.ad3_sample_errors; }
  if (!round.ad4.valid) { ++s_diagnostics.ad4_sample_errors; }
  round.round_span_ms = (uint32_t)(BspTime_GetTickMs() - round.round_t_ms);
  s_diagnostics.last_round = round;
  if (!round.soil.adc.valid)
  {
    ++s_diagnostics.sample_errors;
    if ((unsigned)round.soil.adc.status <= BSP_ADC_OUT_OF_RANGE)
    {
      ++s_diagnostics.sample_error_counts[round.soil.adc.status];
    }
    s_diagnostics.last_adc_error = round.soil.adc;
    if (round.soil.adc.stop_attempted && round.soil.adc.stop_status != BSP_ADC_HAL_OK)
    {
      ++s_diagnostics.cleanup_errors;
    }
  }
  if (!round.wind.adc.valid)
  {
    const BspAdcResult *error = &round.wind.adc;
    SensorWindSpeedDiagnostics *diagnostics = &s_diagnostics.wind_diagnostics;
    ++s_diagnostics.wind_sample_errors;
    if ((unsigned)error->status <= BSP_ADC_OUT_OF_RANGE) { ++diagnostics->error_counts[error->status]; }
    if (error->stop_attempted && error->stop_status != BSP_ADC_HAL_OK) { ++diagnostics->cleanup_error_count; }
    if (error->prepare_attempted && error->prepare_status != BSP_ADC_HAL_OK) { ++diagnostics->prepare_error_count; }
    if (error->config_attempted && error->config_status != BSP_ADC_HAL_OK) { ++diagnostics->config_error_count; }
    diagnostics->last_error = *error;
  }
}

void App_Process(void)
{
  uint32_t now_ms;
  uint8_t closed;
  BspConsole_Process(); now_ms=BspTime_GetTickMs(); App_DtuProcess(now_ms);
  now_ms=BspTime_GetTickMs(); closed=App_CloseWindow(now_ms);
  if(!s_sampling_started || (uint32_t)(now_ms-s_last_sample_tick_ms)>=APP_SAMPLE_ROUND_PERIOD_MS) { App_AcquireRound(now_ms); }
  AppWeather_Process(); App_UploadWindow(BspTime_GetTickMs());
  if(closed)
  {
    int failed=0;
    const AppUploadValue *soil=&s_snapshot.soil_moisture_pct, *wind=&s_snapshot.wind_speed_mps;
    const AppUploadValue *direction=&s_snapshot.wind_direction_deg, *soil_ph=&s_snapshot.soil_ph;
    failed|=printf("\xE5\x9C\x9F\xE5\xA3\xA4\xE6\xB9\xBF\xE5\xBA\xA6\xEF\xBC\x9A")<0;
    if(soil->valid) { failed|=printf("%lu.%02lu%%",(unsigned long)(soil->value/100),(unsigned long)(soil->value%100))<0; }
    else { failed|=printf("\xE6\x95\xB0\xE6\x8D\xAE\xE6\x97\xA0\xE6\x95\x88")<0; }
    failed|=printf("\xEF\xBC\x8C\xE9\xA3\x8E\xE9\x80\x9F\xEF\xBC\x9A")<0;
    if(wind->valid) { failed|=printf("%lu.%02lu m/s",(unsigned long)(wind->value/100),(unsigned long)(wind->value%100))<0; }
    else { failed|=printf("\xE6\x95\xB0\xE6\x8D\xAE\xE6\x97\xA0\xE6\x95\x88")<0; }
    failed|=printf("\xEF\xBC\x8C\xE9\xA3\x8E\xE5\x90\x91\xE8\xA7\x92\xE5\xBA\xA6\xEF\xBC\x9A")<0;
    if(direction->valid) { failed|=printf("%lu.%02lu\xC2\xB0",(unsigned long)(direction->value/100),(unsigned long)(direction->value%100))<0; }
    else { failed|=printf("\xE6\x95\xB0\xE6\x8D\xAE\xE6\x97\xA0\xE6\x95\x88")<0; }
    failed|=printf("\xEF\xBC\x8C\xE5\x9C\x9F\xE5\xA3\xA4 pH\xEF\xBC\x9A")<0;
    if(soil_ph->valid) { failed|=printf("%lu.%02lu",(unsigned long)(soil_ph->value/100),(unsigned long)(soil_ph->value%100))<0; }
    else { failed|=printf("\xE6\x95\xB0\xE6\x8D\xAE\xE6\x97\xA0\xE6\x95\x88")<0; }
    failed|=printf("\r\n")<0;
    if(failed) { ++s_diagnostics.printf_errors; clearerr(stdout); }
  }
}

const AppDiagnostics *App_GetDiagnostics(void)
{
  return &s_diagnostics;
}
