#include "app_upload.h"
#include "app_config.h"
#include "core_json.h"
#include <stdio.h>
#include <string.h>

uint8_t AppUpload_IsConfigured(void)
{
  return (APP_INGEST_TOKEN_CONFIGURED == 1 && sizeof(APP_INGEST_TOKEN_JSON) > 3U) ? 1U : 0U;
}

/* Keep each literal format visible to ARMCC's integer-only printf selection. */
static uint8_t AppUpload_Commit(size_t capacity, size_t *offset, int length)
{
  if(length<0 || (size_t)length>=capacity-*offset) { return 0U; }
  *offset+=(size_t)length; return 1U;
}
#define APP_UPLOAD_APPEND(...) do { \
  int written=snprintf(buffer+offset,capacity-offset,__VA_ARGS__); \
  if(!AppUpload_Commit(capacity,&offset,written)) { return -1; } \
} while(0)

int AppUpload_Format(char *buffer, size_t capacity, uint32_t sequence,
                     uint32_t now_ms, const AppUploadSnapshot *snapshot)
{
  size_t offset=0U;
  unsigned index;
  const char *names[10]={"soil_moisture_pct","wind_speed_mps","wind_direction_deg","soil_ph",
    "temperature_c","air_humidity_rh_pct","light_lux","pressure_kpa","pm25_ug_m3","pm10_ug_m3"};
  const AppUploadValue *values[10];
  const uint32_t scales[10]={100U,100U,100U,100U,10U,10U,1U,100U,1U,1U};
  if(!buffer || !snapshot || !capacity || !AppUpload_IsConfigured()) { return -1; }
  values[0]=&snapshot->soil_moisture_pct; values[1]=&snapshot->wind_speed_mps;
  values[2]=&snapshot->wind_direction_deg; values[3]=&snapshot->soil_ph;
  values[4]=&snapshot->temperature_c; values[5]=&snapshot->air_humidity_rh_pct;
  values[6]=&snapshot->light_lux; values[7]=&snapshot->pressure_kpa;
  values[8]=&snapshot->pm25_ug_m3; values[9]=&snapshot->pm10_ug_m3;
  APP_UPLOAD_APPEND(
    "{\"schema_version\":2,\"device_id\":\"%s\",\"seq\":%lu,\"t_ms\":%lu,\"window_ms\":3000,\"data\":{",
    APP_DEVICE_ID,(unsigned long)sequence,(unsigned long)snapshot->window_end_ms);
  for(index=0U;index<10U;++index)
  {
    const AppUploadValue *value=values[index];
    const char *status=value->status?value->status:"NO_DATA";
    if(strlen(status)>40U || (value->valid && (!value->has_sample || strcmp(status,"OK")))) { return -1; }
    APP_UPLOAD_APPEND("%s\"%s\":{\"value\":",index?",":"",names[index]);
    if(value->valid)
    {
      uint64_t magnitude=value->value<0?(uint64_t)(-(value->value+1))+1U:(uint64_t)value->value;
      const char *sign=value->value<0?"-":"";
      if(magnitude>UINT32_MAX) { return -1; }
      if(scales[index]==1U) {
        APP_UPLOAD_APPEND("%s%lu",sign,(unsigned long)magnitude);
      } else {
        if(scales[index]==100U) {
          APP_UPLOAD_APPEND("%s%lu.%02lu",sign,(unsigned long)(magnitude/100U),(unsigned long)(magnitude%100U));
        } else {
          APP_UPLOAD_APPEND("%s%lu.%lu",sign,(unsigned long)(magnitude/10U),(unsigned long)(magnitude%10U));
        }
      }
    }
    else APP_UPLOAD_APPEND("null");
    APP_UPLOAD_APPEND(",\"status\":\"%s\",",status);
    if(value->has_sample) {
      APP_UPLOAD_APPEND("\"sample_seq\":%lu,\"sample_t_ms\":%lu,\"age_ms\":%lu",
        (unsigned long)value->sample_seq,(unsigned long)value->sample_t_ms,
        (unsigned long)(uint32_t)(now_ms-value->sample_t_ms));
    } else APP_UPLOAD_APPEND("\"sample_seq\":null,\"sample_t_ms\":null,\"age_ms\":null");
    if(value->valid && value->range) { APP_UPLOAD_APPEND(",\"range\":\"%s\"",value->range); }
    APP_UPLOAD_APPEND("}");
  }
  APP_UPLOAD_APPEND("},\"token\":%s}\r\n",APP_INGEST_TOKEN_JSON);
  return (int)offset;
}

static int AppUpload_HexDigit(char character)
{
  if (character >= '0' && character <= '9') { return character - '0'; }
  if (character >= 'a' && character <= 'f') { return character - 'a' + 10; }
  if (character >= 'A' && character <= 'F') { return character - 'A' + 10; }
  return -1;
}

/* Match ASCII protocol identifiers, including equivalent JSON escapes. */
static uint8_t AppUpload_StringEquals(const char *text, size_t length, const char *expected)
{
  size_t index = 0U;
  while (index < length)
  {
    unsigned character = (unsigned char)text[index++];
    if (character == '\\')
    {
      if (index == length) { return 0U; }
      character = (unsigned char)text[index++];
      if (character == 'u')
      {
        unsigned digit;
        character = 0U;
        if (length - index < 4U) { return 0U; }
        for (digit = 0U; digit < 4U; ++digit)
        {
          int value = AppUpload_HexDigit(text[index++]);
          if (value < 0) { return 0U; }
          character = character * 16U + (unsigned)value;
        }
      }
      else if (character != '\\' && character != '"' && character != '/') { return 0U; }
    }
    if (*expected == '\0' || character != (unsigned char)*expected++) { return 0U; }
  }
  return *expected == '\0' ? 1U : 0U;
}

static uint8_t AppUpload_ParseUnsigned(const char *text, size_t length, uint64_t maximum, uint64_t *value)
{
  size_t index;
  uint64_t number = 0U;
  if (!length) { return 0U; }
  for (index = 0U; index < length; ++index)
  {
    unsigned digit = (unsigned char)text[index] - (unsigned)'0';
    if (digit > 9U || number > (maximum - digit) / 10U) { return 0U; }
    number = number * 10U + digit;
  }
  *value = number;
  return 1U;
}

AppUploadAckStatus AppUpload_ParseAck(const char *line, size_t length,
                                     uint32_t expected_sequence, AppUploadAck *ack)
{
  size_t start = 0U, next = 0U, leading = 0U;
  unsigned seen = 0U;
  uint8_t ok = 0U, device_matches = 0U;
  uint64_t sequence = 0U, id = 0U;
  JSONPair_t pair;
  JSONStatus_t result;
  if (!line || !ack || JSON_Validate(line, length) != JSONSuccess) { return APP_UPLOAD_ACK_INVALID; }
  while (leading < length && (line[leading] == ' ' || line[leading] == '\t' || line[leading] == '\r' || line[leading] == '\n')) { ++leading; }
  if (leading == length || line[leading] != '{') { return APP_UPLOAD_ACK_INVALID; }
  while ((result = JSON_Iterate(line, length, &start, &next, &pair)) == JSONSuccess)
  {
    unsigned bit = 0U;
    if (AppUpload_StringEquals(pair.key, pair.keyLength, "ok"))
    {
      bit = 1U;
      if (pair.jsonType != JSONTrue && pair.jsonType != JSONFalse) { return APP_UPLOAD_ACK_INVALID; }
      ok = pair.jsonType == JSONTrue ? 1U : 0U;
    }
    else if (AppUpload_StringEquals(pair.key, pair.keyLength, "device_id"))
    {
      bit = 2U;
      if (pair.jsonType != JSONString) { return APP_UPLOAD_ACK_INVALID; }
      device_matches = AppUpload_StringEquals(pair.value, pair.valueLength, APP_DEVICE_ID);
    }
    else if (AppUpload_StringEquals(pair.key, pair.keyLength, "seq"))
    {
      bit = 4U;
      if (pair.jsonType != JSONNumber || !AppUpload_ParseUnsigned(pair.value, pair.valueLength, UINT32_MAX, &sequence)) { return APP_UPLOAD_ACK_INVALID; }
    }
    else if (AppUpload_StringEquals(pair.key, pair.keyLength, "id"))
    {
      bit = 8U;
      if (pair.jsonType != JSONNumber || !AppUpload_ParseUnsigned(pair.value, pair.valueLength, INT64_MAX, &id) || !id) { return APP_UPLOAD_ACK_INVALID; }
    }
    if (bit && (seen & bit)) { return APP_UPLOAD_ACK_INVALID; }
    seen |= bit;
  }
  if (result != JSONNotFound) { return APP_UPLOAD_ACK_INVALID; }
  if (seen != 15U || !ok || !device_matches || sequence != expected_sequence) { return APP_UPLOAD_ACK_IGNORED; }
  ack->id = id;
  return APP_UPLOAD_ACK_ACCEPTED;
}
