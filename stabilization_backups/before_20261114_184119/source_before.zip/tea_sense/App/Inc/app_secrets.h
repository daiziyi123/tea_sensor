#ifndef APP_SECRETS_H
#define APP_SECRETS_H
/* Local private upload credential. Never print or commit this file. */
#define APP_INGEST_TOKEN_CONFIGURED 1
#define APP_INGEST_TOKEN_JSON "\"e5fe7ef330927d01f254548c480394125ded082e7ffa6da7\""
#endif
