#ifndef APP_UPLOAD_H
#define APP_UPLOAD_H
#include <stddef.h>
#include <stdint.h>
#include "sensor_soil.h"
#include "app_config.h"
/* Test include paths can supply fixture credentials; MDK uses local App/Inc. */
#include <app_secrets.h>

/* Exact escaped local token size plus bounded numeric/status/device fields. */
#define APP_UPLOAD_FRAME_CAPACITY (sizeof(APP_INGEST_TOKEN_JSON) + sizeof(APP_DEVICE_ID) + 2560U)
#define APP_UPLOAD_ACK_CAPACITY 512U

typedef enum
{
  APP_UPLOAD_ACK_INVALID = 0,
  APP_UPLOAD_ACK_IGNORED,
  APP_UPLOAD_ACK_ACCEPTED
} AppUploadAckStatus;

typedef struct
{
  uint64_t id;
} AppUploadAck;

/* Fixed V2 wire contract, not a sensor registry. Values use the field's fixed
 * scale (x100, x10 or integer), and source ticks are never UTC timestamps. */
typedef struct
{
  int64_t value;
  uint32_t sample_seq, sample_t_ms;
  const char *status, *range;
  uint8_t valid, has_sample;
} AppUploadValue;
typedef struct
{
  uint32_t window_seq, window_end_ms;
  AppUploadValue soil_moisture_pct, wind_speed_mps, wind_direction_deg, soil_ph;
  AppUploadValue temperature_c, air_humidity_rh_pct, light_lux, pressure_kpa, pm25_ug_m3, pm10_ug_m3;
} AppUploadSnapshot;

uint8_t AppUpload_IsConfigured(void);
int AppUpload_Format(char *buffer, size_t capacity, uint32_t sequence,
                     uint32_t now_ms, const AppUploadSnapshot *snapshot);
AppUploadAckStatus AppUpload_ParseAck(const char *line, size_t length,
                                     uint32_t expected_sequence, AppUploadAck *ack);
#endif
