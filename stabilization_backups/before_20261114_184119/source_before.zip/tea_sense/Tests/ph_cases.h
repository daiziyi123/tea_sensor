#ifndef PH_CASES_H
#define PH_CASES_H

static void Test_SoilPhConversion(void)
{
  static const struct
  {
    uint64_t sum;
    uint32_t count;
    int32_t input_mv;
    uint32_t soil_ph_x100;
    SensorPhRange range;
  } cases[] = {
    {6222U,100U,0,300U,SENSOR_PH_RANGE_OK},
    {1571624U,100U,2500,600U,SENSOR_PH_RANGE_OK},
    {2093425U,100U,3333,700U,SENSOR_PH_RANGE_OK},
    {3137026U,100U,5000,900U,SENSOR_PH_RANGE_OK},
    {6221U,100U,0,300U,SENSOR_PH_RANGE_LOW},
    {6223U,100U,0,300U,SENSOR_PH_RANGE_OK},
    {3137025U,100U,5000,900U,SENSOR_PH_RANGE_OK},
    {3137027U,100U,5000,900U,SENSOR_PH_RANGE_HIGH},
    {0U,1U,-10,300U,SENSOR_PH_RANGE_LOW},
    {65535U,1U,10456,900U,SENSOR_PH_RANGE_HIGH},
    {34567U,1U,5511,900U,SENSOR_PH_RANGE_HIGH},
    /* raw=88.311: pre-rounding raw to 88.31 or mV to 4 yields wrong pH 3.00. */
    {88311U,1000U,4,301U,SENSOR_PH_RANGE_OK},
    {56300U,30U,290,335U,SENSOR_PH_RANGE_OK},
    {65537U,3U,3479,717U,SENSOR_PH_RANGE_OK},
    {(uint64_t)UINT32_MAX*65535U,UINT32_MAX,10456,900U,SENSOR_PH_RANGE_HIGH},
    {(uint64_t)UINT32_MAX*32768U,UINT32_MAX,5223,900U,SENSOR_PH_RANGE_HIGH},
    {100000000U,UINT32_MAX,-10,300U,SENSOR_PH_RANGE_LOW}
  };
  SensorPhValue soil_ph;
  unsigned i, before;
  uint32_t raw, last_soil_ph_x100=300U;
  int32_t last_mv=-10;
  Test_Reset(0U); before=s_config_calls;
  assert(SENSOR_PH_RAW_SPAN_X100==3130804U);
  for(i=0U;i<sizeof(cases)/sizeof(cases[0]);++i)
  {
    soil_ph=SensorPh_Convert(cases[i].sum,cases[i].count);
    assert(soil_ph.valid && soil_ph.input_mv==cases[i].input_mv);
    assert(soil_ph.soil_ph_x100==cases[i].soil_ph_x100 && soil_ph.range==cases[i].range);
  }
  soil_ph=SensorPh_Convert(0U,0U);
  assert(!soil_ph.valid && soil_ph.range==SENSOR_PH_RANGE_UNAVAILABLE);
  assert(!SensorPh_Convert(65536U,1U).valid && !SensorPh_Convert(UINT64_MAX,UINT32_MAX).valid);
  for(raw=0U;raw<=UINT16_MAX;++raw)
  {
    soil_ph=SensorPh_Convert(raw,1U);
    assert(soil_ph.valid && soil_ph.input_mv>=last_mv && soil_ph.soil_ph_x100>=last_soil_ph_x100);
    assert(soil_ph.soil_ph_x100>=300U && soil_ph.soil_ph_x100<=900U);
    last_mv=soil_ph.input_mv; last_soil_ph_x100=soil_ph.soil_ph_x100;
  }
  assert(s_config_calls==before && !s_ad4_reads); /* Conversion never starts ADC. */
  assert(!strcmp(SensorPh_RangeName(SENSOR_PH_RANGE_LOW),"LOW"));
  assert(!strcmp(SensorPh_RangeName(SENSOR_PH_RANGE_OK),"OK"));
  assert(!strcmp(SensorPh_RangeName(SENSOR_PH_RANGE_HIGH),"HIGH"));
  assert(!strcmp(SensorPh_RangeName(SENSOR_PH_RANGE_UNAVAILABLE),"NA"));
}

static void Test_SoilPhPrintingAndFailure(void)
{
  unsigned tick;
  Test_Reset(0U);assert(!App_GetDiagnostics()->last_soil_ph.valid);
  s_ad4_poll_result=HAL_TIMEOUT;Test_At(1000U);assert(!App_GetDiagnostics()->last_round.soil_ph.valid);
  Test_At(3000U);assert(!App_GetDiagnostics()->last_soil_ph.valid && strstr(s_console,"土壤 pH：数据无效"));
  Test_Reset(0U);
  for(tick=0U;tick<3000U;tick+=100U) {s_ad4_raw=tick<600U?15717U:15716U;Test_At(tick);}
  Test_At(3000U);assert(App_GetDiagnostics()->last_soil_ph.valid && App_GetDiagnostics()->last_soil_ph.soil_ph_x100==600U);
  assert(strstr(s_console,"土壤 pH：6.00") && !strstr(s_console,"soil_ph="));
  s_ad4_stop_result=HAL_ERROR;Test_At(3100U);assert(!App_GetDiagnostics()->last_round.soil_ph.valid);
  assert(!strstr(s_transmitted,"input_mv") && strstr(s_transmitted,"\"soil_ph\""));
}
static void Test_SoilPhWindowMean(void)
{
  SensorPhWindow window;SensorPhWindowResult result;BspAdcResult sample;unsigned count,n;
  memset(&sample,0,sizeof(sample));sample.valid=1U;sample.raw=15716U;
  for(count=23U;count<=24U;++count) {
    SensorPh_WindowReset(&window);sample.valid=1U;sample.status=BSP_ADC_OK;sample.hal_status=BSP_ADC_HAL_OK;sample.stop_attempted=0U;sample.stop_status=BSP_ADC_HAL_OK;
    for(n=0U;n<count;++n) {SensorPh_WindowAdd(&window,&sample);}
    sample.valid=0U;sample.status=BSP_ADC_POLL_FAILED;sample.hal_status=BSP_ADC_HAL_TIMEOUT;
    sample.stop_attempted=1U;sample.stop_status=BSP_ADC_HAL_ERROR;
    for(n=count;n<30U;++n) {SensorPh_WindowAdd(&window,&sample);}
    result=SensorPh_WindowFinish(&window,30U,80U);
    assert(result.raw.sample_count==30U && result.raw.valid_count==count && result.raw.cleanup_errors==30U-count);
    assert(result.soil_ph.valid==(count==24U) && result.used_count==(count==24U?22U:0U));
  }
  memset(&sample,0,sizeof(sample));sample.valid=1U;SensorPh_WindowReset(&window);
  sample.raw=0U;SensorPh_WindowAdd(&window,&sample);SensorPh_WindowAdd(&window,&sample);
  sample.raw=1U;SensorPh_WindowAdd(&window,&sample);sample.raw=65535U;SensorPh_WindowAdd(&window,&sample);
  result=SensorPh_WindowFinish(&window,4U,80U);
  assert(result.used_count==2U && result.trimmed_sum==1U && result.soil_ph.valid && result.soil_ph.soil_ph_x100==300U);
  SensorPh_WindowReset(&window);result=SensorPh_WindowFinish(&window,30U,80U);assert(!result.soil_ph.valid);
}
#endif
