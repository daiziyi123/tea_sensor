# tea_sense 代码架构

更新：2026-11-14（北京时间）。STM32H743VIT6，MDK-ARM / ARMCC 5.06，标准 Arm C 库（MicroLIB 未启用）。

当前每100ms开始一个统一轮次，顺序读取AD0土壤、AD2风速、AD3风向、AD4土壤pH。USART2每1000ms直接printf原中文土壤/风向行及AD2、AD4单点行，每3000ms输出两路ADC_WINDOW；记录以CRLF结束。AD2采用实测raw×100零点6779、满量程3151863，端子电压40～5040mV对应用户指定的标称0～30m/s关系。三秒主要风速值从全部有效raw的sum/count换算，保留LOW/HIGH并限幅显示；AD4用实测0～5V端点6222/3137026（raw×100）分别恢复端子电压和标称pH 3～9，三秒主要值也使用全部有效raw的sum/count。四路共用窗口边界，仅土壤窗口上传。详见[AD4土壤pH换算与验证](soil_ph_validation.md)、[AD2实测映射与验证](wind_speed_calibration_validation.md)、[AD2/AD4原始接入](ad2_ad4_raw_validation.md)、[AD3电气换算](wind_direction_validation.md)。

USART6 / A6-B6 已改为上传真实土壤快照并解析服务器 JSON ACK，固定文本回显已移除。USART6 接收中断沿用当前 CubeMX 生成代码，本轮没有修改 Core 或 .ioc。见 [JSON 上传与验证](json_upload_validation.md)。

另接入百叶箱USART3/A3-B3与UART4/A4-B4，两路4800/8N1/地址01。原中文ADC行保持；百叶箱启动打印配置，每笔查询完成后增加一行WEATHER（原始帧、时间、当前值或NA及状态），只本地输出，不进入土壤JSON。查询周期10/30/60秒，单路单事务、间隔至少250ms、响应等待非阻塞、三次无合法响应后60秒探测，详见[百叶箱接入与验证](weather_rs485_validation.md)。用户已在CubeMX启用两路全局中断并重新生成；本轮接入代码没有手改生成区域。

## 分层

| 目录 | 模块 | 职责 |
| --- | --- | --- |
| App/Inc、App/Src | app_main、app_upload、app_config.h、core_json | 100ms统一采样调度、AD3/AD4原始统计、1秒单点/中文打印、3秒原始窗口打印/土壤上传、每循环接收/非阻塞ACK；coreJSON为MIT第三方解析器 |
| Sensors/Inc、Sensors/Src | sensor_soil、sensor_wind_speed、sensor_wind_direction、sensor_ph | 土壤相对湿润度与原窗口；AD2固定实测零偏补偿及全体raw均值换算，旧去极值字段仅保留诊断语义；AD3纯电压/角度换算；sensor_ph仅纯换算AD4端子电压和soil_ph，不启动ADC；均不依赖App |
| Bsp/Inc、Bsp/Src | bsp_adc、bsp_console、bsp_dtu、bsp_rs485_dir、bsp_time、bsp_config.h | ADC1一次初始化自校准、每读显式停止/配置通道/采样/清理及阶段诊断；串口、方向和时基沿用 |
| App/Inc、App/Src | app_weather | 固定六项查询调度、逐路事务/退避、完成时直接printf检测 |
| Sensors/Inc、Sensors/Src | sensor_weather | 03请求/CRC、流式响应与异常解析、厂家单位及独立有效缓存/新鲜度 |
| Bsp/Inc、Bsp/Src | bsp_weather_rs485 | 两路固定串口单字节IT接收、带毫秒时间的64槽环形缓冲、有限发送/本路恢复；不操作方向GPIO |

每层只有 Inc/Src。App 可调用 Sensors/Bsp，Sensors 只向下依赖 Bsp，Bsp 不依赖上层。HAL 句柄和直接硬件访问在 Bsp 与原有 CubeMX 生成代码内，Sensors 公开接口不暴露 HAL 类型；没有可写 extern 状态。

## 单一运行流程

```text
main：CubeMX 外设初始化 -> App_Init -> 主循环 App_Process
App_Init：BspConsole_Init -> BspDtu_Init（立即启动 RX）-> BspAdc_Init -> 记录 tick
  百叶箱AppWeather_Init在ADC自校准后、采样窗口起点前调用，启动两路接收并打印配置
App_Process：BspConsole_Process -> App_DtuProcess（每次先处理接收/ACK/10 秒超时）
  -> 先结算到期的[start,end)窗口，冻结结果并重置累计状态
  -> 100ms到期时分配round_id、统一round_t_ms，记录各路读取起止tick
  -> SensorSoil_Read -> BspAdc_ReadRaw(BSP_ADC_INPUT_SOIL_AD0)
  -> SensorWindSpeed_Read -> BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_SPEED_AD2)
  -> BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_DIRECTION_AD3)
  -> BspAdc_ReadRaw(BSP_ADC_INPUT_PH_AD4)
  -> AD4成功后SensorPh_Convert(raw,1)，保存soil_ph；窗口冻结时传全部raw_sum/valid_count
  -> AD3采集成功后SensorWindDirection_Convert(raw*100)，保存单点换算结果
  -> 四路结果按round_t_ms分别进入独立窗口，保存完整轮次
     pair_span_ms继续表示AD0+AD2；round_span_ms涵盖四路
  -> App_UploadWindow（仅已结算窗口、无待ACK、距上次尝试至少3000ms）
  -> AppWeather_Process（每循环处理两路接收/期限/调度，不等待响应）
  -> 每1000ms直接printf最近实际样本的土壤湿度和风向角度（中文）
     -> 同行追加之外，输出两条ADC_SAMPLE；窗口到期时输出两条ADC_WINDOW
     AD2追加电压/标称风速/范围，AD4追加端子电压/soil_ph/范围；DTU详情保留只读诊断
printf -> 标准 Arm C 库 -> _sys_write -> BspConsole_Send
  -> 有限超时 HAL_UART_Transmit + TC 检查 + 原有方向控制
```

输入映射固定为AD0/PB1/ADC1 Channel5、AD2/PA6/ADC1 Channel3、AD3/PA5/ADC1 Channel19、AD4/PA4/ADC1 Channel18；AD2不是ADC2外设或Channel2。现有.ioc及生成代码已配置PA6/PA5/PA4模拟输入、无上下拉，不改Core/Drivers/.ioc。bsp_adc每次先检查Stop，再按目标配置Rank1、单端、387.5周期/原offset参数，检查Config，Start/Poll/GetValue/Stop。初始化时只自校准一次；单路失败仍按共享ADC实际状态尝试下一输入，没有重试/延时/重新初始化。

sensor_soil.h端点仍为436/31146，土壤有理数换算不变。sensor_wind_speed.h集中定义AD2 raw×100零点6779、满量程3151863、跨度3145084，端子电压零点40mV、跨度5000mV。唯一纯入口SensorWindSpeed_ConvertMean(raw_sum,count)使用有符号64位中间量，保留除法余数后分别从raw直接计算整数端子毫伏和wind_speed_mps_x100；不先舍入均值或毫伏。范围按未舍入均值判断，显示风速限幅0.00～30.00。原未确认参数结构、开关和旧绝对电压映射已删除；固定电气映射启用，未增加运行模式。标称风速关系由用户指定，尚未用参考风速仪对照，不表示完成实际风速精度标定。

百分比使用 moisture_pct_x100（0～10000），App 用整数除余和 %02lu%% 输出两位小数及百分号，不启用浮点 printf。范围内按 30710 的跨度四舍五入；边界判断先于相减，使用 64 位乘法。低于 436 或高于 31146 时百分比显示限制在 0～100%，仍保留 raw，并在 status=OK 后附加 range=LOW/HIGH；恰好位于端点不算越界。该值表示空气干燥至完全浸水的相对湿润度，不等同于体积含水率。

原中文行继续只含土壤百分比和风向角度，另外沿用AD2/AD4的ADC_SAMPLE与ADC_WINDOW。AD2在原行末追加input_mv、wind_speed_mps、range，AD4在原行末追加input_mv、soil_ph、range；三秒风速使用冻结的全体有效raw_sum/valid_count，任何有效样本数都可换算，不使用去极值和80%门槛。有效raw=0输出29mV、0.00m/s、LOW；采集失败或无有效样本输出NA，保留错误/清理诊断。DTU/AD3摘要仍不打印，通信和采集详情保留只读诊断。没有额外采样、打印任务、上传字段或服务器协议修改。

printf只读最近完整轮次的换算结果，不额外采样或换算。sensor_wind_direction.c内集中定义raw×100端点640067/3100043，跨度2459976；纯接口接收raw_x100，以有符号64位中间量分别从raw直接计算mV和angle_deg_x100。电压外推保留有符号结果（raw=0约-41mV）；角度显示限幅0.00～360.00，LOW/OK/HIGH由未舍入raw关系判断，对应中文“偏低/无附注/偏高”。有效0是ADC成功且LOW，区别于采集失败；不叠加分压/VREF/方位偏移，不表示已完成安装朝向或真实风向精度校准。

三秒AD3原始统计仍冻结为AppAd3Window，保存全部有效raw的min/max/sum/valid_count，不打印摘要。它不使用土壤/风速的去极值和80%门槛，不新增网络字段。该均值仅用于固定角度电气核验，跨越1V/5V边界的普通均值不能当作动态平均风向；不从该窗口生成平均角度。错误分类、清理失败计数及最后错误保留在只读App_GetDiagnostics中。窗口归属依据round_t_ms，AD3读取跨边界也不拆开同一轮；迟到不补采。同步printf与有限超时采样可能造成调度迟到，按实际次数统计。

中文串口输出使用UTF-8，接收软件应选择UTF-8解码。App中的字符串用显式UTF-8字节转义，兼容当前GBK环境下的ARMCC5，不更改MDK编译选项。仍直接使用printf，没有打印包装层、输出开关或日志模块。本次Host 8组、ARMCC完整重编译（0错误0警告）和真实Arm printf模拟验证通过，日志见Docs/validation/chinese_console_*.log；未自动烧录。

BspConsole_Init 使用 setvbuf(stdout, NULL, _IONBF, 0) 关闭 stdout 缓冲，结果可从只读 BspConsole_GetDiagnostics 查看。保留 C 库自身 FILE，不定义小型替代 FILE，不新增输出缓冲或动态内存调用。重定向仅采用 rt_sys.h 的标准 Arm C 库接口；标准流名称及必要的系统钩子均在 bsp_console.c，链接启用 __use_no_semihosting_swi。未实现的文件/输入操作明确失败，不附加另一套 fputc 或 POSIX _write。

BspConsole 统计底层发送调用次数、错误次数及最后结果；次数按 C 库实际 write 调用统计，不等同于输出行数。App_GetDiagnostics 记录序号和 printf 失败次数；失败时 clearerr(stdout) 允许下一周期重试，不递归打印错误。不在中断内输出。RS485 AUTO/MANUAL 配置及手动校验保留，默认 AUTO 不驱动方向 GPIO，仅用于 USART2。

## 命名、配置与验证

命名规则保持：文件snake_case，公开函数模块前缀加动作，类型模块前缀加PascalCase，宏/枚举使用APP_/BSP_/SENSOR_SOIL_/SENSOR_WIND_SPEED_/SENSOR_WIND_DIRECTION_，私有状态s_，时间/电压带单位。HAL、MX、CMSIS、中断和C库钩子沿用规定名称。

app_config.h的APP_SAMPLE_ROUND_PERIOD_MS=100、APP_CONSOLE_PERIOD_MS=1000、APP_SAMPLE_WINDOW_MS=3000统一驱动四路；APP_WINDOW_EXPECTED_ROUNDS=30、APP_WINDOW_MIN_VALID_PERCENT=80由App传给两个Sensors窗口。土壤上传周期引用公共窗口。硬件仍为16位、异步8分频、单次/软件触发/单Rank、初始Channel5、387.5周期，UART/PE15/main不变。没有在线校准、自动校零、Flash保存或新运行模式。

每窗仅累计尝试数、有效数、64位raw总和、各一个最小/最大值和错误诊断。有效数达到ceil(期望数×80%)且至少3个时去掉各一个极值；adc_raw为舍入后的均值，百分比和LOW/HIGH使用未提前舍入的分数均值。单点和窗口共用同一私有有理数换算，不平均已限幅的百分比。无效窗为WINDOW_INSUFFICIENT、两个数据null、used_count=0。t_ms为窗口结束tick。公开JSON增加窗口计数及错误诊断，Bsp只处理硬件。

等待ACK时立即跳过本窗上传并计数，仍继续采样。发送间隔不足3000ms时仅保留当前冻结结果，达到间隔再发送；下一窗到来覆盖旧结果而不形成队列。跨越多个窗口的调度迟到不会连续补采或补发：统计跳过数，最新已结束的空窗报告不足；累计采样错误仍保留。ACK严格检查布尔true、设备号、待确认seq和有效id；不自动重发、不新增boot_id。

App/Inc/app_secrets.h 是本地私有配置，已列入 .gitignore。模板在 Docs/app_secrets.h.example；tools/configure_upload_secret.py 可仅读取指定服务器 .env 的 INGEST_TOKEN，生成经过 JSON/C 字符串双重转义的宏，不输出密钥。使用模板的未配置状态通过AppUpload_IsConfigured可见并禁用上传，不额外打印；缺少私有头文件会在编译时明确失败。USART2绝不打印完整上传JSON。coreJSON v3.3.1采用固定栈空间、不分配堆内存，许可证见coreJSON-LICENSE.txt。

常规验证：py -3 Tests/run_host_tests.py、py -3 Tests/check_arm_build.py、py -3 Tests/check_architecture.py。Tests/check_arm_printf.py用Unicorn执行真实Arm C库和生产业务代码，仅替换临时main并模拟HAL；不属于上板验证。详情见[本轮交付](wind_direction_validation.md)。

AD2电气映射按实测数据启用、风速按标称0～30m/s关系换算；AD3保持本地电压/角度换算，AD4保持原始采样统计并输出实测电气映射与标称pH换算。土壤JSON/ACK/密钥保持原样，服务器、数据库及前端未修改。没有新增安装方向修正、动态方向平均、雨量调度、菜单、持久化或在线标定。

AD4系数属于sensor_ph模块，不依赖其他通道参数或VREF。SensorPh_Convert(sum,count)以有符号64位分别计算input_mv和soil_ph_x100，保留除法余数后最后舍入，范围按未舍入raw判断，显示限幅3.00～9.00。有效raw=0为约-10mV、pH 3.00、LOW；采集失败或count=0为NA，不复用旧结果。App_Init后尚无有效采集时valid=0。ADC成功不代表已确认探头供电或线路正常。该关系为AD4电气端点校准及厂家0～5V版本的标称pH 3～9换算，未完成真实土壤pH精度对照，不使用说明书0～10V示例、温度补偿或电极模型。最新验证见soil_ph_validation.md。
