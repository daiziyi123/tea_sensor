#ifndef APP_MAIN_H
#define APP_MAIN_H

#include <stdint.h>
#include "sensor_soil.h"
#include "sensor_wind_speed.h"
#include "sensor_wind_direction.h"
#include "sensor_ph.h"
#include "bsp_dtu.h"

/* Raw observations for AD3/AD4: all valid values, no trimming. */
typedef struct
{
  uint32_t sample_count;
  uint32_t valid_count;
  uint64_t raw_sum;
  uint16_t raw_min;
  uint16_t raw_max;
  uint32_t error_counts[BSP_ADC_OUT_OF_RANGE + 1U];
  uint32_t cleanup_errors;
  uint32_t prepare_errors;
  uint32_t config_errors;
  BspAdcResult last_error;
} AppAdcRawWindow;

typedef AppAdcRawWindow AppAd3Window;

typedef struct
{
  uint32_t round_id;
  uint32_t round_t_ms;
  uint32_t soil_read_start_ms;
  uint32_t soil_read_end_ms;
  uint32_t wind_read_start_ms;
  uint32_t wind_read_end_ms;
  uint32_t pair_span_ms;
  uint32_t ad3_read_start_ms;
  uint32_t ad3_read_end_ms;
  uint32_t ad4_read_start_ms;
  uint32_t ad4_read_end_ms;
  uint32_t round_span_ms;
  SensorSoilData soil;
  SensorWindSpeedData wind;
  BspAdcResult ad3;
  BspAdcResult ad4;
  SensorPhValue soil_ph;
  SensorWindDirectionValue wind_direction;
} AppSampleRound;

typedef struct
{
  uint32_t sequence;
  uint32_t printf_errors;
  /* Communication diagnostics stay available without console chatter. */
  uint32_t dtu_ack_count;
  uint32_t dtu_ack_sequence;
  uint64_t dtu_ack_id;
  uint32_t dtu_last_sequence;
  uint32_t dtu_timeouts;
  uint32_t dtu_line_drops;
  uint32_t dtu_stream_gaps;
  uint32_t dtu_format_errors;
  BspDtuStatus dtu_init_status;
  uint32_t completed_windows;
  uint32_t upload_skipped_busy;
  uint32_t upload_skipped_late;
  uint32_t upload_skipped_rate;
  uint32_t sample_errors;
  uint32_t sample_error_counts[BSP_ADC_OUT_OF_RANGE + 1U];
  uint32_t cleanup_errors;
  uint32_t last_window_end_ms;
  BspAdcResult last_adc_error;
  SensorSoilWindowResult last_window;
  SensorWindSpeedWindowResult last_wind_window;
  SensorWindSpeedDiagnostics wind_diagnostics;
  uint32_t wind_sample_errors;
  uint32_t ad3_sample_errors;
  AppAd3Window last_ad3_window;
  uint32_t ad4_sample_errors;
  AppAdcRawWindow last_ad4_window;
  SensorPhValue last_soil_ph;
  AppSampleRound last_round;
} AppDiagnostics;

void App_Init(void);
void App_Process(void);
/* Read-only debugger view remains useful when the console cannot report. */
const AppDiagnostics *App_GetDiagnostics(void);

#endif
