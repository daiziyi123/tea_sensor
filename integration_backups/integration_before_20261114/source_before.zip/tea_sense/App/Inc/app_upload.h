#ifndef APP_UPLOAD_H
#define APP_UPLOAD_H
#include <stddef.h>
#include <stdint.h>
#include "sensor_soil.h"
#include "app_config.h"
/* Test include paths can supply fixture credentials; MDK uses local App/Inc. */
#include <app_secrets.h>

/* Exact escaped local token size plus bounded numeric/status/device fields. */
#define APP_UPLOAD_FRAME_CAPACITY (sizeof(APP_INGEST_TOKEN_JSON) + sizeof(APP_DEVICE_ID) + 512U)
#define APP_UPLOAD_ACK_CAPACITY 512U

typedef enum
{
  APP_UPLOAD_ACK_INVALID = 0,
  APP_UPLOAD_ACK_IGNORED,
  APP_UPLOAD_ACK_ACCEPTED
} AppUploadAckStatus;

typedef struct
{
  uint64_t id;
} AppUploadAck;

uint8_t AppUpload_IsConfigured(void);
int AppUpload_Format(char *buffer, size_t capacity, uint32_t sequence,
                     uint32_t window_end_tick_ms, uint32_t window_ms,
                     const SensorSoilWindowResult *window);
AppUploadAckStatus AppUpload_ParseAck(const char *line, size_t length,
                                     uint32_t expected_sequence, AppUploadAck *ack);
#endif
