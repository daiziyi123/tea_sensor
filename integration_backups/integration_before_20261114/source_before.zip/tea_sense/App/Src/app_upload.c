#include "app_upload.h"
#include "app_config.h"
#include "core_json.h"
#include <stdio.h>
#include <string.h>

uint8_t AppUpload_IsConfigured(void)
{
  return (APP_INGEST_TOKEN_CONFIGURED == 1 && sizeof(APP_INGEST_TOKEN_JSON) > 3U) ? 1U : 0U;
}

int AppUpload_Format(char *buffer, size_t capacity, uint32_t sequence,
                     uint32_t window_end_tick_ms, uint32_t window_ms,
                     const SensorSoilWindowResult *window)
{
  int length;
  int metadata_length;
  size_t offset;
  if (!buffer || !window || !capacity || !AppUpload_IsConfigured()) { return -1; }
  if (window->status == SENSOR_SOIL_WINDOW_OK)
  {
    const char *range = window->range == SENSOR_SOIL_RANGE_LOW ? ",\"range\":\"LOW\"" :
                        window->range == SENSOR_SOIL_RANGE_HIGH ? ",\"range\":\"HIGH\"" : "";
    length = snprintf(buffer, capacity,
      "{\"device_id\":\"%s\",\"seq\":%lu,\"t_ms\":%lu,\"channel\":\"AD0\","
      "\"adc_raw\":%lu,\"moisture_pct\":%lu.%02lu,\"status\":\"OK\"%s",
      APP_DEVICE_ID, (unsigned long)sequence, (unsigned long)window_end_tick_ms,
      (unsigned long)window->adc_raw, (unsigned long)(window->moisture_pct_x100 / 100U),
      (unsigned long)(window->moisture_pct_x100 % 100U), range);
  }
  else
  {
    length = snprintf(buffer, capacity,
      "{\"device_id\":\"%s\",\"seq\":%lu,\"t_ms\":%lu,\"channel\":\"AD0\","
      "\"adc_raw\":null,\"moisture_pct\":null,\"status\":\"WINDOW_INSUFFICIENT\"",
      APP_DEVICE_ID, (unsigned long)sequence, (unsigned long)window_end_tick_ms);
  }
  if (length < 0 || (size_t)length >= capacity) { return -1; }
  offset = (size_t)length;
  metadata_length = snprintf(buffer + offset, capacity - offset,
    ",\"window_ms\":%lu,\"sample_count\":%lu,\"valid_count\":%lu,\"used_count\":%lu,"
    "\"sample_error_count\":%lu,\"cleanup_error_count\":%lu,\"last_sample_error\":\"%s\",\"token\":%s}\r\n",
    (unsigned long)window_ms, (unsigned long)window->sample_count,
    (unsigned long)window->valid_count, (unsigned long)window->used_count,
    (unsigned long)(window->sample_count - window->valid_count),
    (unsigned long)window->diagnostics.cleanup_error_count,
    BspAdc_StatusName(window->diagnostics.last_error.status), APP_INGEST_TOKEN_JSON);
  if (metadata_length < 0 || (size_t)metadata_length >= capacity - offset) { return -1; }
  return length + metadata_length;
}

static int AppUpload_HexDigit(char character)
{
  if (character >= '0' && character <= '9') { return character - '0'; }
  if (character >= 'a' && character <= 'f') { return character - 'a' + 10; }
  if (character >= 'A' && character <= 'F') { return character - 'A' + 10; }
  return -1;
}

/* Match ASCII protocol identifiers, including equivalent JSON escapes. */
static uint8_t AppUpload_StringEquals(const char *text, size_t length, const char *expected)
{
  size_t index = 0U;
  while (index < length)
  {
    unsigned character = (unsigned char)text[index++];
    if (character == '\\')
    {
      if (index == length) { return 0U; }
      character = (unsigned char)text[index++];
      if (character == 'u')
      {
        unsigned digit;
        character = 0U;
        if (length - index < 4U) { return 0U; }
        for (digit = 0U; digit < 4U; ++digit)
        {
          int value = AppUpload_HexDigit(text[index++]);
          if (value < 0) { return 0U; }
          character = character * 16U + (unsigned)value;
        }
      }
      else if (character != '\\' && character != '"' && character != '/') { return 0U; }
    }
    if (*expected == '\0' || character != (unsigned char)*expected++) { return 0U; }
  }
  return *expected == '\0' ? 1U : 0U;
}

static uint8_t AppUpload_ParseUnsigned(const char *text, size_t length, uint64_t maximum, uint64_t *value)
{
  size_t index;
  uint64_t number = 0U;
  if (!length) { return 0U; }
  for (index = 0U; index < length; ++index)
  {
    unsigned digit = (unsigned char)text[index] - (unsigned)'0';
    if (digit > 9U || number > (maximum - digit) / 10U) { return 0U; }
    number = number * 10U + digit;
  }
  *value = number;
  return 1U;
}

AppUploadAckStatus AppUpload_ParseAck(const char *line, size_t length,
                                     uint32_t expected_sequence, AppUploadAck *ack)
{
  size_t start = 0U, next = 0U, leading = 0U;
  unsigned seen = 0U;
  uint8_t ok = 0U, device_matches = 0U;
  uint64_t sequence = 0U, id = 0U;
  JSONPair_t pair;
  JSONStatus_t result;
  if (!line || !ack || JSON_Validate(line, length) != JSONSuccess) { return APP_UPLOAD_ACK_INVALID; }
  while (leading < length && (line[leading] == ' ' || line[leading] == '\t' || line[leading] == '\r' || line[leading] == '\n')) { ++leading; }
  if (leading == length || line[leading] != '{') { return APP_UPLOAD_ACK_INVALID; }
  while ((result = JSON_Iterate(line, length, &start, &next, &pair)) == JSONSuccess)
  {
    unsigned bit = 0U;
    if (AppUpload_StringEquals(pair.key, pair.keyLength, "ok"))
    {
      bit = 1U;
      if (pair.jsonType != JSONTrue && pair.jsonType != JSONFalse) { return APP_UPLOAD_ACK_INVALID; }
      ok = pair.jsonType == JSONTrue ? 1U : 0U;
    }
    else if (AppUpload_StringEquals(pair.key, pair.keyLength, "device_id"))
    {
      bit = 2U;
      if (pair.jsonType != JSONString) { return APP_UPLOAD_ACK_INVALID; }
      device_matches = AppUpload_StringEquals(pair.value, pair.valueLength, APP_DEVICE_ID);
    }
    else if (AppUpload_StringEquals(pair.key, pair.keyLength, "seq"))
    {
      bit = 4U;
      if (pair.jsonType != JSONNumber || !AppUpload_ParseUnsigned(pair.value, pair.valueLength, UINT32_MAX, &sequence)) { return APP_UPLOAD_ACK_INVALID; }
    }
    else if (AppUpload_StringEquals(pair.key, pair.keyLength, "id"))
    {
      bit = 8U;
      if (pair.jsonType != JSONNumber || !AppUpload_ParseUnsigned(pair.value, pair.valueLength, INT64_MAX, &id) || !id) { return APP_UPLOAD_ACK_INVALID; }
    }
    if (bit && (seen & bit)) { return APP_UPLOAD_ACK_INVALID; }
    seen |= bit;
  }
  if (result != JSONNotFound) { return APP_UPLOAD_ACK_INVALID; }
  if (seen != 15U || !ok || !device_matches || sequence != expected_sequence) { return APP_UPLOAD_ACK_IGNORED; }
  ack->id = id;
  return APP_UPLOAD_ACK_ACCEPTED;
}
