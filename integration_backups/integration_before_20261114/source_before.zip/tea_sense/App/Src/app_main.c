#include "app_main.h"
#include "app_config.h"
#include "app_weather.h"
#include "sensor_soil.h"
#include "bsp_console.h"
#include "bsp_dtu.h"
#include "app_upload.h"
#include "bsp_time.h"
#include <stdio.h>
#include <string.h>

#define APP_DTU_LINE_SIZE APP_UPLOAD_ACK_CAPACITY

static uint32_t s_last_sample_tick_ms;
static uint32_t s_last_console_tick_ms;
static uint32_t s_window_start_tick_ms;
static uint8_t s_sampling_started;
static SensorSoilWindow s_soil_window;
static SensorWindSpeedWindow s_wind_window;
static AppAd3Window s_ad3_window;
static AppAdcRawWindow s_ad4_window;
static uint8_t s_window_ready;
static AppDiagnostics s_diagnostics;
static char s_dtu_tx_line[APP_UPLOAD_FRAME_CAPACITY];
static uint8_t s_dtu_rx_line[APP_DTU_LINE_SIZE];
static uint8_t s_dtu_rx_chunk[32];
static size_t s_dtu_rx_length;
static uint32_t s_dtu_sequence;
static uint32_t s_dtu_last_attempt_ms;
static uint8_t s_dtu_attempted;
static uint32_t s_dtu_sent_ms;
static uint8_t s_dtu_waiting;
static uint8_t s_dtu_discard_line;

static void App_RawWindowReset(AppAdcRawWindow *window)
{
  memset(window, 0, sizeof(*window));
  window->raw_min = UINT16_MAX;
}

static void App_RawWindowAdd(AppAdcRawWindow *window, const BspAdcResult *sample)
{
  ++window->sample_count;
  if (sample->valid && sample->status == BSP_ADC_OK)
  {
    ++window->valid_count;
    window->raw_sum += sample->raw;
    if (sample->raw < window->raw_min) { window->raw_min = sample->raw; }
    if (sample->raw > window->raw_max) { window->raw_max = sample->raw; }
    return;
  }
  if ((unsigned)sample->status <= BSP_ADC_OUT_OF_RANGE)
  { ++window->error_counts[sample->status]; }
  if (sample->stop_attempted && sample->stop_status != BSP_ADC_HAL_OK)
  { ++window->cleanup_errors; }
  if (sample->prepare_attempted && sample->prepare_status != BSP_ADC_HAL_OK)
  { ++window->prepare_errors; }
  if (sample->config_attempted && sample->config_status != BSP_ADC_HAL_OK)
  { ++window->config_errors; }
  window->last_error = *sample;
}

static void App_DtuConsumeByte(uint8_t byte, uint32_t now_ms)
{
  if (s_dtu_discard_line != 0U)
  {
    if (byte == '\n')
    {
      s_dtu_discard_line = 0U;
    }
    return;
  }
  if (s_dtu_rx_length == sizeof(s_dtu_rx_line))
  {
    s_dtu_rx_length = 0U;
    s_dtu_discard_line = (byte == '\n') ? 0U : 1U;
    ++s_diagnostics.dtu_line_drops;
    return;
  }
  s_dtu_rx_line[s_dtu_rx_length++] = byte;
  if (byte != '\n')
  {
    return;
  }
  if (s_dtu_waiting && (uint32_t)(now_ms - s_dtu_sent_ms) < APP_DTU_TIMEOUT_MS)
  {
    AppUploadAck ack;
    if (AppUpload_ParseAck((const char *)s_dtu_rx_line, s_dtu_rx_length, s_dtu_sequence, &ack) == APP_UPLOAD_ACK_ACCEPTED)
    {
      s_dtu_waiting = 0U;
      ++s_diagnostics.dtu_ack_count;
      s_diagnostics.dtu_ack_sequence = s_dtu_sequence;
      s_diagnostics.dtu_ack_id = ack.id;
    }
  }
  s_dtu_rx_length = 0U;
}

static void App_DtuRead(uint32_t now_ms)
{
  unsigned batch;
  /* Drain up to one ring per pass; continuous noise cannot starve the soil task. */
  for (batch = 0U; batch < 8U; ++batch)
  {
    size_t index;
    BspDtuReadResult received = BspDtu_Read(s_dtu_rx_chunk, sizeof(s_dtu_rx_chunk));
    if (received.data_lost != 0U)
    {
      if (s_dtu_discard_line == 0U)
      {
        ++s_diagnostics.dtu_stream_gaps;
      }
      s_dtu_discard_line = 1U;
      s_dtu_rx_length = 0U;
    }
    for (index = 0U; index < received.length; ++index)
    {
      App_DtuConsumeByte(s_dtu_rx_chunk[index], now_ms);
    }
    if (received.length == 0U)
    {
      break;
    }
  }
}

static void App_DtuProcess(uint32_t now_ms)
{
  App_DtuRead(now_ms);
  if (s_dtu_waiting && (uint32_t)(now_ms - s_dtu_sent_ms) >= APP_DTU_TIMEOUT_MS)
  {
    ++s_diagnostics.dtu_timeouts;
    s_dtu_waiting = 0U;
  }
}

static uint8_t App_CloseWindow(uint32_t now_ms)
{
  uint32_t elapsed = (uint32_t)(now_ms - s_window_start_tick_ms);
  uint32_t windows;
  if (elapsed < APP_SAMPLE_WINDOW_MS) { return 0U; }
  if (s_window_ready) { ++s_diagnostics.upload_skipped_rate; }
  windows = elapsed / APP_SAMPLE_WINDOW_MS;
  if (windows > 1U)
  {
    /* No backlog: old partial/empty windows are skipped, not replayed. The
     * latest completed window had no samples while this task was absent. */
    s_diagnostics.upload_skipped_late += windows - 1U;
    SensorSoil_WindowReset(&s_soil_window);
    SensorWindSpeed_WindowReset(&s_wind_window);
    App_RawWindowReset(&s_ad3_window);
    App_RawWindowReset(&s_ad4_window);
  }
  s_window_start_tick_ms += windows * APP_SAMPLE_WINDOW_MS;
  s_diagnostics.completed_windows += windows;
  s_diagnostics.last_window_end_ms = s_window_start_tick_ms;
  s_diagnostics.last_window = SensorSoil_WindowFinish(&s_soil_window,
    APP_WINDOW_EXPECTED_ROUNDS, APP_WINDOW_MIN_VALID_PERCENT);
  s_diagnostics.last_wind_window = SensorWindSpeed_WindowFinish(&s_wind_window,
    APP_WINDOW_EXPECTED_ROUNDS, APP_WINDOW_MIN_VALID_PERCENT);
  s_diagnostics.last_ad3_window = s_ad3_window;
  s_diagnostics.last_ad4_window = s_ad4_window;
  s_diagnostics.last_soil_ph = SensorPh_Convert(s_ad4_window.raw_sum, s_ad4_window.valid_count);
  SensorSoil_WindowReset(&s_soil_window);
  SensorWindSpeed_WindowReset(&s_wind_window);
  App_RawWindowReset(&s_ad3_window);
  App_RawWindowReset(&s_ad4_window);
  s_window_ready = 1U;
  return 1U;
}

static void App_UploadWindow(uint32_t now_ms)
{
  int length;
  BspDtuStatus status;
  if (!s_window_ready) { return; }
  if (s_dtu_waiting)
  {
    s_window_ready = 0U;
    ++s_diagnostics.upload_skipped_busy;
    return;
  }
  if (!AppUpload_IsConfigured()) { s_window_ready = 0U; return; }
  if (s_dtu_attempted && (uint32_t)(now_ms - s_dtu_last_attempt_ms) < APP_DTU_PERIOD_MS)
  {
    /* One frozen latest result may wait briefly for physical TX spacing.
     * It is overwritten, never queued, if another window closes first. */
    return;
  }
  s_window_ready = 0U;
  s_dtu_last_attempt_ms = now_ms;
  s_dtu_attempted = 1U;
  ++s_dtu_sequence;
  s_diagnostics.dtu_last_sequence = s_dtu_sequence;
  length = AppUpload_Format(s_dtu_tx_line, sizeof(s_dtu_tx_line), s_dtu_sequence,
                            s_diagnostics.last_window_end_ms, APP_SAMPLE_WINDOW_MS,
                            &s_diagnostics.last_window);
  if (length < 0)
  {
    ++s_diagnostics.dtu_format_errors;
    return;
  }
  status = BspDtu_Send(s_dtu_tx_line, (size_t)length);
  if (status == BSP_DTU_OK)
  {
    s_dtu_sent_ms = BspTime_GetTickMs();
    s_dtu_waiting = 1U;
  }
}

void App_Init(void)
{
  memset(&s_diagnostics, 0, sizeof(s_diagnostics));
  BspConsole_Init();
  s_diagnostics.dtu_init_status = BspDtu_Init();
  BspAdc_Init();
  AppWeather_Init();
  /* First real main-loop sample may occur at start; windows are [start,end). */
  s_window_start_tick_ms = BspTime_GetTickMs();
  s_last_sample_tick_ms = s_last_console_tick_ms = s_window_start_tick_ms;
  s_sampling_started = 0U;
  SensorSoil_WindowReset(&s_soil_window);
  SensorWindSpeed_WindowReset(&s_wind_window);
  App_RawWindowReset(&s_ad3_window);
  App_RawWindowReset(&s_ad4_window);
  s_window_ready = 0U;
  s_dtu_last_attempt_ms = s_window_start_tick_ms;
  s_dtu_attempted = 0U;
  s_dtu_sent_ms = 0U;
  s_dtu_sequence = 0U;
  s_dtu_rx_length = 0U;
  s_dtu_waiting = 0U;
  s_dtu_discard_line = 0U;
}

/* Keep the round snapshot frame off the receive/parser/printf call paths. */
static void App_AcquireRound(uint32_t now_ms)
{
  AppSampleRound round;
  memset(&round, 0, sizeof(round));
  s_sampling_started = 1U;
  s_last_sample_tick_ms = now_ms;
  round.round_id = ++s_diagnostics.sequence;
  round.round_t_ms = now_ms;
  round.soil_read_start_ms = BspTime_GetTickMs();
  round.soil = SensorSoil_Read();
  round.soil_read_end_ms = BspTime_GetTickMs();
  round.wind_read_start_ms = BspTime_GetTickMs();
  round.wind = SensorWindSpeed_Read();
  round.wind_read_end_ms = BspTime_GetTickMs();
  /* Preserve the existing AD0/AD2 pair duration. */
  round.pair_span_ms = (uint32_t)(BspTime_GetTickMs() - round.round_t_ms);
  round.ad3_read_start_ms = BspTime_GetTickMs();
  round.ad3 = BspAdc_ReadRaw(BSP_ADC_INPUT_WIND_DIRECTION_AD3);
  round.ad3_read_end_ms = BspTime_GetTickMs();
  round.ad4_read_start_ms = BspTime_GetTickMs();
  round.ad4 = BspAdc_ReadRaw(BSP_ADC_INPUT_PH_AD4);
  round.ad4_read_end_ms = BspTime_GetTickMs();
  if (round.ad4.valid && round.ad4.status == BSP_ADC_OK)
  {
    round.soil_ph = SensorPh_Convert(round.ad4.raw, 1U);
  }
  if (round.ad3.valid && round.ad3.status == BSP_ADC_OK)
  {
    round.wind_direction = SensorWindDirection_Convert((uint32_t)round.ad3.raw * 100U);
  }
  /* All four belong to round_t_ms, even if a later read crosses a boundary. */
  SensorSoil_WindowAdd(&s_soil_window, &round.soil.adc);
  SensorWindSpeed_WindowAdd(&s_wind_window, &round.wind.adc);
  App_RawWindowAdd(&s_ad3_window, &round.ad3);
  App_RawWindowAdd(&s_ad4_window, &round.ad4);
  if (!round.ad3.valid) { ++s_diagnostics.ad3_sample_errors; }
  if (!round.ad4.valid) { ++s_diagnostics.ad4_sample_errors; }
  round.round_span_ms = (uint32_t)(BspTime_GetTickMs() - round.round_t_ms);
  s_diagnostics.last_round = round;
  if (!round.soil.adc.valid)
  {
    ++s_diagnostics.sample_errors;
    if ((unsigned)round.soil.adc.status <= BSP_ADC_OUT_OF_RANGE)
    {
      ++s_diagnostics.sample_error_counts[round.soil.adc.status];
    }
    s_diagnostics.last_adc_error = round.soil.adc;
    if (round.soil.adc.stop_attempted && round.soil.adc.stop_status != BSP_ADC_HAL_OK)
    {
      ++s_diagnostics.cleanup_errors;
    }
  }
  if (!round.wind.adc.valid)
  {
    const BspAdcResult *error = &round.wind.adc;
    SensorWindSpeedDiagnostics *diagnostics = &s_diagnostics.wind_diagnostics;
    ++s_diagnostics.wind_sample_errors;
    if ((unsigned)error->status <= BSP_ADC_OUT_OF_RANGE) { ++diagnostics->error_counts[error->status]; }
    if (error->stop_attempted && error->stop_status != BSP_ADC_HAL_OK) { ++diagnostics->cleanup_error_count; }
    if (error->prepare_attempted && error->prepare_status != BSP_ADC_HAL_OK) { ++diagnostics->prepare_error_count; }
    if (error->config_attempted && error->config_status != BSP_ADC_HAL_OK) { ++diagnostics->config_error_count; }
    diagnostics->last_error = *error;
  }
}

void App_Process(void)
{
  uint32_t now_ms;
  uint8_t window_closed;
  unsigned input;
  int print_failed = 0;
  BspConsole_Process();
  now_ms = BspTime_GetTickMs();
  App_DtuProcess(now_ms);
  now_ms = BspTime_GetTickMs();
  /* Close before acquiring so boundary rounds enter the next window. */
  window_closed = App_CloseWindow(now_ms);
  if (!s_sampling_started || (uint32_t)(now_ms - s_last_sample_tick_ms) >= APP_SAMPLE_ROUND_PERIOD_MS)
  {
    App_AcquireRound(now_ms);
  }
  App_UploadWindow(BspTime_GetTickMs());
  AppWeather_Process();
  if (window_closed)
  {
    for (input = 0U; input < 2U; ++input)
    {
      const SensorWindSpeedWindowResult *wind = &s_diagnostics.last_wind_window;
      const AppAdcRawWindow *ad4 = &s_diagnostics.last_ad4_window;
      uint32_t samples = input ? ad4->sample_count : wind->sample_count;
      uint32_t valid = input ? ad4->valid_count : wind->valid_count;
      uint32_t errors = samples - valid;
      uint64_t sum = input ? ad4->raw_sum : wind->raw_sum;
      const BspAdcResult *error = input ? &ad4->last_error : &wind->diagnostics.last_error;
      print_failed |= printf("ADC_WINDOW,channel=%s,window_end_ms=%lu,sample_count=%lu,valid_count=%lu,",
        input ? "AD4" : "AD2", (unsigned long)s_diagnostics.last_window_end_ms,
        (unsigned long)samples, (unsigned long)valid) < 0;
      if (valid)
      {
        /* Ordinary mean of ALL valid samples, rounded once to two decimals.
         * uint64 covers 65535 * UINT32_MAX * 100 plus rounding. */
        uint32_t mean_x100 = (uint32_t)((sum * 100U + valid / 2U) / valid);
        print_failed |= printf("adc_raw_min=%u,adc_raw_max=%u,adc_raw_mean=%lu.%02lu,",
          (unsigned)(input ? ad4->raw_min : wind->raw_min),
          (unsigned)(input ? ad4->raw_max : wind->raw_max),
          (unsigned long)(mean_x100 / 100U), (unsigned long)(mean_x100 % 100U)) < 0;
      }
      else { print_failed |= printf("adc_raw_min=NA,adc_raw_max=NA,adc_raw_mean=NA,") < 0; }
      print_failed |= printf("error_count=%lu,status=%s,cleanup_error_count=%lu,prepare_error_count=%lu,config_error_count=%lu,",
        (unsigned long)errors, !samples ? "NO_SAMPLES" : !valid ? "NO_VALID_SAMPLES" : errors ? "PARTIAL" : "OK",
        (unsigned long)(input ? ad4->cleanup_errors : wind->diagnostics.cleanup_error_count),
        (unsigned long)(input ? ad4->prepare_errors : wind->diagnostics.prepare_error_count),
        (unsigned long)(input ? ad4->config_errors : wind->diagnostics.config_error_count)) < 0;
      print_failed |= printf("last_error=%s,last_stage=%s,last_hal_status=%s,last_prepare_status=%s,last_config_status=%s,last_stop_status=%s",
        errors ? BspAdc_StatusName(error->status) : "NONE",
        errors ? BspAdc_StageName(error->stage) : "NONE",
        errors ? BspAdc_HalStatusName(error->hal_status) : "NA",
        errors && error->prepare_attempted ? BspAdc_HalStatusName(error->prepare_status) : "NA",
        errors && error->config_attempted ? BspAdc_HalStatusName(error->config_status) : "NA",
        errors && error->stop_attempted ? BspAdc_HalStatusName(error->stop_status) : "NA") < 0;
      if (!input)
      {
        if (wind->value.valid)
        {
          print_failed |= printf(",input_mv=%ld,wind_speed_mps=%lu.%02lu,range=%s",
            (long)wind->value.input_mv,
            (unsigned long)(wind->value.wind_speed_mps_x100 / 100U),
            (unsigned long)(wind->value.wind_speed_mps_x100 % 100U),
            SensorWindSpeed_RangeName(wind->value.range)) < 0;
        }
        else { print_failed |= printf(",input_mv=NA,wind_speed_mps=NA,range=NA") < 0; }
      }
      else
      {
        const SensorPhValue *soil_ph = &s_diagnostics.last_soil_ph;
        if (soil_ph->valid)
        {
          print_failed |= printf(",input_mv=%ld,soil_ph=%lu.%02lu,range=%s",
            (long)soil_ph->input_mv,
            (unsigned long)(soil_ph->soil_ph_x100 / 100U),
            (unsigned long)(soil_ph->soil_ph_x100 % 100U),
            SensorPh_RangeName(soil_ph->range)) < 0;
        }
        else { print_failed |= printf(",input_mv=NA,soil_ph=NA,range=NA") < 0; }
      }
      print_failed |= printf("\r\n") < 0;
    }
  }
  if ((uint32_t)(now_ms - s_last_console_tick_ms) >= APP_CONSOLE_PERIOD_MS)
  {
    const AppSampleRound *round = &s_diagnostics.last_round;
    s_last_console_tick_ms = now_ms;
    /* Explicit UTF-8 bytes also compile with ARMCC5 on a GBK host.
     * Integer fixed point, no extra acquisition. */
    if (round->soil.adc.valid)
    {
      print_failed |= printf("\xE5\x9C\x9F\xE5\xA3\xA4\xE6\xB9\xBF\xE5\xBA\xA6\xEF\xBC\x9A%lu.%02lu%%%s\xEF\xBC\x8C",
        (unsigned long)(round->soil.moisture_pct_x100 / 100U),
        (unsigned long)(round->soil.moisture_pct_x100 % 100U),
        round->soil.range == SENSOR_SOIL_RANGE_LOW ? "\xEF\xBC\x88\xE5\x81\x8F\xE4\xBD\x8E\xEF\xBC\x89" :
        round->soil.range == SENSOR_SOIL_RANGE_HIGH ? "\xEF\xBC\x88\xE5\x81\x8F\xE9\xAB\x98\xEF\xBC\x89" : "") < 0;
    }
    else { print_failed |= printf("\xE5\x9C\x9F\xE5\xA3\xA4\xE6\xB9\xBF\xE5\xBA\xA6\xEF\xBC\x9A\xE6\x97\xA0\xE6\x95\x88\xEF\xBC\x8C") < 0; }
    if (round->ad3.valid && round->wind_direction.valid)
    {
      print_failed |= printf("\xE9\xA3\x8E\xE5\x90\x91\xE8\xA7\x92\xE5\xBA\xA6\xEF\xBC\x9A%lu.%02lu\xE5\xBA\xA6%s\r\n",
        (unsigned long)(round->wind_direction.angle_deg_x100 / 100U),
        (unsigned long)(round->wind_direction.angle_deg_x100 % 100U),
        round->wind_direction.range == SENSOR_WIND_DIRECTION_RANGE_LOW ? "\xEF\xBC\x88\xE5\x81\x8F\xE4\xBD\x8E\xEF\xBC\x89" :
        round->wind_direction.range == SENSOR_WIND_DIRECTION_RANGE_HIGH ? "\xEF\xBC\x88\xE5\x81\x8F\xE9\xAB\x98\xEF\xBC\x89" : "") < 0;
    }
    else { print_failed |= printf("\xE9\xA3\x8E\xE5\x90\x91\xE8\xA7\x92\xE5\xBA\xA6\xEF\xBC\x9A\xE6\x97\xA0\xE6\x95\x88\r\n") < 0; }
    for (input = 0U; input < 2U; ++input)
    {
      const BspAdcResult *sample = input ? &round->ad4 : &round->wind.adc;
      print_failed |= printf("ADC_SAMPLE,round_id=%lu,sample_t_ms=%lu,channel=%s,pin=%s,adc_channel=%u,adc_raw=",
        (unsigned long)round->round_id,
        (unsigned long)(input ? round->ad4_read_start_ms : round->wind_read_start_ms),
        input ? "AD4" : "AD2", input ? "PA4" : "PA6", input ? 18U : 3U) < 0;
      if (sample->valid && sample->status == BSP_ADC_OK)
      { print_failed |= printf("%u,status=OK", (unsigned)sample->raw) < 0; }
      else
      {
        print_failed |= printf("NA,status=%s,stage=%s,hal_status=%s,prepare_status=%s,config_status=%s,stop_status=%s",
          BspAdc_StatusName(sample->status), BspAdc_StageName(sample->stage),
          BspAdc_HalStatusName(sample->hal_status),
          sample->prepare_attempted ? BspAdc_HalStatusName(sample->prepare_status) : "NA",
          sample->config_attempted ? BspAdc_HalStatusName(sample->config_status) : "NA",
          sample->stop_attempted ? BspAdc_HalStatusName(sample->stop_status) : "NA") < 0;
      }
      if (!input)
      {
        if (round->wind.value.valid)
        {
          print_failed |= printf(",input_mv=%ld,wind_speed_mps=%lu.%02lu,range=%s",
            (long)round->wind.value.input_mv,
            (unsigned long)(round->wind.value.wind_speed_mps_x100 / 100U),
            (unsigned long)(round->wind.value.wind_speed_mps_x100 % 100U),
            SensorWindSpeed_RangeName(round->wind.value.range)) < 0;
        }
        else { print_failed |= printf(",input_mv=NA,wind_speed_mps=NA,range=NA") < 0; }
      }
      else
      {
        const SensorPhValue *soil_ph = &round->soil_ph;
        if (soil_ph->valid)
        {
          print_failed |= printf(",input_mv=%ld,soil_ph=%lu.%02lu,range=%s",
            (long)soil_ph->input_mv,
            (unsigned long)(soil_ph->soil_ph_x100 / 100U),
            (unsigned long)(soil_ph->soil_ph_x100 % 100U),
            SensorPh_RangeName(soil_ph->range)) < 0;
        }
        else { print_failed |= printf(",input_mv=NA,soil_ph=NA,range=NA") < 0; }
      }
      print_failed |= printf("\r\n") < 0;
    }
  }
  if (print_failed) { ++s_diagnostics.printf_errors; clearerr(stdout); }
}

const AppDiagnostics *App_GetDiagnostics(void)
{
  return &s_diagnostics;
}
