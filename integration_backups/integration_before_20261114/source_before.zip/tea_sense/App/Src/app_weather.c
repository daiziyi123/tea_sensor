#include "app_weather.h"
#include "app_config.h"
#include "bsp_config.h"
#include "bsp_time.h"
#include <stdio.h>
#include <string.h>

typedef struct {
  AppWeatherPortDiagnostics diagnostics;
  SensorWeatherParser parser;
  uint32_t tx_end_ms, rx_start_ms, rx_end_ms, rx_count, probe_last_ms;
  uint8_t rx_trace[32], trace_length, trace_truncated, ended_once;
  SensorWeatherItem cursor;
} AppWeatherPort;
static AppWeatherPort s_ports[BSP_WEATHER_RS485_PORT_COUNT];
static uint8_t s_attempted[SENSOR_WEATHER_ITEM_COUNT];
static uint32_t s_sequence;

uint32_t AppWeather_PeriodMs(SensorWeatherItem item)
{
  switch(item) {
    case SENSOR_WEATHER_TEMP_HUM:return APP_WEATHER_TEMP_HUM_PERIOD_MS;
    case SENSOR_WEATHER_LIGHT:return APP_WEATHER_LIGHT_PERIOD_MS;
    case SENSOR_WEATHER_PM:return APP_WEATHER_PM_PERIOD_MS;
    case SENSOR_WEATHER_PRESSURE:return APP_WEATHER_PRESSURE_PERIOD_MS;
    case SENSOR_WEATHER_CO2:return APP_WEATHER_CO2_PERIOD_MS;
    default:return APP_WEATHER_OXYGEN_PERIOD_MS;
  }
}
static SensorWeatherStatus AppWeather_UartStatus(BspWeatherRs485Status status)
{
  switch(status) {
    case BSP_WEATHER_RS485_UART_BUSY:return SENSOR_WEATHER_UART_BUSY;
    case BSP_WEATHER_RS485_UART_TIMEOUT:return SENSOR_WEATHER_UART_TIMEOUT;
    case BSP_WEATHER_RS485_RX_NOT_READY:return SENSOR_WEATHER_RX_NOT_READY;
    case BSP_WEATHER_RS485_IRQ_DISABLED:return SENSOR_WEATHER_IRQ_DISABLED;
    default:return SENSOR_WEATHER_UART_ERROR;
  }
}
/* Complete/cache/report exactly once. This is transaction handling, not a
 * logging wrapper; old cache values are never substituted into failed fields. */
static void AppWeather_Finish(BspWeatherRs485Port port, SensorWeatherStatus status, uint32_t now_ms)
{
  AppWeatherPort *state=&s_ports[port];
  AppWeatherPortDiagnostics *diagnostics=&state->diagnostics;
  SensorWeatherReply *reply=&state->parser.reply;
  const SensorWeatherValue *value=&reply->value;
  SensorWeatherFreshness freshness;
  unsigned index;
  int failed=0;
  uint8_t legal=(status==SENSOR_WEATHER_OK || status==SENSOR_WEATHER_MODBUS_EXCEPTION);
  reply->status=status;
  SensorWeather_Complete(diagnostics->item,reply,state->rx_end_ms);
  diagnostics->waiting=0U; diagnostics->last_status=status; diagnostics->last_complete_ms=now_ms;
  ++diagnostics->completions; diagnostics->echo_count+=state->parser.echo_count; state->ended_once=1U;
  if(legal) { diagnostics->no_response_streak=0U; diagnostics->backoff=0U; }
  else {
    if(diagnostics->no_response_streak<APP_WEATHER_NO_RESPONSE_LIMIT) { ++diagnostics->no_response_streak; }
    if(diagnostics->no_response_streak>=APP_WEATHER_NO_RESPONSE_LIMIT && !diagnostics->backoff) {
      diagnostics->backoff=1U; ++diagnostics->backoff_count; state->probe_last_ms=now_ms;
    }
  }
  freshness=SensorWeather_GetFreshness(diagnostics->item,now_ms,AppWeather_PeriodMs(diagnostics->item));
  failed|=printf("WEATHER,seq=%lu,port=%s,item=%s,tx_t_ms=%lu,tx_end_ms=%lu,",
    (unsigned long)diagnostics->query_sequence,port==BSP_WEATHER_RS485_MET?"USART3":"UART4",
    SensorWeather_ItemName(diagnostics->item),(unsigned long)diagnostics->last_start_ms,(unsigned long)state->tx_end_ms)<0;
  if(state->rx_count) { failed|=printf("rx_start_ms=%lu,rx_end_ms=%lu,",(unsigned long)state->rx_start_ms,(unsigned long)state->rx_end_ms)<0; }
  else { failed|=printf("rx_start_ms=NA,rx_end_ms=NA,")<0; }
  failed|=printf("TX=")<0;
  for(index=0U;index<8U;++index) { failed|=printf("%02X",(unsigned)state->parser.request[index])<0; }
  failed|=printf(",RX=")<0;
  if(!state->trace_length) { failed|=printf("NA")<0; }
  for(index=0U;index<state->trace_length;++index) { failed|=printf("%02X",(unsigned)state->rx_trace[index])<0; }
  failed|=printf(",rx_count=%lu,rx_truncated=%u,",(unsigned long)state->rx_count,(unsigned)state->trace_truncated)<0;
  if(status==SENSOR_WEATHER_OK) { failed|=printf("sample_t_ms=%lu,",(unsigned long)state->rx_end_ms)<0; }
  else { failed|=printf("sample_t_ms=NA,")<0; }
  switch(diagnostics->item) {
    case SENSOR_WEATHER_TEMP_HUM:
      if(status==SENSOR_WEATHER_OK) {
        int32_t temperature=value->temperature_c_x10;
        uint32_t magnitude=(uint32_t)(temperature<0?-temperature:temperature);
        failed|=printf("temperature_c=%s%lu.%lu,humidity_rh_pct=%lu.%lu,",temperature<0?"-":"",
          (unsigned long)(magnitude/10U),(unsigned long)(magnitude%10U),
          (unsigned long)(value->humidity_rh_pct_x10/10U),(unsigned long)(value->humidity_rh_pct_x10%10U))<0;
      } else { failed|=printf("temperature_c=NA,humidity_rh_pct=NA,")<0; }
      break;
    case SENSOR_WEATHER_LIGHT:
      if(status==SENSOR_WEATHER_OK) { failed|=printf("light_lux=%lu,",(unsigned long)value->light_lux)<0; }
      else { failed|=printf("light_lux=NA,")<0; } break;
    case SENSOR_WEATHER_PM:
      if(status==SENSOR_WEATHER_OK) { failed|=printf("pm25_ug_m3=%lu,pm10_ug_m3=%lu,",(unsigned long)value->pm25_ug_m3,(unsigned long)value->pm10_ug_m3)<0; }
      else { failed|=printf("pm25_ug_m3=NA,pm10_ug_m3=NA,")<0; } break;
    case SENSOR_WEATHER_PRESSURE:
      if(status==SENSOR_WEATHER_OK) { failed|=printf("pressure_kpa=%lu.%02lu,",(unsigned long)(value->pressure_kpa_x100/100U),(unsigned long)(value->pressure_kpa_x100%100U))<0; }
      else { failed|=printf("pressure_kpa=NA,")<0; } break;
    case SENSOR_WEATHER_CO2:
      if(status==SENSOR_WEATHER_OK) { failed|=printf("co2_ppm=%lu,",(unsigned long)value->co2_ppm)<0; }
      else { failed|=printf("co2_ppm=NA,")<0; } break;
    case SENSOR_WEATHER_OXYGEN:
      if(status==SENSOR_WEATHER_OK) { failed|=printf("oxygen_pct=%lu.%lu,",(unsigned long)(value->oxygen_pct_x10/10U),(unsigned long)(value->oxygen_pct_x10%10U))<0; }
      else { failed|=printf("oxygen_pct=NA,")<0; } break;
    default:break;
  }
  failed|=printf("status=%s,exception_code=0x%02X,uart_error=0x%08lX,cache=%s,backoff=%u\r\n",
    SensorWeather_StatusName(status),(unsigned)reply->exception_code,(unsigned long)diagnostics->uart_error,
    freshness==SENSOR_WEATHER_FRESHNESS_NO_DATA?"NO_DATA":freshness==SENSOR_WEATHER_STALE?"STALE":"FRESH",(unsigned)diagnostics->backoff)<0;
  if(failed) { clearerr(stdout); }
}
static uint8_t AppWeather_LineReady(BspWeatherRs485Port port, uint32_t now_ms)
{
  BspWeatherRs485Diagnostics diagnostics=BspWeatherRs485_GetDiagnostics(port);
  return diagnostics.rx_active && (!diagnostics.rx_seen || (uint32_t)(now_ms-diagnostics.last_rx_ms)>=BSP_WEATHER_RX_QUIET_MS);
}
static uint8_t AppWeather_GapReady(BspWeatherRs485Port port, uint32_t now_ms)
{ return !s_ports[port].ended_once || (uint32_t)(now_ms-s_ports[port].diagnostics.last_complete_ms)>=BSP_WEATHER_TRANSACTION_GAP_MS; }
static void AppWeather_Start(SensorWeatherItem item, uint32_t now_ms)
{
  BspWeatherRs485Port port=SensorWeather_Port(item);
  AppWeatherPort *state=&s_ports[port];
  BspWeatherRs485Status status;
  SensorWeather_ParserInit(&state->parser,item);
  state->trace_length=state->trace_truncated=0U; state->rx_count=0U; state->rx_start_ms=state->rx_end_ms=0U;
  state->diagnostics.item=item; state->diagnostics.query_sequence=++s_sequence;
  state->diagnostics.last_start_ms=now_ms; state->diagnostics.uart_error=0U;
  state->diagnostics.waiting=1U; ++state->diagnostics.queries; s_attempted[item]=1U;
  if(state->diagnostics.backoff) { ++state->diagnostics.probe_count; state->probe_last_ms=now_ms; }
  SensorWeather_RecordQuery(item,s_sequence,now_ms);
  state->cursor=(SensorWeatherItem)(item+1);
  if(port==BSP_WEATHER_RS485_MET && state->cursor>SENSOR_WEATHER_PRESSURE) { state->cursor=SENSOR_WEATHER_TEMP_HUM; }
  if(port==BSP_WEATHER_RS485_GAS && state->cursor>SENSOR_WEATHER_OXYGEN) { state->cursor=SENSOR_WEATHER_CO2; }
  status=BspWeatherRs485_Send(port,state->parser.request,8U); state->tx_end_ms=BspTime_GetTickMs();
  if(status!=BSP_WEATHER_RS485_OK) { AppWeather_Finish(port,AppWeather_UartStatus(status),state->tx_end_ms); }
}
static void AppWeather_Receive(BspWeatherRs485Port port)
{
  AppWeatherPort *state=&s_ports[port]; unsigned batch;
  BspWeatherRs485_Process(port);
  for(batch=0U;batch<4U;++batch) {
    BspWeatherRs485Byte bytes[16]; size_t index;
    BspWeatherRs485ReadResult received=BspWeatherRs485_Read(port,bytes,16U);
    if(received.data_lost && state->diagnostics.waiting) {
      state->diagnostics.uart_error=received.uart_error;
      AppWeather_Finish(port,received.lost_status!=BSP_WEATHER_RS485_OK?AppWeather_UartStatus(received.lost_status):SENSOR_WEATHER_RX_OVERFLOW,BspTime_GetTickMs());
    }
    for(index=0U;index<received.length;++index) {
      if(!state->diagnostics.waiting || (uint32_t)(bytes[index].t_ms-state->diagnostics.last_start_ms)>=
          (uint32_t)(state->tx_end_ms-state->diagnostics.last_start_ms)+BSP_WEATHER_RESPONSE_TIMEOUT_MS) {
        ++state->diagnostics.ignored_idle_bytes; continue;
      }
      if(!state->rx_count) { state->rx_start_ms=bytes[index].t_ms; }
      state->rx_end_ms=bytes[index].t_ms; ++state->rx_count;
      if(state->trace_length<sizeof(state->rx_trace)) { state->rx_trace[state->trace_length++]=bytes[index].byte; }
      else { state->trace_truncated=1U; }
      if(SensorWeather_ParseByte(&state->parser,bytes[index].byte,bytes[index].t_ms,BSP_WEATHER_RX_QUIET_MS)) {
        AppWeather_Finish(port,state->parser.reply.status,BspTime_GetTickMs());
      }
    }
    if(received.length<16U) { break; }
  }
  if(state->diagnostics.waiting && (uint32_t)(BspTime_GetTickMs()-state->tx_end_ms)>=BSP_WEATHER_RESPONSE_TIMEOUT_MS) {
    AppWeather_Finish(port,SensorWeather_ParserError(&state->parser),BspTime_GetTickMs());
  }
}
void AppWeather_Init(void)
{
  unsigned port;
  memset(s_ports,0,sizeof(s_ports)); memset(s_attempted,0,sizeof(s_attempted)); s_sequence=0U; SensorWeather_Init();
  s_ports[BSP_WEATHER_RS485_MET].cursor=SENSOR_WEATHER_TEMP_HUM;
  s_ports[BSP_WEATHER_RS485_GAS].cursor=SENSOR_WEATHER_CO2;
  for(port=0U;port<BSP_WEATHER_RS485_PORT_COUNT;++port) {
    s_ports[port].diagnostics.init_status=BspWeatherRs485_Init((BspWeatherRs485Port)port);
    printf("WEATHER_CONFIG,port=%s,baud=4800,bits=8N1,address=01,tx_timeout_ms=%lu,response_timeout_ms=%lu,gap_ms=%lu,rx_status=%s\r\n",
      port==BSP_WEATHER_RS485_MET?"USART3":"UART4",(unsigned long)BSP_WEATHER_TX_TIMEOUT_MS,
      (unsigned long)BSP_WEATHER_RESPONSE_TIMEOUT_MS,(unsigned long)BSP_WEATHER_TRANSACTION_GAP_MS,
      BspWeatherRs485_StatusName(s_ports[port].diagnostics.init_status));
  }
  printf("WEATHER_PERIODS,TEMP_HUM=%lu,LIGHT=%lu,PM=%lu,PRESSURE=%lu,CO2=%lu,OXYGEN=%lu,unit=ms,no_response_limit=%lu,probe_ms=%lu\r\n",
    (unsigned long)APP_WEATHER_TEMP_HUM_PERIOD_MS,(unsigned long)APP_WEATHER_LIGHT_PERIOD_MS,(unsigned long)APP_WEATHER_PM_PERIOD_MS,
    (unsigned long)APP_WEATHER_PRESSURE_PERIOD_MS,(unsigned long)APP_WEATHER_CO2_PERIOD_MS,(unsigned long)APP_WEATHER_OXYGEN_PERIOD_MS,
    (unsigned long)APP_WEATHER_NO_RESPONSE_LIMIT,(unsigned long)APP_WEATHER_PROBE_PERIOD_MS);
}
void AppWeather_Process(void)
{
  unsigned port,index; uint32_t now_ms;
  for(port=0U;port<BSP_WEATHER_RS485_PORT_COUNT;++port) { AppWeather_Receive((BspWeatherRs485Port)port); }
  now_ms=BspTime_GetTickMs();
  /* Healthy startup has exactly the listed six-query order. A disabled/noisy
   * or backed-off route cannot prevent the other route from starting. */
  for(index=0U;index<SENSOR_WEATHER_ITEM_COUNT;++index) {
    BspWeatherRs485Port route=SensorWeather_Port((SensorWeatherItem)index);
    if(s_attempted[index] || s_ports[route].diagnostics.backoff) { continue; }
    if(s_ports[0].diagnostics.waiting || s_ports[1].diagnostics.waiting || !AppWeather_GapReady(route,now_ms)) { return; }
    if(!AppWeather_LineReady(route,now_ms)) { continue; }
    AppWeather_Start((SensorWeatherItem)index,now_ms); return;
  }
  for(port=0U;port<BSP_WEATHER_RS485_PORT_COUNT;++port) {
    AppWeatherPort *state=&s_ports[port];
    if(state->diagnostics.waiting || !AppWeather_GapReady((BspWeatherRs485Port)port,now_ms) || !AppWeather_LineReady((BspWeatherRs485Port)port,now_ms)) { continue; }
    if(state->diagnostics.backoff) {
      if((uint32_t)(now_ms-state->probe_last_ms)>=APP_WEATHER_PROBE_PERIOD_MS) {
        AppWeather_Start(port==BSP_WEATHER_RS485_MET?SENSOR_WEATHER_TEMP_HUM:SENSOR_WEATHER_CO2,now_ms);
      }
    } else {
      unsigned count=port==BSP_WEATHER_RS485_MET?4U:2U;
      for(index=0U;index<count;++index) {
        SensorWeatherItem item=(SensorWeatherItem)(port==BSP_WEATHER_RS485_MET?((unsigned)state->cursor+index)%4U:4U+((unsigned)state->cursor-4U+index)%2U);
        const SensorWeatherMeasurement *measurement=SensorWeather_GetMeasurement(item);
        if(!s_attempted[item] || (uint32_t)(now_ms-measurement->last_query_t_ms)>=AppWeather_PeriodMs(item)) {
          AppWeather_Start(item,now_ms); break;
        }
      }
    }
    now_ms=BspTime_GetTickMs();
  }
}
const AppWeatherPortDiagnostics *AppWeather_GetDiagnostics(BspWeatherRs485Port port)
{ return (unsigned)port<BSP_WEATHER_RS485_PORT_COUNT?&s_ports[port].diagnostics:NULL; }
