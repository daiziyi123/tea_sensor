#ifndef PH_CASES_H
#define PH_CASES_H

static void Test_SoilPhConversion(void)
{
  static const struct
  {
    uint64_t sum;
    uint32_t count;
    int32_t input_mv;
    uint32_t soil_ph_x100;
    SensorPhRange range;
  } cases[] = {
    {6222U,100U,0,300U,SENSOR_PH_RANGE_OK},
    {1571624U,100U,2500,600U,SENSOR_PH_RANGE_OK},
    {2093425U,100U,3333,700U,SENSOR_PH_RANGE_OK},
    {3137026U,100U,5000,900U,SENSOR_PH_RANGE_OK},
    {6221U,100U,0,300U,SENSOR_PH_RANGE_LOW},
    {6223U,100U,0,300U,SENSOR_PH_RANGE_OK},
    {3137025U,100U,5000,900U,SENSOR_PH_RANGE_OK},
    {3137027U,100U,5000,900U,SENSOR_PH_RANGE_HIGH},
    {0U,1U,-10,300U,SENSOR_PH_RANGE_LOW},
    {65535U,1U,10456,900U,SENSOR_PH_RANGE_HIGH},
    {34567U,1U,5511,900U,SENSOR_PH_RANGE_HIGH},
    /* raw=88.311: pre-rounding raw to 88.31 or mV to 4 yields wrong pH 3.00. */
    {88311U,1000U,4,301U,SENSOR_PH_RANGE_OK},
    {56300U,30U,290,335U,SENSOR_PH_RANGE_OK},
    {65537U,3U,3479,717U,SENSOR_PH_RANGE_OK},
    {(uint64_t)UINT32_MAX*65535U,UINT32_MAX,10456,900U,SENSOR_PH_RANGE_HIGH},
    {(uint64_t)UINT32_MAX*32768U,UINT32_MAX,5223,900U,SENSOR_PH_RANGE_HIGH},
    {100000000U,UINT32_MAX,-10,300U,SENSOR_PH_RANGE_LOW}
  };
  SensorPhValue soil_ph;
  unsigned i, before;
  uint32_t raw, last_soil_ph_x100=300U;
  int32_t last_mv=-10;
  Test_Reset(0U); before=s_config_calls;
  assert(SENSOR_PH_RAW_SPAN_X100==3130804U);
  for(i=0U;i<sizeof(cases)/sizeof(cases[0]);++i)
  {
    soil_ph=SensorPh_Convert(cases[i].sum,cases[i].count);
    assert(soil_ph.valid && soil_ph.input_mv==cases[i].input_mv);
    assert(soil_ph.soil_ph_x100==cases[i].soil_ph_x100 && soil_ph.range==cases[i].range);
  }
  soil_ph=SensorPh_Convert(0U,0U);
  assert(!soil_ph.valid && soil_ph.range==SENSOR_PH_RANGE_UNAVAILABLE);
  assert(!SensorPh_Convert(65536U,1U).valid && !SensorPh_Convert(UINT64_MAX,UINT32_MAX).valid);
  for(raw=0U;raw<=UINT16_MAX;++raw)
  {
    soil_ph=SensorPh_Convert(raw,1U);
    assert(soil_ph.valid && soil_ph.input_mv>=last_mv && soil_ph.soil_ph_x100>=last_soil_ph_x100);
    assert(soil_ph.soil_ph_x100>=300U && soil_ph.soil_ph_x100<=900U);
    last_mv=soil_ph.input_mv; last_soil_ph_x100=soil_ph.soil_ph_x100;
  }
  assert(s_config_calls==before && !s_ad4_reads); /* Conversion never starts ADC. */
  assert(!strcmp(SensorPh_RangeName(SENSOR_PH_RANGE_LOW),"LOW"));
  assert(!strcmp(SensorPh_RangeName(SENSOR_PH_RANGE_OK),"OK"));
  assert(!strcmp(SensorPh_RangeName(SENSOR_PH_RANGE_HIGH),"HIGH"));
  assert(!strcmp(SensorPh_RangeName(SENSOR_PH_RANGE_UNAVAILABLE),"NA"));
}

static void Test_SoilPhPrintingAndFailure(void)
{
  unsigned tick, before;
  Test_Reset(0U);
  assert(!App_GetDiagnostics()->last_round.soil_ph.valid && !App_GetDiagnostics()->last_soil_ph.valid);
  s_ad4_poll_result=HAL_TIMEOUT; Test_At(1000U);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "adc_raw=NA,status=ADC_POLL_FAILED"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "input_mv=NA,soil_ph=NA,range=NA"));
  assert(!App_GetDiagnostics()->last_round.soil_ph.valid);
  Test_At(3000U);
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "valid_count=0,adc_raw_min=NA,adc_raw_max=NA,adc_raw_mean=NA"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "input_mv=NA,soil_ph=NA,range=NA"));

  Test_Reset(0U);
  for(tick=0U;tick<2500U;tick+=100U)
  {
    s_ad4_raw=tick<600U?15717U:15716U; /* Exact raw sum/count=392906/25=15716.24. */
    Test_At(tick);
  }
  s_ad4_raw=0U; Test_At(3000U);
  assert(App_GetDiagnostics()->last_ad4_window.raw_sum==392906U);
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "sample_count=25,valid_count=25,adc_raw_min=15716,adc_raw_max=15717,adc_raw_mean=15716.24,error_count=0,status=OK"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "input_mv=2500,soil_ph=6.00,range=OK"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "adc_raw=0,status=OK,input_mv=-10,soil_ph=3.00,range=LOW"));
  assert(!strchr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"),'%'));
  s_ad4_raw=65535U; Test_At(3950U); before=s_config_calls; Test_At(4000U);
  assert(s_config_calls==before);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "input_mv=10456,soil_ph=9.00,range=HIGH"));
  s_ad4_poll_result=HAL_TIMEOUT; s_ad4_stop_result=HAL_ERROR; Test_At(5000U);
  assert(!App_GetDiagnostics()->last_round.soil_ph.valid);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "stage=POLL,hal_status=HAL_TIMEOUT"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "stop_status=HAL_ERROR,input_mv=NA,soil_ph=NA,range=NA"));
  s_ad4_poll_result=HAL_OK; Test_At(6000U);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "adc_raw=NA,status=ADC_STOP_FAILED"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "input_mv=NA,soil_ph=NA,range=NA"));
  assert(!strstr(s_transmitted,"soil_ph") && !strstr(s_transmitted,"AD4") && !strstr(s_transmitted,"input_mv"));
}

static void Test_SoilPhWindowMean(void)
{
  unsigned tick;
  Test_Reset(0U);
  for(tick=0U;tick<3000U;tick+=100U)
  {
    s_ad4_raw=tick==200U?65535U:0U;
    s_ad4_poll_result=tick<300U?HAL_OK:HAL_TIMEOUT;
    s_ad4_stop_result=tick<300U?HAL_OK:HAL_ERROR;
    Test_At(tick);
  }
  s_ad4_poll_result=s_ad4_stop_result=HAL_OK; s_ad4_raw=15716U; Test_At(3000U);
  /* Average raw first: 21845 -> pH 7.17. Average clamped pH would be 5.00. */
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "sample_count=30,valid_count=3,adc_raw_min=0,adc_raw_max=65535,adc_raw_mean=21845.00,error_count=27,status=PARTIAL,cleanup_error_count=27"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "last_error=ADC_POLL_FAILED,last_stage=POLL,last_hal_status=HAL_TIMEOUT"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "last_stop_status=HAL_ERROR,input_mv=3479,soil_ph=7.17,range=OK"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "input_mv=2500,soil_ph=6.00,range=OK"));
  Test_Through(6000U);
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "sample_count=30,valid_count=30,adc_raw_min=15716,adc_raw_max=15716,adc_raw_mean=15716.00,error_count=0,status=OK,cleanup_error_count=0"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "last_error=NONE,last_stage=NONE"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "input_mv=2500,soil_ph=6.00,range=OK"));
}
#endif
