/* Exercise the measured AD2 mapping with exact rational raw means. */
static void Test_WindSpeedCalibration(void)
{
  static const struct
  {
    uint64_t sum;
    uint32_t count;
    int32_t input_mv;
    uint32_t speed_x100;
    SensorWindSpeedRange range;
  } cases[] = {
    {6779U,100U,40,0U,SENSOR_WIND_SPEED_RANGE_OK},
    {1579321U,100U,2540,1500U,SENSOR_WIND_SPEED_RANGE_OK},
    {3151863U,100U,5040,3000U,SENSOR_WIND_SPEED_RANGE_OK},
    {6778U,100U,40,0U,SENSOR_WIND_SPEED_RANGE_LOW},
    {6780U,100U,40,0U,SENSOR_WIND_SPEED_RANGE_OK},
    {3151862U,100U,5040,3000U,SENSOR_WIND_SPEED_RANGE_OK},
    {3151864U,100U,5040,3000U,SENSOR_WIND_SPEED_RANGE_HIGH},
    {0U,1U,29,0U,SENSOR_WIND_SPEED_RANGE_LOW},
    {65535U,1U,10448,3000U,SENSOR_WIND_SPEED_RANGE_HIGH},
    /* Rounded 41mV would yield 0.01m/s via a voltage-first conversion. */
    {73U,1U,41,0U,SENSOR_WIND_SPEED_RANGE_OK},
    /* Rounding the raw mean to 73.03 first would yield 0.00m/s. */
    {73032U,1000U,41,1U,SENSOR_WIND_SPEED_RANGE_OK},
    {12345U,1U,1992,1171U,SENSOR_WIND_SPEED_RANGE_OK},
    {93535U,30U,525,291U,SENSOR_WIND_SPEED_RANGE_OK},
    {(uint64_t)UINT32_MAX*65535U,UINT32_MAX,10448,3000U,SENSOR_WIND_SPEED_RANGE_HIGH},
    {(uint64_t)UINT32_MAX*32768U,UINT32_MAX,5239,3000U,SENSOR_WIND_SPEED_RANGE_HIGH},
    {(uint64_t)UINT32_MAX*67U+123456789U,UINT32_MAX,40,0U,SENSOR_WIND_SPEED_RANGE_LOW}
  };
  SensorWindSpeedValue value;
  SensorWindSpeedWindow window;
  SensorWindSpeedWindowResult result;
  BspAdcResult sample;
  unsigned i;
  uint32_t raw, last_speed=0U;
  int32_t last_mv=0;
  assert(SENSOR_WIND_SPEED_RAW_SPAN_X100==3145084U);
  for(i=0U;i<sizeof(cases)/sizeof(cases[0]);++i)
  {
    value=SensorWindSpeed_ConvertMean(cases[i].sum,cases[i].count);
    assert(value.valid && value.input_mv==cases[i].input_mv);
    assert(value.wind_speed_mps_x100==cases[i].speed_x100 && value.range==cases[i].range);
  }
  value=SensorWindSpeed_ConvertMean(0U,0U);
  assert(!value.valid && value.range==SENSOR_WIND_SPEED_RANGE_UNAVAILABLE);
  assert(!SensorWindSpeed_ConvertMean(65536U,1U).valid);
  assert(!SensorWindSpeed_ConvertMean(UINT64_MAX,UINT32_MAX).valid);
  for(raw=0U;raw<=UINT16_MAX;++raw)
  {
    value=SensorWindSpeed_ConvertMean(raw,1U);
    assert(value.valid && value.input_mv>=last_mv && value.wind_speed_mps_x100>=last_speed);
    assert(value.wind_speed_mps_x100<=3000U);
    last_mv=value.input_mv; last_speed=value.wind_speed_mps_x100;
  }
  memset(&sample,0,sizeof(sample)); sample.valid=1U; sample.stop_attempted=1U;
  SensorWindSpeed_WindowReset(&window);
  for(i=0U;i<100U;++i)
  {
    sample.raw=i<79U?15793U:15794U;
    SensorWindSpeed_WindowAdd(&window,&sample);
  }
  result=SensorWindSpeed_WindowFinish(&window,100U,80U);
  assert(result.raw_sum==1579321U && result.valid_count==100U);
  assert(result.value.valid && result.value.input_mv==2540 && result.value.wind_speed_mps_x100==1500U);
  /* Retain legacy trimmed diagnostics while value uses every valid sample. */
  SensorWindSpeed_WindowReset(&window);
  sample.raw=0U; SensorWindSpeed_WindowAdd(&window,&sample); SensorWindSpeed_WindowAdd(&window,&sample);
  sample.raw=1U; SensorWindSpeed_WindowAdd(&window,&sample);
  sample.raw=65535U; SensorWindSpeed_WindowAdd(&window,&sample);
  result=SensorWindSpeed_WindowFinish(&window,4U,80U);
  assert(result.raw_mean==1U && result.trimmed_sum==1U && result.used_count==2U);
  assert(result.raw_sum==65536U && result.value.input_mv==2634 && result.value.wind_speed_mps_x100==1556U);
  /* Clamping each sample then averaging would yield 7.50m/s, not 15.56. */
  for(i=23U;i<=24U;++i)
  {
    unsigned n; SensorWindSpeed_WindowReset(&window); sample.valid=1U; sample.status=BSP_ADC_OK; sample.raw=0U;
    for(n=0U;n<i;++n) { SensorWindSpeed_WindowAdd(&window,&sample); }
    sample.valid=0U; sample.status=BSP_ADC_POLL_FAILED; sample.hal_status=BSP_ADC_HAL_TIMEOUT;
    for(n=i;n<30U;++n) { SensorWindSpeed_WindowAdd(&window,&sample); }
    result=SensorWindSpeed_WindowFinish(&window,30U,80U);
    assert(result.valid_count==i && result.used_count==(i==24U?22U:0U));
    assert(result.status==(i==24U?SENSOR_WIND_SPEED_WINDOW_OK:SENSOR_WIND_SPEED_WINDOW_INSUFFICIENT));
    assert(result.value.valid && result.value.input_mv==29 && !result.value.wind_speed_mps_x100);
    sample.hal_status=BSP_ADC_HAL_OK;
  }
  SensorWindSpeed_WindowReset(&window);
  result=SensorWindSpeed_WindowFinish(&window,30U,80U);
  assert(!result.value.valid && result.status==SENSOR_WIND_SPEED_WINDOW_INSUFFICIENT);
  window.sample_count=window.valid_count=UINT32_MAX;
  window.raw_min=window.raw_max=UINT16_MAX;
  window.raw_sum=(uint64_t)UINT16_MAX*UINT32_MAX;
  result=SensorWindSpeed_WindowFinish(&window,UINT32_MAX,80U);
  assert(result.raw_sum==window.raw_sum && result.raw_mean==UINT16_MAX);
  assert(result.value.valid && result.value.input_mv==10448 && result.value.wind_speed_mps_x100==3000U);
}

static void Test_AdcPairAndFailures(void)
{
  BspAdcResult adc; SensorWindSpeedData wind;
  unsigned before;
  Test_Reset(0U);
  adc=BspAdc_ReadRaw(BSP_ADC_INPUT_SOIL_AD0);
  assert(adc.valid && adc.raw==15791U && s_selected_channel==ADC_CHANNEL_5 && s_config_calls==1U);
  wind=SensorWindSpeed_Read();
  assert(wind.adc.valid && wind.adc.raw==12345U && s_selected_channel==ADC_CHANNEL_3 && s_config_calls==2U);
  assert(wind.value.valid && wind.value.input_mv==1992 && wind.value.wind_speed_mps_x100==1171U);
  s_raw=0U; adc=BspAdc_ReadRaw(BSP_ADC_INPUT_SOIL_AD0);
  assert(adc.valid && !adc.raw && s_selected_channel==ADC_CHANNEL_5 && s_config_calls==3U && s_cal_calls==1U);
  before=s_config_calls; adc=BspAdc_ReadRaw((BspAdcInput)99);
  assert(!adc.valid && adc.stage==BSP_ADC_STAGE_INPUT && !adc.prepare_attempted && s_config_calls==before);
  s_config_result=HAL_BUSY; adc=BspAdc_ReadRaw(BSP_ADC_INPUT_SOIL_AD0);
  assert(!adc.valid && adc.status==BSP_ADC_START_FAILED && adc.stage==BSP_ADC_STAGE_CONFIG);
  assert(adc.config_status==BSP_ADC_HAL_BUSY && adc.stop_attempted && adc.stop_status==BSP_ADC_HAL_OK);
  wind=SensorWindSpeed_Read(); assert(wind.adc.valid && wind.adc.raw==12345U);
  s_config_result=HAL_OK; s_start_result=HAL_ERROR; adc=BspAdc_ReadRaw(BSP_ADC_INPUT_SOIL_AD0);
  assert(!adc.valid && adc.stage==BSP_ADC_STAGE_START && adc.stop_attempted);
  s_start_result=HAL_OK; s_poll_result=HAL_TIMEOUT; s_stop_result=HAL_ERROR;
  adc=BspAdc_ReadRaw(BSP_ADC_INPUT_SOIL_AD0);
  assert(!adc.valid && adc.stage==BSP_ADC_STAGE_POLL && adc.hal_status==BSP_ADC_HAL_TIMEOUT && adc.stop_status==BSP_ADC_HAL_ERROR);
  /* Unrecoverable shared stop failure prevents both from configuring/starting. */
  s_prepare_result=HAL_TIMEOUT; before=s_config_calls;
  wind=SensorWindSpeed_Read(); adc=BspAdc_ReadRaw(BSP_ADC_INPUT_SOIL_AD0);
  assert(!wind.adc.valid && !adc.valid && s_config_calls==before);
  assert(wind.adc.stage==BSP_ADC_STAGE_PREPARE && adc.prepare_status==BSP_ADC_HAL_TIMEOUT);
  s_prepare_result=HAL_OK; s_poll_result=HAL_OK; s_stop_result=HAL_OK;
  s_wind_stop_result=HAL_ERROR; wind=SensorWindSpeed_Read();
  assert(!wind.adc.valid && wind.adc.stage==BSP_ADC_STAGE_STOP && !wind.value.valid);
  adc=BspAdc_ReadRaw(BSP_ADC_INPUT_SOIL_AD0); assert(adc.valid && !adc.raw);
  s_wind_stop_result=HAL_OK; s_wind_config_result=HAL_ERROR; wind=SensorWindSpeed_Read();
  assert(!wind.adc.valid && wind.adc.stage==BSP_ADC_STAGE_CONFIG && !wind.adc.raw);
  s_wind_config_result=HAL_OK; s_wind_start_result=HAL_BUSY; wind=SensorWindSpeed_Read();
  assert(!wind.adc.valid && wind.adc.stage==BSP_ADC_STAGE_START);
  s_wind_start_result=HAL_OK; s_wind_poll_result=HAL_TIMEOUT; wind=SensorWindSpeed_Read();
  assert(!wind.adc.valid && wind.adc.stage==BSP_ADC_STAGE_POLL);
  s_wind_poll_result=HAL_OK; s_wind_raw=65536U; wind=SensorWindSpeed_Read();
  assert(!wind.adc.valid && wind.adc.status==BSP_ADC_OUT_OF_RANGE);
  s_cal_result=HAL_ERROR; BspAdc_Init(); before=s_config_calls;
  wind=SensorWindSpeed_Read(); adc=BspAdc_ReadRaw(BSP_ADC_INPUT_SOIL_AD0);
  assert(!wind.adc.valid && !adc.valid && adc.stage==BSP_ADC_STAGE_CALIBRATION && s_config_calls==before);
}

static void Test_PairWindowAlignment(void)
{
  const AppDiagnostics *diagnostics;
  unsigned before;
  Test_Reset(0U); s_soil_duration_ms=2U; s_wind_duration_ms=4U; Test_At(0U);
  diagnostics=App_GetDiagnostics();
  assert(diagnostics->last_round.round_id==1U && diagnostics->last_round.round_t_ms==0U);
  assert(diagnostics->last_round.soil_read_start_ms==0U && diagnostics->last_round.soil_read_end_ms==2U);
  assert(diagnostics->last_round.wind_read_start_ms==2U && diagnostics->last_round.wind_read_end_ms==6U && diagnostics->last_round.pair_span_ms==6U);
  Test_At(99U); assert(s_soil_reads==1U && s_wind_reads==1U);
  Test_At(100U); assert(s_soil_reads==2U && s_wind_reads==2U);
  /* A round starts in the old window and AD2 ends in the new wall-clock window. */
  Test_Reset(0U); s_soil_duration_ms=3U; s_wind_duration_ms=7U;
  Test_At(2995U); assert(s_tick_ms==3005U); Test_At(3005U);
  assert(App_GetDiagnostics()->last_window.sample_count==1U && App_GetDiagnostics()->last_wind_window.sample_count==1U);
  assert(App_GetDiagnostics()->last_round.round_t_ms==2995U && App_GetDiagnostics()->last_round.wind_read_end_ms==3005U);
  Test_Reset(0U); s_raw=1000U; s_wind_raw=50000U; Test_At(0U); Test_Through(2900U);
  s_raw=2000U; s_wind_raw=40000U; Test_At(3000U);
  diagnostics=App_GetDiagnostics();
  assert(diagnostics->last_window.adc_raw==1000U && diagnostics->last_wind_window.raw_mean==50000U);
  assert(diagnostics->last_window.sample_count==30U && diagnostics->last_wind_window.sample_count==30U);
  assert(strstr(s_transmitted,"\"adc_raw\":1000") && !strstr(s_transmitted,"\"wind_"));
  assert((diagnostics->last_wind_window.used_count==28U && diagnostics->last_wind_window.trimmed_sum==1400000U && diagnostics->last_wind_window.value.valid && !strstr(s_console,"WIND_WINDOW")));
  s_inject_ack_in_wind=1U; Test_At(3100U); Test_At(3101U); assert(Test_Acks()==1U);
  Test_Through(6000U); assert(s_uart6_sends==2U);
  assert(App_GetDiagnostics()->last_window.adc_raw==2000U && App_GetDiagnostics()->last_wind_window.raw_mean==40000U);
  Test_Reset(0U); Test_At(0U); Test_Through(2300U); s_wind_poll_result=HAL_TIMEOUT; Test_Through(3000U);
  assert(App_GetDiagnostics()->last_window.valid_count==30U && App_GetDiagnostics()->last_wind_window.valid_count==24U);
  assert(App_GetDiagnostics()->last_wind_window.diagnostics.error_counts[BSP_ADC_POLL_FAILED]==6U);
  assert(App_GetDiagnostics()->wind_sample_errors==7U && App_GetDiagnostics()->sample_errors==0U);
  Test_Reset(0U); s_config_result=HAL_ERROR; Test_At(0U); Test_Through(3000U);
  assert(App_GetDiagnostics()->last_window.valid_count==0U && App_GetDiagnostics()->last_wind_window.valid_count==30U);
  assert(App_GetDiagnostics()->last_window.diagnostics.config_error_count==30U);
  assert(strstr(s_transmitted,"\"last_sample_error\":\"ADC_START_FAILED\"")); /* Old server remains compatible. */
  Test_Reset(UINT32_MAX-3U); s_soil_duration_ms=2U; s_wind_duration_ms=4U; Test_At(UINT32_MAX-3U);
  assert(App_GetDiagnostics()->last_round.pair_span_ms==6U && App_GetDiagnostics()->last_round.wind_read_end_ms==2U);
  Test_Reset(0U); Test_At(0U); Test_At(10000U); before=s_soil_reads;
  assert(s_soil_reads==2U && s_wind_reads==2U && App_GetDiagnostics()->last_wind_window.sample_count==0U);
  Test_At(10000U); assert(s_soil_reads==before && s_wind_reads==2U);
}
