/* Isolated software integration fixture, never linked into the MDK target. */
#include "app_upload.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

const char *BspAdc_StatusName(BspAdcStatus status)
{
  if(status==BSP_ADC_OK) { return "OK"; }
  if(status==BSP_ADC_START_FAILED) { return "ADC_START_FAILED"; }
  return "ADC_POLL_FAILED";
}

int main(int argc, char **argv)
{
  char buffer[APP_UPLOAD_FRAME_CAPACITY];
  SensorSoilWindowResult sample;
  AppUploadAck ack;
  uint32_t sequence = 1U;
  int length;
  if (argc > 1 && strcmp(argv[1], "missing") == 0)
  {
    assert(!AppUpload_IsConfigured());
    memset(&sample,0,sizeof(sample));
    assert(AppUpload_Format(buffer,sizeof(buffer),1U,3000U,3000U,&sample)<0);
    return 0;
  }
  if (argc > 1 && (strcmp(argv[1], "ack") == 0 || strcmp(argv[1], "ack2") == 0 || strcmp(argv[1], "ack3") == 0))
  {
    assert(fgets(buffer,sizeof(buffer),stdin));
    uint32_t expected=strcmp(argv[1],"ack3")==0?3U:strcmp(argv[1],"ack2")==0?2U:1U;
    assert(AppUpload_ParseAck(buffer,strlen(buffer),expected,&ack)==APP_UPLOAD_ACK_ACCEPTED);
    assert(ack.id>0U);
    puts("ACK_ACCEPTED");
    return 0;
  }
  memset(&sample,0,sizeof(sample));
  sample.status=SENSOR_SOIL_WINDOW_OK; sample.adc_raw=15791U;
  sample.sample_count=sample.valid_count=30U; sample.used_count=28U;
  sample.moisture_pct_x100=5000U; sample.range=SENSOR_SOIL_RANGE_OK;
  if (argc>1 && strcmp(argv[1],"failure")==0)
  {
    sequence=2U; sample.status=SENSOR_SOIL_WINDOW_INSUFFICIENT;
    sample.valid_count=23U; sample.used_count=0U;
    sample.diagnostics.cleanup_error_count=2U;
    sample.diagnostics.last_error.status=BSP_ADC_POLL_FAILED;
    /* Deliberately leave stale numeric fields: formatter must emit nulls. */
  }
  if (argc>1 && strcmp(argv[1],"configuration")==0)
  {
    sequence=3U; sample.status=SENSOR_SOIL_WINDOW_INSUFFICIENT;
    sample.valid_count=sample.used_count=0U;
    sample.diagnostics.last_error.status=BSP_ADC_START_FAILED;
    sample.diagnostics.last_error.stage=BSP_ADC_STAGE_CONFIG;
    sample.diagnostics.config_error_count=30U;
  }
  length=AppUpload_Format(buffer,sizeof(buffer),sequence,sequence*3000U,3000U,&sample);
  assert(length>0);
  fwrite(buffer,1U,(size_t)length,stdout);
  return 0;
}
