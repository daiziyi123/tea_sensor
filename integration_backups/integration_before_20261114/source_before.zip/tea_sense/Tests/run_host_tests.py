"""Run the real application sources with a fake HAL, never on board hardware."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
GCC = os.environ.get("APP_TEST_GCC") or shutil.which("gcc")
if not GCC:
    candidate = Path(r"D:\Qt\Tools\mingw1310_64\bin\gcc.exe")
    if candidate.exists():
        GCC = str(candidate)
if not GCC:
    raise SystemExit("Set APP_TEST_GCC to a native GCC executable")
env = dict(os.environ)
env["PATH"] = str(Path(GCC).resolve().parent) + os.pathsep + env.get("PATH", "")
sources = sorted(source for layer in ("App", "Sensors", "Bsp") for source in (ROOT / layer / "Src").glob("*.c"))
sources += [ROOT / "Tests/host_stdio.c"]
base = [GCC, "-std=c11", "-Wall", "-Wextra", "-Werror", "-fno-builtin",
        "-I" + str(ROOT / "Tests/stubs"), "-I" + str(ROOT / "App/Inc"),
        "-I" + str(ROOT / "Sensors/Inc"), "-I" + str(ROOT / "Bsp/Inc")]
variants = {
    "auto_direction": [],
    "calibration_independent_of_vref": ["-DBSP_ADC_VREF_MV=2500"],
    "short_hardware_timeouts": ["-DBSP_ADC_POLL_TIMEOUT_MS=1",
        "-DBSP_CONSOLE_TX_TIMEOUT_MS=2", "-DBSP_CONSOLE_TC_TIMEOUT_MS=3"],
    "manual_fake_gpio": [
        "-DBSP_RS485_DIRECTION_MODE=1", "-DBSP_RS485_MANUAL_WIRING_CONFIRMED=1",
        "-DBSP_RS485_GPIO_PORT=(&fake_gpio)", "-DBSP_RS485_GPIO_PIN=1",
        "-DBSP_RS485_GPIO_CLOCK_ENABLE=TestEnableGpioClock",
        "-DBSP_RS485_TX_LEVEL=GPIO_PIN_SET", "-DBSP_RS485_RX_LEVEL=GPIO_PIN_RESET"],
}
with tempfile.TemporaryDirectory(prefix="tea_sense_host_") as tmp:
    Path(tmp, "app_secrets.h").write_text('#define APP_INGEST_TOKEN_CONFIGURED 1\n#define APP_INGEST_TOKEN_JSON "\\\"test-upload-token\\\""\n')
    base[1:1] = ["-I" + tmp]
    for name, options in variants.items():
        for test in ("soil_host_test", "dtu_host_test"):
            exe = Path(tmp) / (name + "_" + test + ".exe")
            interception = ["-include", str(ROOT / "Tests/stubs/stdio_fault.h")] if test == "dtu_host_test" else []
            subprocess.run(base + options + interception + list(map(str, sources)) +
                           [str(ROOT / "Tests" / (test + ".c")), "-o", str(exe)], check=True, env=env)
            print(name + ": " + test, flush=True)
            subprocess.run([str(exe)], check=True, env=env)
    # The unconfirmed manual configuration must be rejected at compile time.
    denied = subprocess.run(base + ["-DBSP_RS485_DIRECTION_MODE=1", "-c",
        str(ROOT / "Bsp/Src/bsp_rs485_dir.c"), "-o", str(Path(tmp) / "denied.o")],
        capture_output=True, text=True, env=env)
    assert denied.returncode != 0 and "Confirm automatic circuit isolation" in denied.stderr
    print("PASS: unconfirmed manual mode is blocked at compile time")
    # Endpoint constants stay in the module; reject a zero-span configuration.
    invalid_header = Path(tmp) / "sensor_soil.h"
    invalid_header.write_text((ROOT / "Sensors/Inc/sensor_soil.h").read_text().replace(
        "#define SENSOR_SOIL_RAW_WET 31146U", "#define SENSOR_SOIL_RAW_WET 436U"))
    denied = subprocess.run(base[:1] + ["-I" + tmp] + base[1:] + ["-c",
        str(ROOT / "Sensors/Src/sensor_soil.c"), "-o", str(Path(tmp) / "invalid_calibration.o")],
        capture_output=True, text=True, env=env)
    assert denied.returncode != 0 and "must be greater than" in denied.stderr
    print("PASS: zero calibration span is rejected at compile time")
    invalid_header.unlink()
    Path(tmp, "app_secrets.h").write_text('#define APP_INGEST_TOKEN_CONFIGURED 0\n#define APP_INGEST_TOKEN_JSON "\\\"\\\""\n')
    missing = Path(tmp) / "missing_key.exe"
    subprocess.run(base + [str(ROOT / "App/Src/app_upload.c"), str(ROOT / "App/Src/core_json.c"),
        str(ROOT / "Tests/upload_wire_fixture.c"), "-o", str(missing)], check=True, env=env)
    subprocess.run([str(missing), "missing"], check=True, env=env)
    print("PASS: missing private key explicitly disables JSON upload")
