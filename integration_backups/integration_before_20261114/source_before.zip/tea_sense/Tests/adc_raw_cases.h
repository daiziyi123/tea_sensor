#ifndef ADC_RAW_CASES_H
#define ADC_RAW_CASES_H

/* Match fields within one CRLF record, never across the adjacent channel. */
static const char *Test_RawRow(const char *kind, const char *channel)
{
  static char row[1024];
  const char *begin = s_console;
  while (*begin)
  {
    const char *end = strstr(begin, "\r\n");
    const char *match = strstr(begin, channel);
    assert(end != NULL);
    if (!strncmp(begin, kind, strlen(kind)) && match && match < end)
    {
      size_t length = (size_t)(end - begin);
      assert(length < sizeof(row));
      memcpy(row, begin, length); row[length] = '\0';
      return row;
    }
    begin = end + 2;
  }
  assert(!"Missing raw ADC record");
  return "";
}

static void Test_RawSamplesAndFaults(void)
{
  const AppSampleRound *round;
  BspAdcResult adc;
  unsigned before;
  Test_Reset(0U); s_soil_duration_ms=2U; s_wind_duration_ms=3U;
  s_ad3_duration_ms=4U; s_ad4_duration_ms=5U;
  Test_At(950U); before=s_config_calls; Test_At(1000U);
  round=&App_GetDiagnostics()->last_round;
  assert(s_config_calls==before && before==4U && s_ad4_reads==1U && s_wind_reads==1U);
  assert(round->ad4_read_start_ms==959U && round->ad4_read_end_ms==964U && round->round_span_ms==14U);
  assert(!strcmp(Test_RawRow("ADC_SAMPLE,", "channel=AD2,"),
    "ADC_SAMPLE,round_id=1,sample_t_ms=952,channel=AD2,pin=PA6,adc_channel=3,adc_raw=12345,status=OK,input_mv=1992,wind_speed_mps=11.71,range=OK"));
  assert(!strcmp(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"),
    "ADC_SAMPLE,round_id=1,sample_t_ms=959,channel=AD4,pin=PA4,adc_channel=18,adc_raw=34567,status=OK,input_mv=5511,soil_ph=9.00,range=HIGH"));
  Test_At(1001U); assert(!s_console_length && s_config_calls==before);

  Test_Reset(0U); s_wind_raw=s_ad4_raw=0U; Test_At(1000U);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD2,"), "adc_raw=0,status=OK"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD2,"), "input_mv=29,wind_speed_mps=0.00,range=LOW"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "adc_raw=0,status=OK"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "input_mv=-10,soil_ph=3.00,range=LOW"));
  s_wind_raw=321U; s_ad4_raw=999U; s_ad4_poll_result=HAL_TIMEOUT; s_ad4_stop_result=HAL_ERROR;
  Test_At(2000U); round=&App_GetDiagnostics()->last_round;
  assert(round->wind.adc.valid && round->wind.adc.raw==321U && !round->ad4.valid);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD2,"), "adc_raw=321,status=OK"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"),
    "adc_raw=NA,status=ADC_POLL_FAILED,stage=POLL,hal_status=HAL_TIMEOUT,prepare_status=HAL_OK,config_status=HAL_OK,stop_status=HAL_ERROR"));
  s_ad4_poll_result=HAL_OK; Test_At(3000U);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "adc_raw=NA,status=ADC_STOP_FAILED,stage=STOP"));
  s_ad4_stop_result=HAL_OK; s_ad4_config_result=HAL_BUSY; Test_At(4000U);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "stage=CONFIG,hal_status=HAL_BUSY"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "config_status=HAL_BUSY,stop_status=HAL_OK"));
  s_ad4_config_result=HAL_OK; s_ad4_start_result=HAL_ERROR; Test_At(5000U);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "stage=START,hal_status=HAL_ERROR"));
  s_ad4_start_result=HAL_OK; s_ad4_raw=65536U; Test_At(6000U);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "adc_raw=NA,status=ADC_OUT_OF_RANGE,stage=VALUE"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"),
    "sample_count=3,valid_count=0,adc_raw_min=NA,adc_raw_max=NA,adc_raw_mean=NA,error_count=3,status=NO_VALID_SAMPLES,cleanup_error_count=1,prepare_error_count=0,config_error_count=1"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "last_error=ADC_START_FAILED,last_stage=START"));
  s_ad4_raw=65535U; s_wind_poll_result=HAL_TIMEOUT; Test_At(7000U);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD2,"), "adc_raw=NA,status=ADC_POLL_FAILED"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD2,"), "input_mv=NA,wind_speed_mps=NA,range=NA"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "adc_raw=65535,status=OK"));
  s_prepare_result=HAL_TIMEOUT; before=s_config_calls; Test_At(8000U);
  assert(s_config_calls==before);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"),
    "stage=PREPARE,hal_status=HAL_TIMEOUT,prepare_status=HAL_TIMEOUT,config_status=NA,stop_status=NA"));
  s_cal_result=HAL_ERROR; BspAdc_Init(); Test_At(9000U);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD4,"), "status=ADC_CAL_FAILED,stage=CALIBRATION"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "error_count=2,status=PARTIAL,cleanup_error_count=0,prepare_error_count=1,config_error_count=0"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "last_error=ADC_STOP_FAILED,last_stage=PREPARE,last_hal_status=HAL_TIMEOUT"));
  adc=BspAdc_ReadRaw(BSP_ADC_INPUT_PH_AD4);
  assert(!adc.valid && !adc.prepare_attempted && !adc.stop_attempted);
  assert(s_config_calls==before && !strstr(s_transmitted,"AD4") && !strstr(s_transmitted,"AD2"));
}

static void Test_RawWindows(void)
{
  const AppDiagnostics *d;
  unsigned tick;
  Test_Reset(0U);
  for(tick=0U;tick<3000U;tick+=100U)
  {
    s_wind_raw=tick==0U?0U:tick==2900U?65535U:1000U;
    s_ad4_raw=tick==0U?100U:tick==2900U?200U:2000U;
    Test_At(tick);
  }
  s_wind_raw=7U; s_ad4_raw=11U; Test_At(3000U); d=App_GetDiagnostics();
  assert(d->last_wind_window.raw_sum==93535U && d->last_wind_window.raw_mean==1000U);
  assert(d->last_wind_window.trimmed_sum==28000U && d->last_wind_window.used_count==28U);
  assert(d->last_ad4_window.raw_sum==56300U);
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"),
    "window_end_ms=3000,sample_count=30,valid_count=30,adc_raw_min=0,adc_raw_max=65535,adc_raw_mean=3117.83,error_count=0,status=OK"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"), "input_mv=525,wind_speed_mps=2.91,range=OK"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"),
    "adc_raw_min=100,adc_raw_max=2000,adc_raw_mean=1876.67,error_count=0,status=OK"));
  assert(!strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "wind_speed_mps="));
  Test_Through(6000U);
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"), "adc_raw_min=7,adc_raw_max=7,adc_raw_mean=7.00"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "adc_raw_min=11,adc_raw_max=11,adc_raw_mean=11.00"));
  assert(App_GetDiagnostics()->last_ad4_window.raw_sum==330U);

  /* Sparse valid values still have an ordinary mean below the old quality gate. */
  Test_Reset(0U);
  for(tick=0U;tick<3000U;tick+=100U)
  {
    s_wind_raw=tick==0U?0U:tick==300U?65535U:1U;
    s_ad4_raw=tick==0U?0U:tick==100U?65535U:2U;
    s_wind_poll_result=tick<400U?HAL_OK:HAL_TIMEOUT;
    s_ad4_poll_result=tick<300U?HAL_OK:HAL_TIMEOUT;
    s_ad4_stop_result=tick<300U?HAL_OK:HAL_ERROR;
    Test_At(tick);
  }
  Test_At(3000U); d=App_GetDiagnostics();
  assert(!d->last_wind_window.used_count && d->last_wind_window.raw_sum==65537U);
  assert(d->last_ad4_window.cleanup_errors==27U && d->last_ad4_window.error_counts[BSP_ADC_POLL_FAILED]==27U);
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"),
    "sample_count=30,valid_count=4,adc_raw_min=0,adc_raw_max=65535,adc_raw_mean=16384.25,error_count=26,status=PARTIAL"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"), "input_mv=2634,wind_speed_mps=15.56,range=OK"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"),
    "sample_count=30,valid_count=3,adc_raw_min=0,adc_raw_max=65535,adc_raw_mean=21845.67,error_count=27,status=PARTIAL,cleanup_error_count=27"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "last_error=ADC_POLL_FAILED,last_stage=POLL,last_hal_status=HAL_TIMEOUT"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "last_stop_status=HAL_ERROR"));

  Test_Reset(0U); s_wind_raw=s_ad4_raw=0U; Test_At(0U); Test_Through(3000U);
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"), "adc_raw_min=0,adc_raw_max=0,adc_raw_mean=0.00,error_count=0,status=OK"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "adc_raw_min=0,adc_raw_max=0,adc_raw_mean=0.00,error_count=0,status=OK"));
  Test_Reset(0U); s_wind_poll_result=s_ad4_poll_result=HAL_TIMEOUT;
  s_wind_stop_result=s_ad4_stop_result=HAL_ERROR; Test_At(0U); Test_Through(3000U);
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"), "valid_count=0,adc_raw_min=NA,adc_raw_max=NA,adc_raw_mean=NA,error_count=30,status=NO_VALID_SAMPLES,cleanup_error_count=30"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"), "input_mv=NA,wind_speed_mps=NA,range=NA"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "valid_count=0,adc_raw_min=NA,adc_raw_max=NA,adc_raw_mean=NA,error_count=30,status=NO_VALID_SAMPLES,cleanup_error_count=30"));
}

static void Test_RawWindowBoundaries(void)
{
  uint32_t base=UINT32_MAX-1499U;
  unsigned before;
  Test_Reset(0U); s_ad4_duration_ms=10U; s_ad4_raw=123U;
  Test_At(2995U); Test_At(3005U);
  assert(App_GetDiagnostics()->last_ad4_window.sample_count==1U);
  assert(App_GetDiagnostics()->last_wind_window.sample_count==1U);
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "sample_count=1,valid_count=1,adc_raw_min=123,adc_raw_max=123,adc_raw_mean=123.00"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "input_mv=10,soil_ph=3.01,range=OK"));
  Test_Reset(base); s_ad4_raw=500U; Test_At(base); Test_At(base+2900U);
  s_ad4_raw=900U; Test_At(base+3000U);
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "window_end_ms=1500,sample_count=2,valid_count=2,adc_raw_min=500,adc_raw_max=500,adc_raw_mean=500.00"));
  assert(App_GetDiagnostics()->last_round.ad4.raw==900U);
  Test_Reset(UINT32_MAX-3U); s_soil_duration_ms=2U; s_wind_duration_ms=4U;
  s_ad3_duration_ms=3U; s_ad4_duration_ms=5U; Test_At(UINT32_MAX-3U);
  assert(App_GetDiagnostics()->last_round.ad4_read_start_ms==5U && App_GetDiagnostics()->last_round.ad4_read_end_ms==10U);
  Test_Reset(0U); Test_At(0U); Test_At(10000U); before=s_config_calls;
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"), "window_end_ms=9000,sample_count=0,valid_count=0,adc_raw_min=NA,adc_raw_max=NA,adc_raw_mean=NA,error_count=0,status=NO_SAMPLES"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"), "input_mv=NA,wind_speed_mps=NA,range=NA"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "window_end_ms=9000,sample_count=0,valid_count=0,adc_raw_min=NA,adc_raw_max=NA,adc_raw_mean=NA,error_count=0,status=NO_SAMPLES"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD4,"), "input_mv=NA,soil_ph=NA,range=NA"));
  assert(s_wind_reads==2U && s_ad4_reads==2U && s_cal_calls==1U);
  Test_At(10000U); assert(s_config_calls==before && !s_console_length);
}

static void Test_WindSpeedPrinting(void)
{
  unsigned tick, before;
  Test_Reset(0U);
  for(tick=0U;tick<2800U;tick+=200U)
  {
    s_wind_raw=tick<2200U?15793U:15794U; /* Sum/count=221105/14, display 15793.21. */
    Test_At(tick);
  }
  s_wind_raw=0U; Test_At(3000U);
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"), "sample_count=14,valid_count=14"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"), "adc_raw_mean=15793.21"));
  assert(strstr(Test_RawRow("ADC_WINDOW,", "channel=AD2,"), "input_mv=2540,wind_speed_mps=15.00,range=OK"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD2,"), "input_mv=29,wind_speed_mps=0.00,range=LOW"));
  s_wind_raw=65535U; Test_At(3950U); before=s_config_calls; Test_At(4000U);
  assert(s_config_calls==before);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD2,"), "input_mv=10448,wind_speed_mps=30.00,range=HIGH"));
  s_wind_stop_result=HAL_ERROR; Test_At(5000U);
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD2,"), "adc_raw=NA,status=ADC_STOP_FAILED"));
  assert(strstr(Test_RawRow("ADC_SAMPLE,", "channel=AD2,"), "input_mv=NA,wind_speed_mps=NA,range=NA"));
  assert(!App_GetDiagnostics()->last_round.wind.value.valid);
  assert(!strstr(s_transmitted,"input_mv") && !strstr(s_transmitted,"wind_speed"));
}
#endif
