"""Real C JSON -> loopback TCP -> temporary SQLite -> API -> real C ACK parser.

Run with the server's .venv Python and --server-root. Never reads .env, uses
the real device ID, contacts the DTU/public tunnel, or opens the existing DB.
"""
import argparse
import csv
import io
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--server-root", type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.server_root.resolve()))
from fastapi.testclient import TestClient
from app.config import Settings
from app.main import create_app

gcc = os.getenv("APP_TEST_GCC") or shutil.which("gcc")
if not gcc:
    raise SystemExit("Set APP_TEST_GCC to a native GCC executable")
env = dict(os.environ)
env["PATH"] = str(Path(gcc).parent) + os.pathsep + env.get("PATH", "")
with tempfile.TemporaryDirectory(prefix="tea_wire_integration_") as directory:
    temp = Path(directory)
    (temp / "app_secrets.h").write_text(
        '#define APP_INGEST_TOKEN_CONFIGURED 1\n'
        '#define APP_INGEST_TOKEN_JSON "\\\"fixture-ingest\\\""\n')
    executable = temp / "wire_fixture.exe"
    command = [gcc, "-std=c11", "-Wall", "-Wextra", "-Werror",
               '-DAPP_DEVICE_ID="demo_h743_001"']
    command += ["-I" + str(path) for path in
                (temp, ROOT / "App/Inc", ROOT / "Sensors/Inc", ROOT / "Bsp/Inc")]
    command += [str(ROOT / path) for path in
                ("App/Src/app_upload.c", "App/Src/core_json.c", "Tests/upload_wire_fixture.c")]
    subprocess.run(command + ["-o", str(executable)], check=True, env=env)
    payload = subprocess.check_output([str(executable)], env=env)
    assert payload.endswith(b"\r\n") and json.loads(payload)["device_id"] == "demo_h743_001"
    application = create_app(Settings(database=temp / "isolated.db", tcp_port=0,
                                      ingest_token="fixture-ingest", view_token="fixture-view"))
    headers = {"X-View-Token": "fixture-view"}
    with TestClient(application) as client:
        port = application.state.receiver.server.sockets[0].getsockname()[1]
        with socket.create_connection(("127.0.0.1", port), timeout=3) as connection:
            # Fragment the C-produced CRLF frame across actual socket writes.
            connection.sendall(payload[:17])
            connection.sendall(payload[17:])
            with connection.makefile("rb") as stream:
                ack = stream.readline()
        result = subprocess.check_output([str(executable), "ack"], input=ack, env=env)
        assert result.strip() == b"ACK_ACCEPTED"
        query = {"device_id": "demo_h743_001", "hours": 24, "limit": 100}
        assert client.get("/api/readings", params=query).status_code == 401
        response = client.get("/api/readings", params=query, headers=headers)
        row = response.json()["items"][0]
        assert (row["adc_raw"], row["moisture_pct"], row["t_ms"], row["seq"]) == (15791, 50.0, 3000, 1)
        assert [row[key] for key in ("window_ms", "sample_count", "valid_count", "used_count")] == [3000, 30, 30, 28]
        assert row["id"] == json.loads(ack)["id"] and "token" not in row
        exported = client.get("/api/export.csv", params=query, headers=headers)
        rows = list(csv.DictReader(io.StringIO(exported.content.decode("utf-8-sig"))))
        assert len(rows) == 1 and rows[0]["device_id"] == "demo_h743_001"
        assert rows[0]["adc_raw"] == "15791" and "token" not in exported.text
        assert rows[0]["used_count"] == "28" and rows[0]["window_ms"] == "3000"
        assert client.get("/api/readings", params={"device_id":"tea_h743_001"}, headers=headers).json()["items"] == []
        failed_payload = subprocess.check_output([str(executable), "failure"], env=env)
        with socket.create_connection(("127.0.0.1", port), timeout=3) as connection:
            connection.sendall(failed_payload)
            with connection.makefile("rb") as stream:
                failed_ack = stream.readline()
        assert subprocess.check_output([str(executable), "ack2"], input=failed_ack, env=env).strip() == b"ACK_ACCEPTED"
        failed_row = client.get("/api/readings", params=query, headers=headers).json()["items"][0]
        assert failed_row["status"] == "WINDOW_INSUFFICIENT"
        assert failed_row["adc_raw"] is None and failed_row["moisture_pct"] is None
        assert (failed_row["valid_count"], failed_row["used_count"], failed_row["sample_error_count"]) == (23, 0, 7)
        assert failed_row["last_sample_error"] == "ADC_POLL_FAILED"
        config_payload = subprocess.check_output([str(executable), "configuration"], env=env)
        assert not any(key.startswith("wind_") for key in json.loads(config_payload))
        with socket.create_connection(("127.0.0.1", port), timeout=3) as connection:
            connection.sendall(config_payload)
            with connection.makefile("rb") as stream:
                config_ack = stream.readline()
        assert subprocess.check_output([str(executable), "ack3"], input=config_ack, env=env).strip() == b"ACK_ACCEPTED"
        config_row = client.get("/api/readings", params=query, headers=headers).json()["items"][0]
        assert config_row["last_sample_error"] == "ADC_START_FAILED" and config_row["valid_count"] == 0
    print("PASS: production C formatter -> fragmented TCP -> committed temporary SQLite -> authenticated API/CSV -> production C ACK parser")
    print("Only demo_h743_001 and fixture credentials used; no hardware/public DTU or production database involved")
    print("PASS: insufficient C window nulls stale values and preserves counts/error diagnostics through server ACK/storage/API")
    print("PASS: pre-start/configuration error keeps the existing soil wire class; no wind fields or server changes required")
