"""Optional CPU emulation of the real linked Arm printf path, with fake HAL.

Requires Python unicorn (or APP_ARM_EMULATOR_PATH pointing to its package dir)
and a fresh MDK build. No target board or debugger is used. Only main.o is
replaced in a temporary image; App, Sensors, Bsp and Arm libc are production.
"""
import os
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

if os.environ.get("APP_ARM_EMULATOR_PATH"):
    sys.path.insert(0, os.environ["APP_ARM_EMULATOR_PATH"])
try:
    from unicorn import Uc, UC_ARCH_ARM, UC_MODE_THUMB, UC_MODE_MCLASS, UC_HOOK_CODE
    from unicorn.arm_const import UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_LR, UC_ARM_REG_PC, UC_ARM_REG_SP
except ImportError:
    raise SystemExit("Optional ARM printf execution requires Python unicorn / APP_ARM_EMULATOR_PATH")

ROOT = Path(__file__).resolve().parents[1]
MDK = ROOT / "MDK-ARM"
TOOLS = Path(os.environ.get("BSP_ARM_BIN", r"D:\Program Files\Keil_v5\ARM\ARMCC\bin"))
HARNESS = r'''
#include <stdint.h>
#include <stdio.h>
#include "app_main.h"
#include "app_weather.h"
#include "usart.h"
volatile uint32_t g_test_tick_ms, g_test_raw, g_test_tx_error, g_test_poll_error, g_test_stage;
volatile uint32_t g_test_printf_errors;
volatile uint32_t g_test_soil_channel, g_test_wind_channel, g_test_ad3_channel, g_test_ad3_raw;
volatile uint32_t g_test_ad4_channel, g_test_ad4_raw, g_test_ad4_poll_error;
volatile uint8_t *g_test_dtu_rx_byte;
uint8_t g_test_dtu_tx[160];
volatile uint32_t g_test_dtu_tx_length;
volatile uint8_t *g_test_weather_rx[2];
uint8_t g_test_weather_reply[2][9];
volatile uint32_t g_test_weather_length[2];
volatile uint32_t g_test_acks, g_test_ack_sequence;
volatile uint32_t g_test_window_end, g_test_soil_valid, g_test_soil_used, g_test_soil_mean;
volatile uint32_t g_test_wind_valid, g_test_wind_used, g_test_wind_mean;
volatile uint32_t g_test_ad3_samples, g_test_ad3_valid, g_test_ad3_sum;
volatile int32_t g_test_wind_input_mv;
volatile uint32_t g_test_wind_speed_x100, g_test_wind_range, g_test_wind_value_valid;
volatile int32_t g_test_soil_ph_input_mv;
volatile uint32_t g_test_soil_ph_x100, g_test_soil_ph_range, g_test_soil_ph_valid;
__attribute__((noinline)) void TestArm_Observe(uint32_t stage) { g_test_stage=stage; }
__attribute__((noinline)) void TestArm_Check(uint32_t stage)
{
  const AppDiagnostics *d=App_GetDiagnostics();
  g_test_acks=d->dtu_ack_count; g_test_ack_sequence=d->dtu_ack_sequence;
  g_test_window_end=d->last_window_end_ms;
  g_test_soil_valid=d->last_window.valid_count; g_test_soil_used=d->last_window.used_count;
  g_test_soil_mean=d->last_window.adc_raw;
  g_test_wind_valid=d->last_wind_window.valid_count; g_test_wind_used=d->last_wind_window.used_count;
  g_test_wind_mean=d->last_wind_window.raw_mean;
  g_test_ad3_samples=d->last_ad3_window.sample_count; g_test_ad3_valid=d->last_ad3_window.valid_count;
  g_test_ad3_sum=(uint32_t)d->last_ad3_window.raw_sum;
  TestArm_Observe(stage);
}
__attribute__((noinline)) void TestArm_Done(void) { for (;;) {} }
static void TestArm_WindMapping(uint32_t stage, uint64_t sum, uint32_t count)
{
  SensorWindSpeedValue value=SensorWindSpeed_ConvertMean(sum,count);
  g_test_wind_input_mv=value.input_mv; g_test_wind_speed_x100=value.wind_speed_mps_x100;
  g_test_wind_range=value.range; g_test_wind_value_valid=value.valid;
  TestArm_Observe(stage);
}
void Error_Handler(void) { for (;;) {} }
static void TestArm_SoilPhMapping(uint32_t stage, uint64_t sum, uint32_t count)
{
  SensorPhValue soil_ph=SensorPh_Convert(sum,count);
  g_test_soil_ph_input_mv=soil_ph.input_mv; g_test_soil_ph_x100=soil_ph.soil_ph_x100;
  g_test_soil_ph_range=soil_ph.range; g_test_soil_ph_valid=soil_ph.valid;
  TestArm_Observe(stage);
}
static void TestArm_Through(uint32_t end)
{
  while (g_test_tick_ms < end) { g_test_tick_ms = (g_test_tick_ms / 100U + 1U) * 100U; App_Process(); }
}
static void TestArm_Ack(uint32_t stage)
{
  uint32_t index;
  g_test_tick_ms += 10U;
  for (index=0U; index<g_test_dtu_tx_length; ++index)
  {
    *g_test_dtu_rx_byte=g_test_dtu_tx[index]; HAL_UART_RxCpltCallback(&huart6);
  }
  App_Process(); TestArm_Check(stage);
}
static void TestArm_Weather(void)
{
  uint32_t tick,port,index;
  huart3.Instance=USART3; huart4.Instance=UART4;
  NVIC->ISER[(uint32_t)USART3_IRQn/32U] |= 1UL<<((uint32_t)USART3_IRQn%32U);
  NVIC->ISER[(uint32_t)UART4_IRQn/32U] |= 1UL<<((uint32_t)UART4_IRQn%32U);
  AppWeather_Init();
  for(tick=10000U;tick<=12000U;++tick) {
    g_test_tick_ms=tick; AppWeather_Process();
    for(port=0U;port<2U;++port) {
      for(index=0U;index<g_test_weather_length[port];++index) {
        *g_test_weather_rx[port]=g_test_weather_reply[port][index];
        HAL_UART_RxCpltCallback(port?&huart4:&huart3);
      }
      g_test_weather_length[port]=0U;
    }
  }
  TestArm_Check(13U);
}
int main(void)
{
  g_test_raw = 15791U;
  g_test_soil_channel=ADC_CHANNEL_5; g_test_wind_channel=ADC_CHANNEL_3;
  g_test_ad3_channel=ADC_CHANNEL_19; g_test_ad3_raw=23456U;
  g_test_ad4_channel=ADC_CHANNEL_18; g_test_ad4_raw=34567U;
  if(g_test_soil_channel==g_test_wind_channel) { Error_Handler(); }
  App_Init(); App_Process(); TestArm_Through(900U); TestArm_Check(0U);
  TestArm_Through(1000U); TestArm_Check(1U); TestArm_Through(1900U);
  g_test_raw=0U; g_test_ad3_raw=0U; g_test_ad4_raw=0U; TestArm_Through(2000U); TestArm_Check(2U);
  g_test_poll_error=1U; g_test_ad4_poll_error=1U; TestArm_Through(3000U); TestArm_Check(3U);
  TestArm_Ack(11U); g_test_poll_error=0U; g_test_ad4_poll_error=0U; TestArm_Through(3900U);
  g_test_tx_error=1U; TestArm_Through(4000U);
  g_test_printf_errors = App_GetDiagnostics()->printf_errors; TestArm_Check(4U);
  g_test_tx_error=0U; TestArm_Through(5000U); TestArm_Check(5U);
  printf("direct=%lu\r\n", 7UL); TestArm_Check(6U);
  TestArm_Through(5900U); g_test_raw=436U; g_test_ad3_raw=65535U; g_test_ad4_raw=65535U; TestArm_Through(6000U); TestArm_Check(7U);
  TestArm_Ack(12U); TestArm_Through(6900U);
  g_test_raw=31146U; TestArm_Through(7000U); TestArm_Check(8U); TestArm_Through(7900U);
  g_test_raw=65535U; TestArm_Through(8000U); TestArm_Check(9U); TestArm_Through(8900U);
  g_test_raw=438U; TestArm_Through(9000U); TestArm_Check(10U);
  TestArm_Weather();
  TestArm_WindMapping(20U,6779U,100U);
  TestArm_WindMapping(21U,1579321U,100U);
  TestArm_WindMapping(22U,3151863U,100U);
  TestArm_WindMapping(23U,0U,1U);
  TestArm_WindMapping(24U,65535U,1U);
  TestArm_WindMapping(25U,0U,0U);
  TestArm_WindMapping(26U,73032U,1000U);
  TestArm_WindMapping(27U,(uint64_t)UINT32_MAX*65535U,UINT32_MAX);
  TestArm_WindMapping(28U,(uint64_t)UINT32_MAX*67U+123456789U,UINT32_MAX);
  TestArm_SoilPhMapping(30U,6222U,100U);
  TestArm_SoilPhMapping(31U,1571624U,100U);
  TestArm_SoilPhMapping(32U,2093425U,100U);
  TestArm_SoilPhMapping(33U,3137026U,100U);
  TestArm_SoilPhMapping(34U,0U,1U);
  TestArm_SoilPhMapping(35U,65535U,1U);
  TestArm_SoilPhMapping(36U,0U,0U);
  TestArm_SoilPhMapping(37U,88311U,1000U);
  TestArm_SoilPhMapping(38U,(uint64_t)UINT32_MAX*65535U,UINT32_MAX);
  TestArm_SoilPhMapping(39U,6221U,100U);
  TestArm_SoilPhMapping(40U,3137027U,100U);
  TestArm_Done();
  return 0;
}
'''

def elf_sections_and_symbols(binary):
    header = struct.unpack_from("<16sHHIIIIIHHHHHH", binary)
    sections = [struct.unpack_from("<IIIIIIIIII", binary, header[6] + index * header[11])
                for index in range(header[12])]
    symbols = {}
    for section in sections:
        if section[1] != 2:
            continue
        strings_section = sections[section[6]]
        strings = binary[strings_section[4]:strings_section[4] + strings_section[5]]
        for offset in range(section[4], section[4] + section[5], section[9]):
            name, address, size, info, other, index = struct.unpack_from("<IIIBBH", binary, offset)
            label = strings[name:strings.find(b"\0", name)].decode(errors="replace")
            if address:
                symbols[label] = address
    return sections, symbols

with tempfile.TemporaryDirectory(prefix="tea_sense_arm_printf_") as folder:
    folder = Path(folder)
    source, obj = folder / "test_main.c", folder / "test_main.o"
    source.write_text(HARNESS, encoding="utf-8")
    project = ET.parse(MDK / "tea_sense.uvprojx")
    compile_command = [str(TOOLS / "armcc.exe"), "--cpu", "Cortex-M7.fp.dp", "--c99", "--gnu", "-O1", "--split_sections"]
    compile_command += ["-D" + definition for definition in project.findtext(".//Cads/VariousControls/Define").split(",")]
    for include in project.findtext(".//Cads/VariousControls/IncludePath").split(";"):
        compile_command += ["-I", str((MDK / include).resolve())]
    subprocess.run(compile_command + ["-c", str(source), "-o", str(obj)], check=True)
    response = (MDK / "tea_sense/tea_sense.lnp").read_text()
    assert response.count('"tea_sense\\main.o"') == 1
    response = response.replace('"tea_sense\\main.o"', '"' + str(obj) + '"')
    image = folder / "printf.axf"
    response = re.sub(r"--list[^\r\n]*", lambda _: f'--list "{folder / "printf.map"}" -o "{image}"', response)
    link = folder / "printf.lnp"
    link.write_text(response)
    subprocess.run([str(TOOLS / "armlink.exe"), "--via", str(link)], cwd=MDK, check=True)
    binary = image.read_bytes()
    sections, symbols = elf_sections_and_symbols(binary)
    cpu = Uc(UC_ARCH_ARM, UC_MODE_THUMB | UC_MODE_MCLASS)
    for address, size in ((0x08000000, 0x200000), (0x20000000, 0x20000),
                          (0x24000000, 0x80000), (0x40000000, 0x10000), (0xE000E000, 0x2000)):
        cpu.mem_map(address, size)
    for section in sections:
        if section[2] & 2 and section[1] != 8 and section[5]:
            cpu.mem_write(section[3], binary[section[4]:section[4] + section[5]])
    cpu.mem_write(0xE000ED88, struct.pack("<I", 0xF00000))
    cpu.reg_write(UC_ARM_REG_SP, symbols["__initial_sp"])
    captured = bytearray()
    console_trace = bytearray()
    checkpoints = []
    calls = {"adc": 0, "malloc": 0, "write": 0, "calibration": 0, "dtu_tx": 0, "dtu_rx_starts": 0,
             "config":0, "stop":0, "soil_reads":0, "wind_reads":0, "ad3_reads":0, "ad4_reads":0, "weather_tx":0, "weather_rx_starts":0}
    def check_console(stage, output):
        text=output.decode("utf-8")
        if stage>=30:
            expected={30:(0,300,1,1),31:(2500,600,1,1),32:(3333,700,1,1),
                      33:(5000,900,1,1),34:(-10,300,2,1),35:(10456,900,3,1),
                      36:(0,0,0,0),37:(4,301,1,1),38:(10456,900,3,1),
                      39:(0,300,2,1),40:(5000,900,3,1)}[stage]
            input_mv=read_word('g_test_soil_ph_input_mv')
            if input_mv>=1<<31: input_mv-=1<<32
            assert not text
            assert (input_mv,read_word('g_test_soil_ph_x100'),read_word('g_test_soil_ph_range'),read_word('g_test_soil_ph_valid'))==expected
            return
        if stage>=20:
            expected={20:(40,0,1,1),21:(2540,1500,1,1),22:(5040,3000,1,1),
                      23:(29,0,2,1),24:(10448,3000,3,1),25:(0,0,0,0),
                      26:(41,1,1,1),27:(10448,3000,3,1),28:(40,0,2,1)}[stage]
            assert not text
            assert tuple(read_word(n) for n in ('g_test_wind_input_mv','g_test_wind_speed_x100','g_test_wind_range','g_test_wind_value_valid'))==expected
            return
        if stage==13:
            lines=text.splitlines()
            assert sum(line.startswith("WEATHER_CONFIG,") for line in lines)==2
            assert sum("rx_status=OK" in line for line in lines)==2
            rows=[dict(field.split("=",1) for field in line.split(",")[1:]) for line in lines if line.startswith("WEATHER,")]
            assert len(rows)==6
            expected=[("TEMP_HUM",{"temperature_c":"-5.5","humidity_rh_pct":"45.6"}),
                      ("LIGHT",{"light_lux":"305419896"}),("PM",{"pm25_ug_m3":"12","pm10_ug_m3":"34"}),
                      ("PRESSURE",{"pressure_kpa":"101.32"}),("CO2",{"co2_ppm":"600"}),("OXYGEN",{"oxygen_pct":"20.9"})]
            previous={}
            for index,(row,(item,values)) in enumerate(zip(rows,expected)):
                assert row['item']==item and row['seq']==str(index+1) and row['status']=='OK'
                assert row['port']==('USART3' if index<4 else 'UART4')
                assert all(row[key]==value for key,value in values.items())
                assert row['cache']=='FRESH' and row['rx_truncated']=='0'
                if row['port'] in previous: assert int(row['tx_t_ms'])-previous[row['port']]>=251
                previous[row['port']]=int(row['sample_t_ms'])
            print("ARM CPU / fake weather UART: "+next(line for line in lines if line.startswith("WEATHER,")))
            return
        if stage==0:
            assert text.count("WEATHER_CONFIG,")==2 and "WEATHER_PERIODS," in text
            assert text.count("rx_status=IRQ_DISABLED")==2
            return
        if stage==4:
            assert not text and read_word("g_test_printf_errors")==1
            return
        if stage==6:
            assert text=="direct=7\r\n"; return
        if stage in (11,12):
            assert not text  # ACK processing must be silent on USART2.
            assert read_word("g_test_acks")==stage-10 and read_word("g_test_ack_sequence")==stage-10
            return
        soil,direction={
            1:("50.00%","249.59度"),2:("0.00%（偏低）","0.00度（偏低）"),
            3:("无效","0.00度（偏低）"),5:("0.00%（偏低）","0.00度（偏低）"),
            7:("0.00%","360.00度（偏高）"),8:("100.00%","360.00度（偏高）"),
            9:("100.00%（偏高）","360.00度（偏高）"),10:("0.01%","360.00度（偏高）")}[stage]
        assert text.endswith("\r\n") and text.count("\n")==text.count("\r\n"),repr(text)
        lines=text.splitlines()
        business=[line for line in lines if line.startswith("土壤湿度：")]
        assert business==[f"土壤湿度：{soil}，风向角度：{direction}"],repr(text)
        samples=[dict(field.split("=",1) for field in line.split(",")[1:]) for line in lines if line.startswith("ADC_SAMPLE,")]
        assert len(samples)==2 and [row['channel'] for row in samples]==['AD2','AD4']
        assert samples[0]['round_id']==samples[1]['round_id']
        tick={1:1000,2:2000,3:3000,5:5000,7:6000,8:7000,9:8000,10:9000}[stage]
        assert all(row['sample_t_ms']==str(tick) and row['round_id']==str(tick//100+1) for row in samples)
        assert samples[0]['adc_raw']=='12345' and samples[0]['status']=='OK'
        assert (samples[0]['input_mv'],samples[0]['wind_speed_mps'],samples[0]['range'])==('1992','11.71','OK')
        expected_soil_ph=('5511','9.00','HIGH') if stage==1 else ('NA','NA','NA') if stage==3 else ('-10','3.00','LOW') if stage in (2,5) else ('10456','9.00','HIGH')
        assert tuple(samples[1][key] for key in ('input_mv','soil_ph','range'))==expected_soil_ph
        assert 'wind_speed_mps' not in samples[1]
        assert samples[0]['pin']=='PA6' and samples[0]['adc_channel']=='3'
        assert samples[1]['pin']=='PA4' and samples[1]['adc_channel']=='18'
        assert samples[1]['adc_raw']==('34567' if stage==1 else 'NA' if stage==3 else '0' if stage in (2,5) else '65535')
        if stage==3:
            assert samples[1]['status']=='ADC_POLL_FAILED' and samples[1]['hal_status']=='HAL_TIMEOUT' and samples[1]['stop_status']=='HAL_OK'
        else: assert samples[1]['status']=='OK'
        windows=[dict(field.split("=",1) for field in line.split(",")[1:]) for line in lines if line.startswith("ADC_WINDOW,")]
        assert len(windows)==(2 if stage in (3,7,10) else 0)
        assert len(lines)==3+len(windows),repr(text)
        if windows:
            assert [row['channel'] for row in windows]==['AD2','AD4']
            assert all(row['window_end_ms']==str(tick) and row['sample_count']=='30' for row in windows)
            assert windows[0]['adc_raw_mean']=='12345.00' and windows[0]['valid_count']=='30'
            assert (windows[0]['input_mv'],windows[0]['wind_speed_mps'],windows[0]['range'])==('1992','11.71','OK')
            assert tuple(windows[1][key] for key in ('input_mv','soil_ph','range'))=={3:('5248','9.00','HIGH'),7:('-10','3.00','LOW'),10:('10456','9.00','HIGH')}[stage]
            assert 'wind_speed_mps' not in windows[1]
            assert windows[1]['adc_raw_mean']=={3:'32920.95',7:'0.00',10:'65535.00'}[stage]
            assert windows[1]['valid_count']==('21' if stage==3 else '29' if stage==7 else '30')
        if stage==1:
            print("ARM CPU / fake HAL USART2: "+text.strip())
        if stage in (3,7,10):
            assert read_word("g_test_window_end")=={3:3000,7:6000,10:9000}[stage]
            assert tuple(read_word(n) for n in ("g_test_soil_valid","g_test_soil_used","g_test_soil_mean"))=={
                3:(21,0,0),7:(29,27,0),10:(30,28,32329)}[stage]
            assert tuple(read_word(n) for n in ("g_test_wind_valid","g_test_wind_used","g_test_wind_mean"))==(30,28,12345)
            assert read_word("g_test_ad3_samples")==30 and read_word("g_test_ad3_valid")==30
            assert read_word("g_test_ad3_sum")=={3:469120,7:0,10:1966050}[stage]
    def read_word(name):
        return struct.unpack("<I", cpu.mem_read(symbols[name], 4))[0]
    def return_value(value):
        cpu.reg_write(UC_ARM_REG_R0, value)
        cpu.reg_write(UC_ARM_REG_PC, cpu.reg_read(UC_ARM_REG_LR))
    def handle(name):
        if name == "HAL_GetTick": return_value(read_word("g_test_tick_ms"))
        elif name == "HAL_UART_GetState":
            cpu.mem_write(symbols["huart2"], struct.pack("<I", 0x40004400))
            cpu.mem_write(0x4000441C, struct.pack("<I", 1 << 6))
            return_value(0x20)
        elif name == "HAL_UART_Transmit":
            uart=cpu.reg_read(UC_ARM_REG_R0)
            if uart in (symbols['huart3'],symbols['huart4']):
                port=0 if uart==symbols['huart3'] else 1
                assert calls['weather_rx_starts']>=2
                request=bytes(cpu.mem_read(cpu.reg_read(UC_ARM_REG_R1),cpu.reg_read(UC_ARM_REG_R2)))
                golden=[bytes.fromhex(frame) for frame in ('010300000002C40B','01030002000265CB','010300140002840F','0103000B0001F5C8','01030007000135CB','01030008000105C8')]
                assert request==golden[calls['weather_tx']], (calls['weather_tx'],request.hex(),port,read_word('g_test_tick_ms'),bytes(captured).decode('utf-8'))
                words=[(456,0xFFC9),(0x1234,0x5678),(12,34),(10132,),(600,),(209,)][calls['weather_tx']]
                response=bytearray((1,3,len(words)*2))
                for word in words: response.extend(word.to_bytes(2,'big'))
                crc=0xFFFF
                for byte in response:
                    crc^=byte
                    for _ in range(8): crc=(crc>>1)^0xA001 if crc&1 else crc>>1
                response.extend(crc.to_bytes(2,'little'))
                cpu.mem_write(symbols['g_test_weather_reply']+port*9,bytes(response))
                cpu.mem_write(symbols['g_test_weather_length']+port*4,struct.pack('<I',len(response)))
                calls['weather_tx']+=1;return_value(0);return
            if cpu.reg_read(UC_ARM_REG_R0) == symbols["huart6"]:
                assert calls["dtu_rx_starts"] > 0
                payload = cpu.mem_read(cpu.reg_read(UC_ARM_REG_R1), cpu.reg_read(UC_ARM_REG_R2))
                message=json.loads(bytes(payload))
                sequence=message["seq"]
                assert sequence==calls["dtu_tx"]+1 and message["t_ms"]==sequence*3000
                assert message["window_ms"]==3000 and message["sample_count"]==30
                expected_window={1:(21,0,None,None),2:(29,27,0,0),3:(30,28,32329,100)}[sequence]
                assert tuple(message[key] for key in ("valid_count","used_count","adc_raw","moisture_pct"))==expected_window
                assert message["device_id"]=="tea_h743_001" and message["token"]
                assert not any(key.startswith(("wind_","ad3")) for key in message) and message['channel']=='AD0' and 'soil_ph' not in message
                payload=json.dumps({"id":14,"extra":{"nested":False},"seq":sequence,"device_id":"tea_h743_001","ok":True},separators=(",",":")).encode()+b"\r\n"
                cpu.mem_write(symbols["g_test_dtu_tx"], bytes(payload))
                cpu.mem_write(symbols["g_test_dtu_tx_length"], struct.pack("<I", len(payload)))
                calls["dtu_tx"] += 1
                return_value(0)
                return
            if not read_word("g_test_tx_error"):
                captured.extend(cpu.mem_read(cpu.reg_read(UC_ARM_REG_R1), cpu.reg_read(UC_ARM_REG_R2)))
            return_value(1 if read_word("g_test_tx_error") else 0)
        elif name == "HAL_UART_Receive_IT":
            uart=cpu.reg_read(UC_ARM_REG_R0)
            if uart in (symbols['huart3'],symbols['huart4']):
                port=0 if uart==symbols['huart3'] else 1
                assert cpu.reg_read(UC_ARM_REG_R2)==1
                cpu.mem_write(symbols['g_test_weather_rx']+port*4,struct.pack('<I',cpu.reg_read(UC_ARM_REG_R1)))
                calls['weather_rx_starts']+=1;return_value(0);return
            assert cpu.reg_read(UC_ARM_REG_R0) == symbols["huart6"] and cpu.reg_read(UC_ARM_REG_R2) == 1
            cpu.mem_write(symbols["g_test_dtu_rx_byte"], struct.pack("<I", cpu.reg_read(UC_ARM_REG_R1)))
            calls["dtu_rx_starts"] += 1
            return_value(0)
        elif name == "HAL_UART_AbortReceive": return_value(0)
        elif name == "HAL_ADCEx_Calibration_Start":
            calls["calibration"] += 1; return_value(0)
        elif name == "HAL_ADC_ConfigChannel":
            channel=struct.unpack("<I",cpu.mem_read(cpu.reg_read(UC_ARM_REG_R1),4))[0]
            expected_channel=read_word(("g_test_soil_channel","g_test_wind_channel","g_test_ad3_channel","g_test_ad4_channel")[calls["config"]%4])
            assert channel==expected_channel
            calls["selected"]=channel; calls["config"]+=1; return_value(0)
        elif name == "HAL_ADC_Start": calls["adc"] += 1; return_value(0)
        elif name == "HAL_ADC_PollForConversion":
            failed=(calls["selected"]==read_word("g_test_soil_channel") and read_word("g_test_poll_error")) or (calls["selected"]==read_word("g_test_ad4_channel") and read_word("g_test_ad4_poll_error"))
            return_value(3 if failed else 0)
        elif name == "HAL_ADC_GetValue":
            soil=calls["selected"]==read_word("g_test_soil_channel")
            ad3=calls["selected"]==read_word("g_test_ad3_channel")
            ad4=calls["selected"]==read_word("g_test_ad4_channel")
            calls["soil_reads" if soil else "ad3_reads" if ad3 else "ad4_reads" if ad4 else "wind_reads"]+=1
            return_value(read_word("g_test_raw") if soil else read_word("g_test_ad3_raw") if ad3 else read_word("g_test_ad4_raw") if ad4 else 12345)
        elif name == "HAL_ADC_Stop": calls["stop"]+=1; return_value(0)
        elif name == "_sys_write": calls["write"] += 1
        elif name == "malloc": calls["malloc"] += 1
        elif name == "TestArm_Observe":
            stage = cpu.reg_read(UC_ARM_REG_R0)
            check_console(stage,bytes(captured))
            console_trace.extend(captured)
            checkpoints.append(stage); captured.clear()
        elif name == "TestArm_Done": cpu.emu_stop()
        elif name == "_sys_exit": raise AssertionError("Unexpected C library exit")
        elif name == "Error_Handler": raise AssertionError("Unexpected Error_Handler in CPU fixture")
    names = ["HAL_GetTick", "HAL_UART_GetState", "HAL_UART_Transmit", "HAL_ADCEx_Calibration_Start",
             "HAL_ADC_Start", "HAL_ADC_PollForConversion", "HAL_ADC_GetValue", "HAL_ADC_Stop",
             "HAL_UART_Receive_IT", "HAL_UART_AbortReceive", "_sys_write", "malloc", "TestArm_Observe", "TestArm_Done", "_sys_exit"]
    names.append("HAL_ADC_ConfigChannel")
    names.append("Error_Handler")
    addresses = {symbols[name] & ~1: name for name in names if name in symbols}
    def instruction_hook(cpu_instance, address, size, user):
        if address in addresses: handle(addresses[address])
    cpu.hook_add(UC_HOOK_CODE, instruction_hook)
    cpu.emu_start(symbols["__main"] | 1, 0, count=8000000)
    assert checkpoints == [0,1,2,3,11,4,5,6,7,12,8,9,10,13,20,21,22,23,24,25,26,27,28,30,31,32,33,34,35,36,37,38,39,40], (checkpoints,calls,hex(cpu.reg_read(UC_ARM_REG_PC)))
    assert calls["adc"]==364 and calls["config"]==364 and calls["stop"]==728 and calls["calibration"]==1, calls
    assert calls["soil_reads"]==81 and calls["wind_reads"]==91 and calls["ad3_reads"]==91 and calls["ad4_reads"]==81, calls
    assert calls["weather_tx"]==6 and calls["weather_rx_starts"]>6, calls
    assert calls["write"] > 0 and calls["malloc"] == 0, calls
    assert calls["dtu_tx"] == 3 and calls["dtu_rx_starts"] > 1, calls
    Path(os.environ.get("APP_ARM_CONSOLE_OUTPUT", str(ROOT / "Docs/validation/ad2_ad4_arm_console.txt"))).write_bytes(console_trace)
    print("PASS: real ARM measured wind zero/mid/full, LOW/HIGH, zero-valid vs no-data, rational raw mean and UINT32_MAX count signed-64 calculations")
    print("PASS: real ARM AD4 electrical endpoints/pH 3/6/7/9, signed voltage/LOW/HIGH, invalid/zero/fractional mean/UINT32_MAX; existing AD4 records extended only")
    print("PASS: real ARM weather six CRC requests, shared HAL callbacks, negative temperature/uint32 light/scaled units and UART2 raw-frame output")
    print("PASS: real Arm libc printf -> production _sys_write -> BspConsole -> fake HAL")
    print("PASS: 100ms acquisition, 1s printf, 3s trimmed windows, fractional mean conversion, failure/NA and write recovery")
    print("PASS: 91 complete rounds / 364 explicit 5/3/19/18 selections; AD2/AD4 raw samples/plain means/zero/failure; Chinese soil/wind direction and ACK preserved; no runtime malloc; CPU emulation only")
    print("PASS: USART6 receive armed before TX; production receive callback/ring/main-loop JSON ACK alongside soil printf")
