#include "bsp_dtu.h"
#include "bsp_config.h"
#include "bsp_weather_rs485.h"
#include "usart.h"

#define BSP_DTU_RX_BUFFER_SIZE 256U

static volatile uint8_t s_rx_buffer[BSP_DTU_RX_BUFFER_SIZE];
static uint8_t s_rx_byte;
static volatile uint16_t s_rx_head;
static volatile uint16_t s_rx_tail;
static volatile uint8_t s_initialized;
static volatile uint8_t s_rx_data_lost;
static volatile uint8_t s_abort_required;
static volatile BspDtuDiagnostics s_diagnostics;

static BspDtuStatus BspDtu_MapHalStatus(HAL_StatusTypeDef status)
{
  switch (status)
  {
    case HAL_OK:      return BSP_DTU_OK;
    case HAL_BUSY:    return BSP_DTU_UART_BUSY;
    case HAL_TIMEOUT: return BSP_DTU_UART_TIMEOUT;
    default:          return BSP_DTU_UART_ERROR;
  }
}

/* Called with interrupts masked in the main loop, or from the UART ISR.
 * The configured non-DMA HAL abort only clears RX flags/state; it does not
 * disturb an ongoing TX or reinitialize USART6. */
static BspDtuStatus BspDtu_StartReceive(void)
{
  BspDtuStatus status;
  if (s_abort_required != 0U)
  {
    status = BspDtu_MapHalStatus(HAL_UART_AbortReceive(&huart6));
    s_diagnostics.last_abort_status = status;
    if (status != BSP_DTU_OK)
    {
      return status;
    }
    s_abort_required = 0U;
  }
  status = BspDtu_MapHalStatus(HAL_UART_Receive_IT(&huart6, &s_rx_byte, 1U));
  s_diagnostics.last_rx_status = status;
  s_diagnostics.rx_active = (status == BSP_DTU_OK) ? 1U : 0U;
  if (status != BSP_DTU_OK)
  {
    ++s_diagnostics.rx_start_errors;
    s_rx_data_lost = 1U;
    s_abort_required = 1U;
  }
  return status;
}

BspDtuStatus BspDtu_Init(void)
{
  const BspDtuDiagnostics empty = {0U, 0U, 0U, 0U, 0U, 0U, 0U,
                                  BSP_DTU_OK, BSP_DTU_OK, BSP_DTU_OK, 0U};
  BspDtuStatus status;
  uint32_t irq_state = __get_PRIMASK();
  __disable_irq();
  s_rx_head = 0U;
  s_rx_tail = 0U;
  s_rx_data_lost = 0U;
  /* Repeated init must also terminate the previous one-byte receive. */
  s_abort_required = s_initialized;
  s_initialized = 1U;
  s_diagnostics = empty;
  status = BspDtu_StartReceive();
  __set_PRIMASK(irq_state);
  return status;
}

BspDtuStatus BspDtu_Send(const char *data, size_t length)
{
  BspDtuStatus status;
  uint32_t irq_state;
  if ((data == NULL) || (length == 0U) || (length > UINT16_MAX))
  {
    status = BSP_DTU_BAD_LENGTH;
  }
  else
  {
    irq_state = __get_PRIMASK();
    __disable_irq();
    if ((s_initialized != 0U) && (s_diagnostics.rx_active == 0U))
    {
      (void)BspDtu_StartReceive();
    }
    status = ((s_initialized != 0U) && (s_diagnostics.rx_active != 0U))
             ? BSP_DTU_OK : BSP_DTU_RX_NOT_READY;
    __set_PRIMASK(irq_state);
    if (status == BSP_DTU_OK)
    {
      /* RX interrupts remain enabled while the bounded synchronous TX runs.
       * No GPIO direction control: AUTO on this USART6 path only. */
      status = BspDtu_MapHalStatus(HAL_UART_Transmit(&huart6, (const uint8_t *)data,
                                   (uint16_t)length, BSP_DTU_TX_TIMEOUT_MS));
    }
  }
  irq_state = __get_PRIMASK();
  __disable_irq();
  ++s_diagnostics.tx_attempts;
  s_diagnostics.last_tx_status = status;
  if (status != BSP_DTU_OK)
  {
    ++s_diagnostics.tx_errors;
  }
  __set_PRIMASK(irq_state);
  return status;
}

BspDtuReadResult BspDtu_Read(uint8_t *data, size_t capacity)
{
  BspDtuReadResult result = {0U, 0U};
  uint32_t irq_state;
  if ((data == NULL) || (capacity == 0U))
  {
    return result;
  }
  /* Keep interrupt masking bounded even for an oversized caller buffer. */
  if (capacity > 32U)
  {
    capacity = 32U;
  }
  irq_state = __get_PRIMASK();
  __disable_irq();
  if ((s_initialized != 0U) && (s_diagnostics.rx_active == 0U))
  {
    (void)BspDtu_StartReceive();
  }
  if (s_rx_data_lost != 0U)
  {
    s_rx_tail = s_rx_head;
    s_rx_data_lost = 0U;
    result.data_lost = 1U;
  }
  else
  {
    while ((result.length < capacity) && (s_rx_tail != s_rx_head))
    {
      data[result.length++] = s_rx_buffer[s_rx_tail];
      s_rx_tail = (uint16_t)((s_rx_tail + 1U) % BSP_DTU_RX_BUFFER_SIZE);
    }
  }
  __set_PRIMASK(irq_state);
  return result;
}

BspDtuDiagnostics BspDtu_GetDiagnostics(void)
{
  BspDtuDiagnostics result;
  uint32_t irq_state = __get_PRIMASK();
  __disable_irq();
  result = s_diagnostics;
  __set_PRIMASK(irq_state);
  return result;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *uart)
{
  uint16_t next;
  if(uart==&huart3) { BspWeatherRs485_RxCompleteIsr(BSP_WEATHER_RS485_MET); return; }
  if(uart==&huart4) { BspWeatherRs485_RxCompleteIsr(BSP_WEATHER_RS485_GAS); return; }
  if ((uart != &huart6) || (s_initialized == 0U) || (s_diagnostics.rx_active == 0U))
  {
    return;
  }
  s_diagnostics.rx_active = 0U;
  ++s_diagnostics.rx_bytes;
  next = (uint16_t)((s_rx_head + 1U) % BSP_DTU_RX_BUFFER_SIZE);
  if (next == s_rx_tail)
  {
    ++s_diagnostics.rx_overflows;
    s_rx_data_lost = 1U;
  }
  else
  {
    s_rx_buffer[s_rx_head] = s_rx_byte;
    s_rx_head = next;
  }
  (void)BspDtu_StartReceive();
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *uart)
{
  if(uart==&huart3) { BspWeatherRs485_ErrorIsr(BSP_WEATHER_RS485_MET,HAL_UART_GetError(uart)); return; }
  if(uart==&huart4) { BspWeatherRs485_ErrorIsr(BSP_WEATHER_RS485_GAS,HAL_UART_GetError(uart)); return; }
  if ((uart != &huart6) || (s_initialized == 0U))
  {
    return;
  }
  ++s_diagnostics.rx_errors;
  s_diagnostics.last_uart_error = HAL_UART_GetError(uart);
  s_diagnostics.rx_active = 0U;
  s_rx_data_lost = 1U;
  s_abort_required = 1U;
  (void)BspDtu_StartReceive();
}

const char *BspDtu_StatusName(BspDtuStatus status)
{
  switch (status)
  {
    case BSP_DTU_OK:           return "OK";
    case BSP_DTU_BAD_LENGTH:   return "BAD_LENGTH";
    case BSP_DTU_UART_BUSY:    return "UART_BUSY";
    case BSP_DTU_UART_TIMEOUT: return "UART_TIMEOUT";
    case BSP_DTU_RX_NOT_READY: return "RX_NOT_READY";
    default:                  return "UART_ERROR";
  }
}
